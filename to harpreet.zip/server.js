// Dependencies
var express = require('express');
var app = express();
var restful = require('node-restful');
var bodyParser = require('body-parser');
var path = require('path');
var mongoose = restful.mongoose;
var multer = require('multer');
var done = false;
var fileObj = {};
var server = require('http').Server(app);
var io = require('socket.io')(server);

io.on('connection', function(socket){
  socket.on('user-transaction', function(obj){
    io.emit('user-transaction', obj);
  });
});

app.use(express.static(path.join(__dirname, 'public')));

var allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
};

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(allowCrossDomain);
app.use(express.static(path.join(__dirname, 'public')));

mongoose.connect('mongodb://localhost/blooddonation');


app.use(multer({ dest: './uploads/',
	rename: function (fieldname, filename) {
		return filename+Date.now();
	},
	onFileUploadStart: function (file) {
		console.log(file.originalname + ' is starting ...');
	},
	onFileUploadComplete: function (file) {
		fileObj = file;
		console.log(file.fieldname + ' uploaded to  ' + file.path)
		done=true;
	}
}));

// app.get('/test',function(req,res){
      // res.sendfile("uploads/05_Unltd1433852969463.png");
// });

app.post('/api/photo',function(req,res){
  if(done==true){
    console.log(req.files);
    res.send(fileObj);
  }
});

var userSchema = mongoose.Schema({
	userID: String,
	name: String,
	house: String
});

var testimonialSchema = mongoose.Schema({
	userID: String,
	userName: String,
	testimonial: String
});

var gallerySchema = mongoose.Schema({
	image: String
});

var transactionSchema = mongoose.Schema({
	userID: String,
	house: String
});

var User = restful.model('user', userSchema);
var Testimonial = restful.model('testimonial', testimonialSchema);
var Gallery = restful.model('gallery', gallerySchema);
var Transaction = restful.model('transaction', transactionSchema);


app.post('/api/transaction', function(req,res, next){
	console.log('testing socket');
	io.emit('user-transaction', {});
	next()
});


User.methods(['get', 'post', 'delete']);
Testimonial.methods(['get', 'post', 'delete']);
Gallery.methods(['get', 'post', 'delete']);
Transaction.methods(['get', 'post', 'delete']);


User.register(app, '/api/user');
Testimonial.register(app, '/api/testimonial');
Gallery.register(app, '/api/gallery');
Transaction.register(app, '/api/transaction');

app.get('/', function(req,res){
	res.sendfile('./index.html');
});

server.listen(4000);
console.log('Server listening on port 4000....');