var webServiceURL = "http://192.168.12.60:4000/api";
var imagePathURL = "http://192.168.12.60/bloodDonation/uploads/";

$(document).ready(function() {
    loadDataUserList();
    
    addEventlistner();
	
	jQuery.expr[":"].containsIgnoreCase = jQuery.expr.createPseudo(function(arg) {
			  return function( elem ) {
				  return jQuery(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
			  };
	 });
	
});


function addEventlistner() {
    
    
    $('#submitData').click(function() {                
        submitUserData();
    });
	
	$('#employeeSearchBox').on('keyup',function(event){
		handleEmployeeSearch(event);
	});
    
    $('#js-upload-form').submit(function(event) {
        event.preventDefault();
        $(this).ajaxSubmit({
            
            error: function(xhr) {
                status('Error: ' + xhr.status);
            },
            
            success: function(response) {
                //console.log(response);
                
                var imgObj = {
                    "image": imagePathURL + response.name
                };
                
                uploadImageToServer(imgObj);
            }
        });
    });
}

function loadDataUserList() {
    
    
    $.ajax({
        method: "GET",
        url: webServiceURL+"/user",
        contentType: "jsonp",
        success: function(res) {
            console.log(res);
            if (res && res.length > 0) {
                console.log(res);
                renderUserList(res);
            } else {
            // $('.noDiv').addClass('disabled');
            }
        },
        error: function() {
            console.log("error");
        }
    });


}


function renderUserList(res) {
    
    var objectToPush = {
        "dataArray": res
    };
    var template = _.template($("#userTableRow").html(), objectToPush);
    
    $('#userTable').html(template);


}

function submitUserData() {
    var textarea = $('textarea');
    var testimonialData = textarea.val();
    
    console.log($('input[name="status"]:checked').val());
    var userId = $('input[name="status"]:checked').val();
    var username = $('input[name="status"]:checked').data('username');
    console.log(testimonialData, username);
    
    
    if (userId != undefined) 
    {
        if (testimonialData.length > 0) 
        {

            //var testimonialToUpload = username+" : "+testimonialData;
            var testimonialToUpload = testimonialData;
            console.log(testimonialToUpload);
            sendTestimonialRequest(userId, username, testimonialToUpload);
        }
        sendStatusSubmitRequest(userId);
    } else {
        
        alert("Please Select a User");
    
    }

}


function sendTestimonialRequest(userId, username, testimonialData) {
    
    var objectToPush = {
        "userID": userId,
        "userName": username,
        "testimonial": testimonialData
    };
    
    
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": webServiceURL+"/testimonial",
        "method": "POST",
        "headers": {
            "content-type": "application/json"
        },
        "processData": false,
        "data": JSON.stringify(objectToPush)
    };
    
    $.ajax(settings).done(function(response) {
    //alert("testimonial saved SuccessFully");
    }).fail(function() {
        alert("testimonial fail to save");
    });

}

function sendStatusSubmitRequest(deletedId) {
    
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": webServiceURL+"/user/" + deletedId,
        "method": "DELETE",
        "headers": {
            "content-type": "application/json"
        }
    };
    
    $.ajax(settings).done(function(response) {
        
        alert("User Deleted SuccessFully");
        $('textarea').val('');

        // $("#"+deletedId).remove();
        addCounterRequest(deletedId);
    
    }).fail(function() {
        
        alert("User fail to Delete");
    });

}

function addCounterRequest(deletedId) {
    
    var house = $('#' + deletedId + ' td:nth-child(3)').text();
    
    var counterObject = {
        "userID": deletedId,
        "house": house
    };
    
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": webServiceURL+"/transaction",
        "method": "POST",
        "headers": {
            "content-type": "application/json"
        },
        "processData": false,
        "data": JSON.stringify(counterObject)
    }
    
    $.ajax(settings).done(function(response) {
        console.log(response);
        $("#" + deletedId).remove();
    });
}

function uploadImageToServer(uploadObj) {
    
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": webServiceURL+"/gallery",
        "method": "POST",
        "headers": {
            "content-type": "application/json"
        },
        "processData": false,
        "data": JSON.stringify(uploadObj)
    }
    
    $.ajax(settings).done(function(response) {
//        console.log(response);	
		alert("Image Uploaded Successfully");
		$('#js-upload-files').val('');
    });
}

function handleEmployeeSearch(e){
	var searchText = $('#employeeSearchBox').val();
	//$('.radioLayoutCls').closest('li').hide();
	$('#userTable tr').hide();
	
	//$("#userTable tr td:nth-child(2)")

	if (searchText !== '') {
		$("#userTable tr td:nth-child(2):containsIgnoreCase('" + searchText + "')").each(function () {
			//$(e.target).closest('.radioLayoutCls').closest('li').show();
			$(this).closest('tr').show();
		});

	} else {
	   $('#userTable tr').show();
	}
}
