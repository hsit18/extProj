
$(document).ready(function(){
        var date = new Date(2015, 5, 16);
        var now = new Date();
        var diff = (date.getTime()) - (now.getTime());
        var timeLeft = Math.abs(diff/1000);
        var clock = $('.clock').FlipClock( {
            autoStart: false,
            clockFace: 'DailyCounter',
            countdown: true,
			stop: function(){
				$('.clock-counter').addClass('disabled');
			}
        });
        clock.setTime(20);
        clock.start();

        $('.slideshow').show();
       
    });