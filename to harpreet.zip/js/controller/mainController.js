var currentUserName, 
currentUserObj, 
userId, 
emailId;

var webServiceURL = "http://192.168.12.60:4000/api";

$(document).ready(function() {
    
    getUserDatafromURL().done(function() {
		
		socket.on('user-transaction', function(obj){
        	//console.log(obj);
			handleCounter();
      	});
        
        handleCounter();
        getTestimonials();
		getImages();
		getUserCount();
        
        if (emailId && emailId.length > 0) {
            checkUserEntry();
        }
        
        addEventListener();
    
    });

});

function getUserCount(){
	var settings = {
        "async": true,
        "crossDomain": true,
        "url": webServiceURL+"/user",
        "method": "GET",
        "headers": {
            "content-type": "application/json"
        }
    };
    
    $.ajax(settings).done(function(res) {
        //console.log(res);
		// to be disabled on the blood donation day
        $('#userCountTotal').text(res.length);
    });
}

function checkUserEntry() {
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": webServiceURL+"/user?userID=" + emailId,
        "method": "GET",
        "headers": {
            "content-type": "application/json"
        }
    };
    
    $.ajax(settings).done(function(res) {
        console.log(res);
        if (res && res.length > 0) {
            $('#myonoffswitch').prop('checked', true);
            $('.icn-yes').addClass('disabled');
            currentUserObj = res[0];
			$('#thankMessage').css('visibility', 'visible');
            $('#page-overlay').hide();
        } else {
            $('.icn-no').addClass('disabled');
            $('#myonoffswitch').prop('checked', false);
			$('#thankMessage').css('visibility', 'hidden');
            $('#page-overlay').hide();
        }
    });
}

function getUserDatafromURL() {
    
    var userName = getParameterByName('username'), 
    userNameArr = userName.replace('EXTENTIA05', '').slice(1).split('.'), 
    fullName = userNameArr[0] + ' ' + userNameArr[1], 
    $deferred = new $.Deferred();
    
    emailId = getParameterByName('emailid');
    userId = getParameterByName('uid');
    //userNameForDb = userNameArr[0] + userNameArr[1];
    currentUserName = fullName;

    //if(currentUserName.trim() === "undefined" || typeof(emailId) === "undefined"){
    if (userName === "" || emailId === "") {
        $('#unknownUserBox').show();
        $('#uname').text("User Name");
    } else {
        $('#uname').text(fullName);
    //$('#unknownUserBox').show();
    }
    
    $deferred.resolve();
    
    return $deferred.promise();
}

function addEventListener() {
    $('#myonoffswitch').unbind('change');
    $('#myonoffswitch').bind('change', submitResponse);
    
    $('#modalSubmit').unbind('click');
    $('#modalSubmit').bind('click', getModalData);
}

function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), 
    results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function submitResponse() {
    //var choice = $(this).data('value');
    var choice = $(this).prop('checked');
    
    if (choice) {
        addUserEntry();
    } else {
        
        var confirmMessage = "Are you Sure you want to cancel Blood Donation?";
        if (window.confirm(confirmMessage)) {
            removeUserEntry();
        } else {
            $('#myonoffswitch').prop('checked', true);
        }
    }
}

function handleCounter() {
    
    var houseArray = ["Royal Brigade", "Infinites", "Unicorns", "Spartans", "Parikrama", "Constant Variables"];
    
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": webServiceURL+"/transaction/",
        "method": "GET",
        "headers": {
            "content-type": "application/json"
        }
    };
    
    $.ajax(settings).done(function(response) {
		
		var totalUsersDonating = 123, //change this as per the total count
			maxWidthBottle = 301,
			usersDonated = response.length,
			bottleHeight = (maxWidthBottle/totalUsersDonating) * usersDonated;
		
		$('#fillBlood').css('height', bottleHeight+'px');
		
		// to be enabled on the blood donation day
		//$('#userCountTotal').text(response.length);
		
        
        var allHouseData = response;

        //$('#countTotal').text(allHouseData.length);
        $('.fillNumber').text(allHouseData.length);
        
        var countRB = _.filter(allHouseData, function(obj) {
            if (obj.house == houseArray[0]) {
                return (obj);
            }
        });
        
        $('#countRB').text(countRB.length);
        
        var countInfi = _.filter(allHouseData, function(obj) {
            if (obj.house == houseArray[1] || obj.house == "Infinite") {
                return (obj);
            }
        });
        
        $('#countInfi').text(countInfi.length);
        
        var countUni = _.filter(allHouseData, function(obj) {
            if (obj.house == houseArray[2]) {
                return (obj);
            }
        });
        
        $('#countUni').text(countUni.length);
        
        var countSparta = _.filter(allHouseData, function(obj) {
            if (obj.house == houseArray[3]) {
                return (obj);
            }
        });
        
        $('#countSparta').text(countSparta.length);
        
        var countPari = _.filter(allHouseData, function(obj) {
            if (obj.house == houseArray[4]) {
                return (obj);
            }
        });
        
        $('#countPari').text(countPari.length);
        
        var countCV = _.filter(allHouseData, function(obj) {
            if (obj.house == houseArray[5] || obj.house == "Constant Variable") {
                return (obj);
            }
        });
        
        $('#countCV').text(countCV.length);
    });

}

function addUserEntry() {
    
    var houseName = getParameterByName('hname');

    //if(typeof(houseName) === "undefined"){
    if (houseName === "") {
        houseName = $('#modalHouse').val();
    }
    
    var objectToInsert = {
        "userID": emailId,
        "name": currentUserName,
        "house": houseName
    };
    
    console.log("object to be inserted in DB", objectToInsert);
    
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": webServiceURL+"/user",
        "method": "POST",
        "headers": {
            "content-type": "application/json"
        },
        "processData": false,
        "data": JSON.stringify(objectToInsert)
    };
    
    $.ajax(settings).done(function(response) {
        currentUserObj = response;
        console.log(currentUserObj);
        $('#myonoffswitch').prop('checked', true);
        $('.icn-no').removeClass('disabled');
        $('.icn-yes').addClass('disabled');
		$('#thankMessage').css('visibility', 'visible');
		getUserCount();
    }).fail(function() {
        alert("submit failed");
    });

}

function removeUserEntry() {
    console.log("current user object", currentUserObj);
    
    var deleteId = currentUserObj._id;
    
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": webServiceURL+"/user/" + deleteId,
        "method": "DELETE",
        "headers": {
            "content-type": "application/json"
        }
    };
    
    $.ajax(settings).done(function(response) {
        $('#myonoffswitch').prop('checked', false);
        $('.icn-yes').removeClass('disabled');
        $('.icn-no').addClass('disabled');
		$('#thankMessage').css('visibility', 'hidden');
		getUserCount();
    }).fail(function() {
        alert("submit failed");
    });

}

function getTestimonials() {
    var settings = {
        "async": true,
        "crossDomain": true,
        "url": webServiceURL+"/testimonial/",
        "method": "GET",
        "headers": {
            "content-type": "application/json"
        }
    };
    
    $.ajax(settings).done(function(response) {
        //console.log(response);
        
        var obj = {
            "data": response
        };
        
        var templateScript = $('#testimonialTemplate').html(), 
        template = _.template(templateScript, obj);
        
        $('#tsetimonialContainer').html(template);
        //$('.slideshow').cycle();
    
    });
}

function getImages(){
	var settings = {
	  	"async": true,
	  	"crossDomain": true,
	  	"url": webServiceURL+"/gallery/",
	  	"method": "GET",
	  	"headers": {
			"content-type": "application/json"
	  	}
	};

	$.ajax(settings).done(function (response) {
	 	//console.log(response);
        
        var obj = {
            "data": response
        };
        
        var templateScript = $('#galleryTemplate').html(), 
        template = _.template(templateScript, obj);
        
        $('#imageContainer').html(template);
        $('.slideshow').cycle();
	});
}

function getModalData() {
    
    emailId = $('#modalEmail').val();
    var houseName = $('#modalHouse').val();
    
    var emailRegExp = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
    
    if (emailRegExp.test(emailId)) {
        var tempName = emailId.split('@'), 
        tempName1 = tempName[0].split('.'), 
        fullName = tempName1[0] + ' ' + tempName1[1];
        
        currentUserName = fullName;
        
        $('#uname').text(currentUserName);
        $('#unknownUserBox').hide();
        checkUserEntry();
    } else {
        alert("Pliease Enter Valid Email");
    }
}
