﻿// Dependencies
var mongoose = require('mongoose');
var CONSTANT = require('../utilities/Constant').CONSTANTS;

// Model Definition
var occurrenceSchema = new mongoose.Schema({
    notes: String,
    notes_datetime: Date,
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: CONSTANT.DOCUMENT_NAMES.USER }
});

// Export module.
module.exports = mongoose.model(CONSTANT.DOCUMENT_NAMES.OCCURRENCE_NOTES, occurrenceSchema);