// Dependencies
var mongoose = require('mongoose');
var CONSTANT = require('../utilities/Constant').CONSTANTS;

// Model Definition
var roomSchema = new mongoose.Schema({
    room_no: Number,
    si_ip: String,
    camera_no: Number,
    sensor1: String,
    sensor2: String,
    no_of_people: Number,
    cmp_people: Number
});

// Export module.
module.exports = mongoose.model(CONSTANT.DOCUMENT_NAMES.ROOMS, roomSchema);