﻿// Dependencies
var mongoose = require('mongoose');
var CONSTANT = require('../utilities/Constant').CONSTANTS;

// Model Definition
var behaviorSchema = new mongoose.Schema({
    behavior_level: Number,
    behavior: String,
    caption: String,
    sop: String,
	img_file: String,
    by_va: String,
    by_aa: String
});

// Export module.
module.exports = mongoose.model(CONSTANT.DOCUMENT_NAMES.BEHAVIORS, behaviorSchema);