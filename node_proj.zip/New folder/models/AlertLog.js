﻿// Dependencies
var mongoose = require('mongoose');
var CONSTANT = require('../utilities/Constant').CONSTANTS;
var mongoosePaginate = require('mongoose-paginate');


// Model Definition
var alertLogSchema = new mongoose.Schema({
    room_id: { type: mongoose.Schema.Types.ObjectId, ref: CONSTANT.DOCUMENT_NAMES.ROOMS },
    behavior_id: { type: mongoose.Schema.Types.ObjectId, ref: CONSTANT.DOCUMENT_NAMES.BEHAVIORS },
    sensor_name: String,
    alert_status: String,
    start_datetime: Date,
    end_datetime: Date,
    acknowleged_datetime: Date,   
    acknowleged_by: { type: mongoose.Schema.Types.ObjectId, ref: CONSTANT.DOCUMENT_NAMES.USER },
    priority: Number,
    confidence_value: String,
    notes: String,
    actual_no_of_people: Number,
    no_of_people: Number,
    current_notification: Number

});

//alertLogSchema.plugin( mongoosePaginate );
//mongoose.set('debug', true);

// Export module.
module.exports = mongoose.model(CONSTANT.DOCUMENT_NAMES.ALERT_LOG, alertLogSchema);