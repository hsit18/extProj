﻿// Dependencies
var mongoose = require('mongoose');
var CONSTANT = require('../utilities/Constant').CONSTANTS;

// Model Definition
var thresholdAuditSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: CONSTANT.DOCUMENT_NAMES.USER },
    room_id: { type: mongoose.Schema.Types.ObjectId, ref: CONSTANT.DOCUMENT_NAMES.ROOMS },
    behavior_id: { type: mongoose.Schema.Types.ObjectId, ref: CONSTANT.DOCUMENT_NAMES.BEHAVIORS },
    threshold_datetime: String,
    previous_confidence: String,
    new_confidence: String,
    no_of_people: Number
});

// Export module.
module.exports = mongoose.model(CONSTANT.DOCUMENT_NAMES.THRESHOLD_AUDIT, thresholdAuditSchema);