﻿// Dependencies
var mongoose = require('mongoose');
var CONSTANT = require('../utilities/Constant').CONSTANTS;

// Model Definition
var thresholdSchema = new mongoose.Schema({
    room_id: { type: mongoose.Schema.Types.ObjectId, ref: CONSTANT.DOCUMENT_NAMES.ROOMS },
    updated_by: { type: mongoose.Schema.Types.ObjectId, ref: CONSTANT.DOCUMENT_NAMES.USER },
    behavior_id: { type: mongoose.Schema.Types.ObjectId, ref: CONSTANT.DOCUMENT_NAMES.BEHAVIORS },
    confidence: Number,
    frequency: Number,
    updated_date: Date
});

// Export module.
module.exports = mongoose.model(CONSTANT.DOCUMENT_NAMES.THRESHOLD, thresholdSchema);