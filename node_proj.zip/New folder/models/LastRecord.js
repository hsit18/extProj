﻿// Dependencies
var mongoose = require('mongoose');
var CONSTANT = require('../utilities/Constant').CONSTANTS;

// Model Definition
var lastRecordSchema = new mongoose.Schema({
    room_id: { type: mongoose.Schema.Types.ObjectId, ref: CONSTANT.DOCUMENT_NAMES.ROOMS },
    sensor_name: String,
    last_record_date: String
});

// Export module.
module.exports = mongoose.model(CONSTANT.DOCUMENT_NAMES.LAST_RECORD, lastRecordSchema);