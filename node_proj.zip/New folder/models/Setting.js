/**
 * Created by Sandesh.Magdum on 3/19/2015.
 */

// Dependencies
var mongoose = require('mongoose');
var CONSTANT = require('../utilities/Constant').CONSTANTS;

// Model Definition
var settingsSchema = new mongoose.Schema({
    settingname:     { type: String, required: true, index: { unique: true } },
    settingvalue:    { type:  String },
    status:         {type: String, enum: ['active', 'inactive']},
    modified_by:    { type:  String },
    modified_at:    { type: Date }
});

// Export module.
module.exports = mongoose.model(CONSTANT.DOCUMENT_NAMES.SETTINGS, settingsSchema);
