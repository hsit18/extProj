﻿// Dependencies
var mongoose = require('mongoose');
var CONSTANT = require('../utilities/Constant').CONSTANTS;

// Model Definition
var eventsSchema = new mongoose.Schema({
    event_type: String,
    event_date: String,
    event_status: String,
    event_exception: String,
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: CONSTANT.DOCUMENT_NAMES.USER }
});

// Export module.
module.exports = mongoose.model(CONSTANT.DOCUMENT_NAMES.EVENT_LOG, eventsSchema);