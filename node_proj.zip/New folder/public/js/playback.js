var PLAYBACK = {	
	droppedLiveElements:[],
	droppedPlaybackElements:[],
	liveFuncs : [],
	playbackFuncs : [],
	onReady: function() {

		$("#menu li").draggable({revert: true});
		
		$('#txtPlaybackFromdate').datepicker({
            altField: "#hidPlaybackFromDate",
            altFormat: "yy-mm-dd",
            minDate: '-3m',
            maxDate: '-0',
            dateFormat: "dd-MM-yy"
        });
        $( document ).on( "click", "#liveVideo", PLAYBACK.fnDisplayLive);
        $( document ).on( "click", "#playbackVideo", PLAYBACK.fnDisplayPlayback);
        $( document ).on( "click", "#btnLoad", PLAYBACK.fnLoadPlayback);


		PLAYBACK.fnRemoveAllIframes();

		if(sessionStorage.getItem('activeSubTab') == 'playback'){
			PLAYBACK.fnDisplayPlayback();
		}else{
			PLAYBACK.fnDisplayLive();
		}


		document.getElementById("frmLivePlayback").reset();

	

		/********** START :  Live Video  *******************/
	    PLAYBACK.dropOption={ 
	        drop: function(event, ui) {
				$(event.target).empty();
				var cam_id = $(ui.draggable).attr("data-cameraid");
				var room_no = $(ui.draggable).attr("data-roomno");
				var tempHtml = $('.cameraDivTemplate').html();
				var currDivId = $(event.target).attr('id');
				var divIds_parts = currDivId.split('_');
				var scriptTag ='';
				var divHeight = $(event.target).height();
				var divWidth = $(event.target).width();

			
				$(event.target).append('<iframe class="ifrmLive" src="live.html?info='+divIds_parts[1]+'&cameraId='+cam_id+'&divWidth='+(divWidth-20)+'&divHeight='+(divHeight-60)+'&room_no='+room_no+'" class="dialog" id="iframe_'+divIds_parts[1]+'" frameborder="0" width="'+divWidth+'" height="'+(divHeight)+'">');
				
				PLAYBACK.droppedLiveElements.push({ui : currDivId, engMngr:'engineManager'+divIds_parts[1],imgMngr : 'imageViewer'+divIds_parts[1],audioMngr : 'audioPlayer'+divIds_parts[1],cam_id : cam_id,draggedEleText:room_no});

				sessionStorage.setItem('droppedLiveElements', JSON.stringify(PLAYBACK.droppedLiveElements));
	        }
	    };


		
		/**************** END :  LIVE VIDEO ****************/


		/***************** START : PLAYBACK VIDEO *****************/

		PLAYBACK.playbackDropOption={ 
	        drop: function(event, ui) {
				$(event.target).empty();
				var cam_id = $(ui.draggable).attr("data-cameraid");
				var room_no = $(ui.draggable).attr("data-roomno");
				
				var tempHtml = $('.cameraDivPlaybackTemplate').html();
				var currDivId = $(event.target).attr('id');
				var divIds_parts = currDivId.split('_');
				var scriptTag ='';
				var divHeight = $(event.target).height();
				var divWidth = $(event.target).width();


				tempHtml = tempHtml.replace(/###CAMID###/g,divIds_parts[1]).replace('###WIDTH###',divWidth).replace('###HEIGHT###',divHeight-40);
				$(event.target).html('<div class="dash-head">Room '+room_no+'</div>');


				PLAYBACK.droppedPlaybackElements.push({ui : currDivId, cam_id : cam_id,room_no:room_no,divWidth:divWidth,divHeight:divHeight});

				sessionStorage.setItem('droppedPlaybackElements', JSON.stringify(PLAYBACK.droppedPlaybackElements));
				console.log(sessionStorage.getItem('droppedPlaybackElements'));
	        }
	    };


		/*********  END : Playback Video ***********/
		

		$(document).on('change','#selectRoom',PLAYBACK.fnChangeGrid);
		var roomVal = $('#selectRoom').val();

		$('#selectRoom').val(roomVal);
		PLAYBACK.fnChangeGrid();

	},

	fnLoadPlayback : function(){
				 var frmValidator=	$('#frmLivePlayback').validate({
			rules: {
                txtPlaybackFromdate: {
                    required: true,
                },
                selPlybckFrmHr: {
                    required: true,
					le:'#selPlybckToHr'
                },
				selPlybckFrmMin: {
                    required: true,
					le:'#selPlybckToMin'
                },
				selPlybckToHr: {
                    required: true,
					ge:'#selPlybckFrmHr'
                },
				selPlybckToMin: {
                    required: true,
					ge:'#selPlybckFrmMin'
                }
 
            },
            messages: {
                txtPlaybackFromdate: {
                    required: "Select date."
					
                },
                selPlybckFrmHr: {
                    required: "Select from Hour.",
						le:'From value should be less than To value.'
                },
				selPlybckFrmMin: {
                    required: "Select from Mins.",
						le:'From value should be less than To value.'
                },
				selPlybckToHr: {
                    required: "Select to Hour.",
						ge:'To value should be greater than From value.'
                },
				selPlybckToMin: {
                    required: "Select to Mins.",
						ge:'To value should be greater than From value.'
                }
            },
            errorElement: "div",
			errorPlacement: function(error, element){
					error.appendTo( element.parent().parent() );
			}

		});

		/****  START : Validation ******/

			$.validator.addMethod('le', function(value, element, param) {
				
				var firstVal;
				var otherVal;
				if(param == '#selPlybckToMin'){
					if($('#selPlybckFrmHr').val() == $('#selPlybckToHr').val()){
						if($('#selPlybckFrmHr').val() == 0){
							if($('#selPlybckFrmMin').val() == 0 || ( $('#selPlybckFrmMin').val() > $('#selPlybckToMin').val() && $('#selPlybckFrmMin').val() != 0)){
								return false;
							}else{
								return true;
							}
						}else{
							firstVal = parseInt($('#selPlybckFrmHr').val()+ $('#selPlybckFrmMin').val());
							otherVal = parseInt($('#selPlybckToHr').val()+ $('#selPlybckToMin').val());
						}
						
						return this.optional(element) || firstVal <= otherVal ;

					}else{
						return true;
					}

				}else{
					firstVal = value;
					otherVal= $(param).val();
				  return this.optional(element) || (firstVal <= otherVal);

				}

			}, '');
			$.validator.addMethod('ge', function(value, element, param) {

				var firstVal;
				var otherVal;

				if(param == '#selPlybckFrmMin' ){
					if($('#selPlybckFrmHr').val() == $('#selPlybckToHr').val()){
						if($('#selPlybckFrmHr').val() == 0){
							if($('#selPlybckToMin').val() == 0 || ( $('#selPlybckToMin').val() < $('#selPlybckFrmMin').val()  &&  $('#selPlybckToMin').val() != 0) ){
								return false;
							}else{
								return true;
							}
						}else{
							otherVal = parseInt($('#selPlybckFrmHr').val()+ $('#selPlybckFrmMin').val());
							firstVal = parseInt($('#selPlybckToHr').val()+ $('#selPlybckToMin').val());
							return this.optional(element) || firstVal >= otherVal;
						}
					}
					else{
						return true;
					}
				}else{
					firstVal = value;
					var otherVal = $(param).val();
					return this.optional(element) || ( firstVal >= otherVal);
				}
				
				  
			}, '');

		/**** END : Validation  *****/


		var frmChk = $('#frmLivePlayback').valid();
		if($('#frmLivePlayback').valid()){
			
		var fromDate = $('#hidPlaybackFromDate').val();
		var fromHr = $('#selPlybckFrmHr').val();
		var fromMin = $('#selPlybckFrmMin').val();
		var toHr = $('#selPlybckToHr').val();
		var toMin = $('#selPlybckToMin').val();

		var dateData = fromDate.split('-');

		console.log(' Date ',fromDate,' from hr ',fromHr,' from min ',fromMin,' to hr ',toHr,' to min ',toMin);

		var checkFromDate = new Date(dateData[0],dateData[1]-1,dateData[2],fromHr,fromMin); //(year, month, day, hours, minutes, seconds, milliseconds); 
		var checkToDate = new Date(dateData[0],dateData[1]-1,dateData[2],toHr,toMin);

			if(checkFromDate!== undefined || checkToDate!== undefined){
				if(PLAYBACK.droppedPlaybackElements && PLAYBACK.droppedPlaybackElements.length > 0){
					for(objCnt = 0; objCnt < PLAYBACK.droppedPlaybackElements.length; objCnt++){
						if(PLAYBACK.droppedPlaybackElements[objCnt]!== undefined){
							
							$('#'+PLAYBACK.droppedPlaybackElements[objCnt].ui).html('<iframe class="ifrmPlayback" src="playBack.html?cameraId='+PLAYBACK.droppedPlaybackElements[objCnt].cam_id+'&divWidth='+(PLAYBACK.droppedPlaybackElements[objCnt].divWidth-20)+'&divHeight='+(PLAYBACK.droppedPlaybackElements[objCnt].divHeight-60)+'&room_no='+PLAYBACK.droppedPlaybackElements[objCnt].room_no+'&fromTime='+checkFromDate.getTime()+'&toTime='+checkToDate.getTime()+'" class="dialog" id="iframe_'+PLAYBACK.droppedPlaybackElements[objCnt].ui+'" frameborder="0" width="'+PLAYBACK.droppedPlaybackElements[objCnt].divWidth+'" height="'+PLAYBACK.droppedPlaybackElements[objCnt].divHeight+'">');
						}
					}
				}
			}
		}//check if is form is valid
		else{
		
		}
	},

	fnDisplayLive: function(){
		PLAYBACK.fnRemoveAllIframes();
		$('#divPlaybackSearch').hide();
		$("#liveVideo").addClass("active-tab");
		$('#playbackVideo').removeClass("active-tab");
		$('.live-video').show();
		$('.playback-video-div').hide();
		$('#selectRoom').trigger('change');
		sessionStorage.setItem('activeSubTab', 'live');
	},
	fnDisplayPlayback: function(){
		PLAYBACK.fnRemoveAllIframes();
		$('#divPlaybackSearch').show();
		$('#playbackVideo').addClass("active-tab");
		$('#liveVideo').removeClass("active-tab");
		$('.live-video').hide();
		$('.playback-video-div').show();
		$('#selectRoom').trigger('change');
		sessionStorage.setItem('activeSubTab', 'playback');
	},
	fnChangeGrid : function(){

		var roomVal = $('#selectRoom').val();

		PLAYBACK.droppedPlaybackElements.length = 0;

		if($(".live-video").is(':visible')){


			$(".live-video").empty();
			for(i=1;i<=roomVal;i++){
				$( ".live-video").prepend( "<div class='droppable'></div>" );
			}

			$(".live-video .droppable").each(function(i,ele){
				$(ele).attr('id','divDrop_'+i);
				$(ele).droppable(PLAYBACK.dropOption);
			});

		}else{
			$(".playback-video-div").empty();
			for(i=1;i<=roomVal;i++){
				$(".playback-video-div").prepend( "<div class='droppable'></div>" );
			}

			$(".playback-video-div .droppable").each(function(i,ele){
				$(ele).attr('id','divPlaybackDrop_'+i);
				$(ele).droppable(PLAYBACK.playbackDropOption);
			});
		}

		
		 if(roomVal==2){
			$(".droppable").addClass('option-two');
		 }
		 if(roomVal==3){
			$(".droppable").addClass('option-three');  
		 }
		 if(roomVal==4){
			$(".droppable").addClass('option-four');  
		 }
		 if(roomVal==6){
			$(".droppable").addClass('option-six');  
		 }
		 if(roomVal==8){
			$(".droppable").addClass('option-eight');  
		 }
		 sessionStorage.setItem('liveVideoGridSel', roomVal);
	},
	fnRemoveAllIframes : function(){
		$( document ).remove('.ifrmPlayback,.ifrmLive');
	}
};
$( document ).ready( PLAYBACK.onReady);
