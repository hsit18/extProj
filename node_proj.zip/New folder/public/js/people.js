var EDITPEOPLE = {               
    onReady: function() {        
        $( document ).on( "click", "#peopleCancel", EDITPEOPLE.fnClosePeople );      
        $( document ).on( "submit", "#peopleForm",  parent.OPERATION.fnUpdatePeople );     
    }, 
    isNumber: function(evt) {
         evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    },
    fnClosePeople: function() {
        location.reload();
        parent.OPERATION.fnClosePeople();
    }
};
$( document ).ready( EDITPEOPLE.onReady);  