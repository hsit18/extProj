var ALERTPOPUP = {
    zindex: 100,
    leftpx: 540,
    toppx: 40,
    monthsArrary: '',
    roomsAlertCount: '',
    onReady: function() {
        ALERTPOPUP.monthsArrary = $.parseJSON($('#hidMonthArr').val());
        var allAlerts = JSON.parse(localStorage.getItem("alertsData"));
        if (allAlerts !== null) {
            for (var i = 0; i < allAlerts.length; i++) {
                if (allAlerts[i].zindex > ALERTPOPUP.zindex)
                    ALERTPOPUP.zindex = allAlerts[i].zindex;
                if (allAlerts[i].left > ALERTPOPUP.leftpx)
                    ALERTPOPUP.leftpx = allAlerts[i].left;
                if (allAlerts[i].right > ALERTPOPUP.toppx)
                    ALERTPOPUP.rightpx = allAlerts[i].top;
                ALERTPOPUP.fnGenerateAlertPopup(allAlerts[i]);
            }
        }
        if (localStorage.getItem("showAlerts") === null) {
            localStorage.setItem("showAlerts", 1);
        }else{
            if (allAlerts !== null) {
                if (localStorage.getItem("showAlerts") == 1)
                   $("#showallpopup").addClass('hide-active');
                else
                    $("#hideallpopup").addClass('hide-active');
            }
        }

        //$(document).on("click", ".close-btn", ALERTPOPUP.fnCloseAlertPopup);
        $(document).on("click", "#showallpopup", ALERTPOPUP.fnShowAllAlerts);
        $(document).on("click", "#hideallpopup", ALERTPOPUP.fnHideAllAlerts);
        updateAlertLogList();
        socket.on('alertpopup', function (alertDet) {
            updateAlertLogList();
            console.log(alertDet);
            if(alertDet.notify){
                ALERTPOPUP.fnUpdateAlertCount(alertDet.room.room_no,"I");
                /*var oldCount = ALERTPOPUP.roomsAlertCount[alertDet.room.room_no].count;
                 ALERTPOPUP.roomsAlertCount[alertDet.room.room_no].count= ++oldCount;*/
                alertDet.zindex = ALERTPOPUP.zindex;
                alertDet.top = ALERTPOPUP.toppx;
                alertDet.left = ALERTPOPUP.leftpx;
                ALERTPOPUP.fnGenerateAlertPopup(alertDet);
            }

        });

        /* Draggable Javascript functions*/
        bringSelectedIframeToTop(true);
        allowDragOffScreen(false);
        setPageHeightAndWidth(window.screen.availWidth-330,window.screen.availHeight-150);
        /* Draggable Javascript functions*/

    },
    fnShowAllAlerts: function(){
        if($(this).hasClass('hide-active'))
            return false;
        $(".dialog").show();
        localStorage.setItem("showAlerts", 1);
        $(this).addClass('hide-active');
        $("#hideallpopup").removeClass('hide-active');
    },
    fnHideAllAlerts: function(){
        if($(this).hasClass('hide-active'))
            return false;
        $(".dialog").hide();
        localStorage.setItem("showAlerts", 0);
        $(this).addClass('hide-active');
        $("#showallpopup").removeClass('hide-active');
    },
    fnCloseAlertPopup: function (event) {
        var targetEle = event.target.id;
        var split_id = targetEle.split('_');
        $('#iframe_alertId_'+split_id[1]).remove();
        ALERTPOPUP.fnRemoveAlertFromLocalStorage(split_id[1]);
    },
    fnStoreAlertToLocalStorage: function (alert) {
        var index = -1;
        var alertsData = JSON.parse(localStorage.getItem("alertsData"));
        if (alertsData === null || alertsData.length == 0) {
            alertsData = [];
        } else {
            for (var i = 0, len = alertsData.length; i < len; i++) {
                if (alertsData[i].alert_id === alert.alert_id) {
                    index = i;
                    break;
                }
            }
        }
        if (index < 0) {
            alertsData.push(alert);
            localStorage.setItem("alertsData", JSON.stringify(alertsData));
        }
    },
    fnRemoveAlertFromLocalStorage: function (alertId) {
        if (localStorage.getItem("alertsData") === null) {
            return false;
        }
        var alertsData = [];
        var roomNo;
        alertsData = JSON.parse(localStorage.getItem("alertsData"));
        alertsData = alertsData.filter(function (el) {
            if(el.alert_id == alertId){
                roomNo=el.room.room_no;
            }
            return el.alert_id != alertId;
        });
        //ALERTPOPUP.fnUpdateAlertCount(roomNo,"D");
        localStorage.setItem("alertsData", JSON.stringify(alertsData));
        ALERTPOPUP.fnUpdateAlertCountOnHeader();
    },
    fnUpdateAlertToLocalStorage: function (topx, leftx, zindex, divEle) {
        var split_id = divEle.split('_');
        var alertData = JSON.parse(localStorage.getItem("alertsData"));
        var index = -1;
        alertLength = alertData.length;
        for (var i = 0; i < alertLength; i++) {
            if (alertData[i].alert_id === split_id[2]) {
                index = i;
                break;
            }
        }
        if (index >= 0) {
            alertData[index].zindex = zindex;
            alertData[index].top = topx;
            alertData[index].left = leftx;
        }
        localStorage.setItem("alertsData", JSON.stringify(alertData));
    },
    moveIframe: function (obj) {
        if($("#"+obj).length > 0){
            var postion = $("#"+obj).position();
            ALERTPOPUP.fnUpdateAlertToLocalStorage(postion.top, postion.left, $("#"+obj).css('z-index'), $("#"+obj).attr("id"))
        }
    },
    fnUpdateAlertCountOnHeader: function () {
        var alertData = JSON.parse(localStorage.getItem("alertsData"));
        if(alertData.length > 0)
            $("#alertCount").html('&nbsp;&nbsp;('+alertData.length+')');
        else
            $("#alertCount").html('');
    },
    fnGenerateAlertPopup: function (alertDet) {
        updateAlertLogList();
        var targetEle = 'alertId_' + alertDet.alert_id;
        
        if ($('body').find("#iframe_"+targetEle).length == 0) {
            var displayText;

            sessionStorage.setItem(alertDet.alert_id, JSON.stringify(alertDet));
            $("body").append('<iframe src="alert_popup.html?info='+alertDet.alert_id+'" class="dialog" id="iframe_'+targetEle+'" frameborder="0" width="630" height="800" >');

            $('#iframe_'+targetEle).css('z-index', alertDet.zindex);
            if(localStorage.getItem("showAlerts")==1)
                displayText="block";
            else
                displayText="none";


            $('#iframe_'+targetEle).css('display',displayText);

            $('#iframe_'+targetEle).css({'left': alertDet.left + 'px', 'top': alertDet.top + 'px','position': 'absolute'});

            ALERTPOPUP.toppx = ALERTPOPUP.toppx + 20;
            ALERTPOPUP.leftpx = ALERTPOPUP.leftpx + 20;
            ALERTPOPUP.fnStoreAlertToLocalStorage(alertDet);

        } else {
            $('#iframe_'+targetEle).css('z-index', ALERTPOPUP.zindex).show();
        }
        ALERTPOPUP.zindex = ALERTPOPUP.zindex + 1;
        ALERTPOPUP.fnUpdateAlertCountOnHeader();
    },
    fnAcknowledgeAlert: function (alertId,txt) {
        if(alertId!=undefined || alertId!=''){
            $.post('/submitAcknowledement', {'alert_id': alertId, 'note': txt}, function (res) {
                $("#iframe_alertId_" + alertId + "").remove();
                ALERTPOPUP.fnRemoveAlertFromLocalStorage(alertId);
                if ($('div.sensors').length > 0) {
                    $('div.sensors').html(res);
                }
            });
        } else {
            window.location.reload(true);
        }
    },
    fnUpdateAlertCount: function (roomNo, action) {
         
        if(ALERTPOPUP.roomsAlertCount[roomNo] !=undefined){
            var oldCount = ALERTPOPUP.roomsAlertCount[roomNo].count;
            if(action==="I")
                oldCount++;
            else
                oldCount--;
            ALERTPOPUP.roomsAlertCount[roomNo].count= oldCount;
            ALERTPOPUP.fnUpdateFloorPlan(roomNo);
        }
    },
    fnUpdateFloorPlan : function(roomNo){

        var theElement = $('#'+'room_'+roomNo+'_camera').find('div');
        if(theElement.length > 0){

            if(theElement.hasClass('acknowledged') || theElement.hasClass('avail')){
                if(ALERTPOPUP.roomsAlertCount[roomNo].count > 0){
                    theElement.removeClass().addClass('acknowledged sprite');
                    //theElement.html(''+ dataObj.room);
                    theElement.html('');
                }else{
                    theElement.removeClass().addClass('avail sprite');
                    theElement.html(''+ roomNo);
                }
            }else{
                if(ALERTPOPUP.roomsAlertCount[roomNo].count > 0){
                    theElement.removeClass().addClass('acknowledgedGrey sprite');
                    theElement.html('');
                }else{
                    theElement.removeClass().addClass('cross sprite');
                    theElement.html('');
                }
            }            
        } 
    }
};
$( document ).ready( ALERTPOPUP.onReady);
