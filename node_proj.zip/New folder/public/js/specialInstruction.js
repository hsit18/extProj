var SPECIALINST = {               
    onReady: function() {        
       $( document ).on( "click", "#btnSplConfirm", parent.OPERATION.fnSaveSplInst);      
       $( document ).on( "click", "#btnSplCancel", parent.OPERATION.fnCancelSplInst);             
    }
};
$( document ).ready( SPECIALINST.onReady);  