
var DETECTION = {
    zindex: 1,
    toppx: 10,
    leftpx: 34,
    onReady: function () {

        DETECTION.monthArr = $.parseJSON($('#hidMonthArr').val());
        DETECTION.monthArrFull = new Array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');        
        $( document ).on( "click", "#searchDet", DETECTION.fnSearchDet );
        var getVars = DETECTION.fnGetUrlVars();
        //Alerts and Acknowledgements
        
        $( document ).on( "click", ".ackBtn", DETECTION.fnAcknowledge );

        if (getVars.behavior != '') {
            $('#selBehavior').val(getVars.behavior)
        }
        if (getVars.room != '') {
            $('#selRooms').val(getVars.room)
        }
        if (getVars.detType != '') {
            $('#selDetType').val(getVars.detType)
        }

        if (getVars.fromDate != '' && getVars.fromDate !== undefined) {
            var fromParts = getVars.fromDate.split('-');
            $('#txtFromdate').val(fromParts[2] + '-' + DETECTION.monthArrFull[fromParts[1] - 1] + '-' + fromParts[0]);
            $('#hidFromDate').val(getVars.fromDate);
        }

        if (getVars.toDate != '' && getVars.toDate !== undefined) {
            var toParts = getVars.toDate.split('-');
            $('#txtTodate').val(toParts[2] + '-' + DETECTION.monthArrFull[toParts[1] - 1] + '-' + toParts[0]);
            $('#hidToDate').val(getVars.toDate);
        }

        var cameraNumber = 0;
		$('#txtFromdate,#txtTodate').keydown(function() {
			return false;
		});
	
        $('#txtFromdate').datepicker({
            altField: "#hidFromDate",
            altFormat: "yy-mm-dd",
            minDate: '-3m',
            maxDate: '-0',
            dateFormat: "dd-MM-yy",
        });

        $('#txtTodate').datepicker({
            altField: "#hidToDate",
            altFormat: "yy-mm-dd",
            minDate: '-3m',
            maxDate: '-0',
            dateFormat: "dd-MM-yy"
        });

		$('#txtFromdate,#txtTodate').css('cursor','pointer');
		$('#txtFromdate,#txtTodate').focus(function(){
			this.blur();
		});


        $('#txtFromdate,#txtTodate').datepicker();
		 var validatorCal = $('#frmDetection').validate({
            rules: {
                txtFromdate: {
                    dpCompareDate: ['notGreaterThan', '#txtTodate']
                },
                txtTodate: {
                    dpCompareDate: {notLessThan: '#txtFromdate'}
                }
            },
            messages: {
                txtFromdate: 'Please enter a date before the To date.',
                txtTodate: 'Please enter a date after the From date.'
            },
            errorElement: "p",
            onchange: function(element) { $(element).valid(); $(element).blur();},
			onkeyup: function(element) { $(element).valid();$(element).blur(); },
            onfocusout: function(element) { $(element).valid(); $(element).blur(); }
        });

		/*** START : JQ Grid Integration *****/

		var url_parts = window.location.href.split('?');
		var search_str = '';
		if(url_parts.length > 0 && url_parts[1]!='' && url_parts[1]!== undefined){
			search_str = '?'+url_parts[1];
		}

		function JSONToCSVConvertor(ReportTitle, ShowLabel) {
			//If JSONData is not an object then JSON.parse will parse the JSON string in an Object

			var colNamesOriginal = ['Behavior','Room','Date','Time','Priority','Acknowledged at','Acknowledged by','Follow up action by Officer','Actual No. of People','No. of People'];

			var colNames = ['behavior','room_no','startDate','startTime','priority','ackAt','username','notes','actual_no_of_people','no_of_people'];


			$.ajax( {
					url: "/detectionList"+search_str,
					type: 'GET',
					success:function(resSet){

					var JSONData = resSet.alerts;
				
					var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;

					//console.log(' CSV Generation ');
					//console.log(arrData);

					var CSV = '';    
					//Set Report title in first row or line
					
					//This condition will generate the Label/Header
					if (ShowLabel) {
						var row = "";
						
						//This loop will extract the label from 1st index of on array
						for (var index in colNamesOriginal) {
							
							//Now convert each value to string and comma-seprated
							row += '"' +colNamesOriginal[index] + '"' +',';
						}

						row = row.slice(0, -1);
						
						//append Label row with line break
						CSV += row + '\r\n';
					}
				
					//1st loop is to extract each row
					for (var i = 0; i < arrData.length; i++) {
						var row = "";
						var data = arrData[i];

						for ( var j = 0; j < colNames.length; j++) {
						 var field_data =  data[colNames[j]];
						   if(colNames[j] == 'behavior'){
							field_data =  data['behavior_text'];
						   }
							row += '"' + field_data + '",';
						}

						row = row.slice(0, row.length - 1);
						
						//add a line break after each row
						CSV += row + '\r\n';
					}

					if (CSV == '') {        
						alert("Invalid data");
						return;
					}
				
					//Generate a file name
					var fileName = '';
					//this will remove the blank-spaces from the title and replace it with an underscore
					fileName += ReportTitle.replace(/ /g,"_");   
					
					//Initialize file format you want csv or xls
					//var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
					if (navigator.appName != 'Microsoft Internet Explorer' && navigator.appName != 'Netscape')
					{
						window.open('data:text/csv;charset=utf-8,' + escape(CSV));
					}
					else
					{
						 var blob = new Blob([CSV], { type: 'text/csv;charset=utf-8;' });
						 if (navigator.msSaveBlob) { // IE 10+
							navigator.msSaveBlob(blob, fileName+'.csv');
						} 
					}
				}
			});//Ajax ends
		}

		var convertToXLS = function(fileName){

			var colNamesOriginal = ['Behavior','Room','Date','Time','Priority','Acknowledged at','Acknowledged by','Follow up action by Officer','Actual No. of People','No. of People'];

			var colNames = ['behavior','room_no','startDate','startTime','priority','ackAt','username','notes','actual_no_of_people','no_of_people'];

			$.ajax( {
					url: "/detectionList"+search_str,
					type: 'GET',
					success:function(resSet){

					var JSONData = resSet.alerts;
					var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
					
					var filteredArr =  [];
					for(i=0;i<arrData.length;i++){
					
					  var new_node = {};
					  console.log(arrData[i].behavior_text);
					  new_node.Behavior = arrData[i].behavior_text;
  					  new_node.Room_no = arrData[i].room_no;
  					  new_node.StartDate = arrData[i].startDate;
  					  new_node.StartTime = arrData[i].startTime;
					  new_node.Priority = arrData[i].priority;
  					  new_node.AckAt = arrData[i].ackAt;
  					  new_node.AckBy = arrData[i].username;
  					  new_node.FollowUpAction = arrData[i].notes;
  					  new_node.Actual_no_of_people = arrData[i].actual_no_of_people;
  					  new_node.No_of_people = arrData[i].no_of_people;

					  filteredArr.push(new_node);
					}

					var testJson = filteredArr;

					// Simple type mapping; dates can be hard
					// and I would prefer to simply use `datevalue`
					// ... you could even add the formula in here.
					testTypes = {
						"Behavior": "String",
						"Room_no": "Number",
						"StartDate": "String",
						"StartTime": "String",
						"Priority": "String",
						"AckAt": "String",
						"AckBy": "String",
						"FollowUpAction": "String",
						"Actual_no_of_people": "Number",
						"No_of_people": "Number"
					};

					emitXmlHeader = function () {
						var headerRow =  '<ss:Row>\n';
						for (var colName in colNamesOriginal) {
							headerRow += '  <ss:Cell>\n';
							headerRow += '    <ss:Data ss:Type="String">';
							headerRow += colNamesOriginal[colName] + '</ss:Data>\n';
							headerRow += '  </ss:Cell>\n';        
						}
						headerRow += '</ss:Row>\n';    
						return '<?xml version="1.0"?>\n' +
							   '<ss:Workbook xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">\n' +
							   '<ss:Worksheet ss:Name="Sheet1">\n' +
							   '<ss:Table>\n\n' + headerRow;
					};

					emitXmlFooter = function() {
						return '\n</ss:Table>\n' +
							   '</ss:Worksheet>\n' +
							   '</ss:Workbook>\n';
					};

					jsonToSsXml = function (jsonObject) {
						var row;
						var col;
						var xml;
						var data = typeof jsonObject != "object" ? JSON.parse(jsonObject) : jsonObject;
						
						xml = emitXmlHeader();

						for (row = 0; row < data.length; row++) {
							xml += '<ss:Row>\n';
						  
							for (col in data[row]) {
								xml += '  <ss:Cell>\n';
								xml += '    <ss:Data ss:Type="' + testTypes[col]  + '">';
								xml += data[row][col] + '</ss:Data>\n';
								xml += '  </ss:Cell>\n';
							}

							xml += '</ss:Row>\n';
						}
						
						xml += emitXmlFooter();
						return xml;
					};

					download = function (content, filename, contentType) {
						if (!contentType) contentType = 'application/octet-stream';
						var a = document.getElementById('test');
						var blob = new Blob([content], {
							'type': contentType
						});
						
						if (navigator.appName != 'Microsoft Internet Explorer' && navigator.appName != 'Netscape')
						{
							// a.href = window.URL.createObjectURL(blob);
							// a.download = filename;
						}
						else{
							if (navigator.msSaveBlob) { // IE 10+
								navigator.msSaveBlob(blob, filename);
							 }
						}
					};
		
					download(jsonToSsXml(testJson), fileName+'.xls', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');

				}//Ajax success ends

			});

		}//JsontoXLS conversion ends


		var writeHtml =  function(){
			var resData;
			var resStr = '';
			$.ajax( {
				url: "/detectionList"+search_str,
				type: 'GET',
				success:function(resSet){

					var res = resSet.alerts;

					var colNames = ['behavior','room_no','startDate','startTime','priority','ackAt','username','notes','actual_no_of_people','no_of_people'];

					var colNamesOriginal = ['Behavior','Room','Date','Time','Priority','Acknowledged at','Acknowledged by','Follow up action by Officer','Actual No. of People','No. of People'];
					var resStr ='<table border="1" cellspacing="0" cellpadding="1" width="100%">';
					for ( var k = 0; k < colNamesOriginal.length; k++) {
						resStr = resStr + "<th>" + colNamesOriginal[k] + "</th>";
					}
					resStr = resStr + "</tr>"; // Output header with end of line

					for (i = 0; i < res.length; i++) {
						resStr = resStr + "<tr>";
						data = res[i]; // get each row

						for ( var j = 0; j < colNames.length; j++) {
						 var field_data =  data[colNames[j]];
						   if(colNames[j] == 'behavior'){
							field_data =  data['behavior_text'];
						   }
						 resStr = resStr + "<td>" + field_data + "</td>"; // output each Row as	// tab delimited
						}
						resStr = resStr + "</tr>"; // output each row with end of line
					}

					resStr = resStr + "</tr>"; // Output header with end of line
					resStr = resStr + "</table>"; // end of line at the end

					$('#testData').html(resStr);
				  }
				});// ajax ends here
			};

			writeHtml();
		

			$("#detectionListGrid").jqGrid(
            {
				//data: resData,
				datatype: "json",
                url: "/detectionList"+search_str,
                viewrecords: true, // show the current page, data rang and total records on the toolbar
				width: '1903',
				height: 'auto',
				//gridview: true,
				loadonce: true,
				page: 1,
				colNames: ['Behavior','Room','Date','Time','Priority','Acknowledged at','Acknowledged by','Follow up action by Officer','Actual No. of People','No. of People'],
                colModel: [
					{ label: 'Behavior', name: 'behavior', width:290},
                    { label: 'Room', name: 'room_no', width:105 },
                    { label: 'Date',name:'startDate'},
                    { label: 'Time',name:'startTime'},
					{ label: 'Priority', name: 'priority'},
                    { label: 'Acknowledged at', name: 'ackAt', width:200},
                    { label: 'Acknowledged by', name: 'username'},
                    { label: 'Follow up action by Officer', name: 'notes', width:300 },
					{ label: 'Actual No. of People', name: 'actual_no_of_people'  },
                    { label: 'No. of People', name: 'no_of_people'  }
                ],
				jsonReader: { repeatitems:true, root:"alerts" },
				pager:'#detectionListGridPager',
				emptyrecords: "No records found.",
				rowNum:10,
            });

			$("#detectionListGrid").bind("pagechanged", function (event) {
				var args = event.args;
				var pagenumber = args.pagenum;
				var pagesize = args.pagesize;
			});
			$("#detectionListGrid").bind("pagesizechanged", function (event) {
				var args = event.args;
				var pagenumber = args.pagenum;
				var pagesize = args.pagesize;
			});


			var curr_date = new Date();
			var file_name = curr_date.getDate()+'_'+DETECTION.monthArr[curr_date.getMonth()]+'_'+curr_date.getFullYear()+'_'+curr_date.getHours()+'_'+curr_date.getMinutes()+'_'+curr_date.getSeconds();

			$("#excelExport").click(function () {
			   convertToXLS(file_name);
            });
            $("#csvExport").click(function () {
				JSONToCSVConvertor(file_name,true);
            });

			 $("#pdfExport").click(function () {
				var gridHTML = $('#testData').html();
				var gridContent = '';
				gridContent+="<div>Date: "+curr_date.getDate()+' '+DETECTION.monthArr[curr_date.getMonth()]+' '+curr_date.getFullYear()+"</div>";	gridContent+="<div>Printed by: "+$('#loggedInUserName').val()+"</div>";
				gridContent +='<style>body{font-size:25px !important;} table{word-wrap: break-word;font-weight: normal;}  th{font-size:50px !important;word-wrap: break-word;width:auto;font-weight: normal;} td{font-size:50px !important;word-wrap: break-word;width:auto;font-weight: normal;}</style>';
				
				gridContent +=gridHTML;
				gridContent = gridContent.toString();


				var patt = new RegExp('style=.*"',"g");
				gridContent = gridContent.replace(patt,'');

				var replace_digits = new RegExp('.00',"g");
				gridContent = gridContent.replace(replace_digits,'');

				var replace_table = new RegExp('<table',"g");
				gridContent = gridContent.replace(replace_table,'<table style="width:200% !important;"');

		        var doc = new jsPDF('l', 'mm', 'a2');

				// We'll make our own renderer to skip this editor
				specialElementHandlers = {
					// element with id of "bypass" - jQuery style selector
					'#editor': function(element, renderer){
						return true;
					}
				};
								
				margins = {
					top: 10,
					bottom: 10,
					left: 10,
					width: 0
				};

			
				doc.fromHTML(gridContent, 15, 30, {
					'width': 100,
					'elementHandlers': specialElementHandlers
				},
					function (dispose) {
						console.log('dispose ',dispose);
						// dispose: object with X, Y of the last line add to the PDF
						// this allow the insertion of new lines after html
						doc.save(file_name+'.pdf'); 
					},margins);
            });

			

			$("#print").click(function () {

				var gridContent = $('#testData').html();
				
				var replace_digits = new RegExp('.00',"g");
				gridContent = gridContent.replace(replace_digits,'');

                var newWindow = window.open('', '', 'width=800, height=500,resizable=yes,scrollbars=yes'),
                document = newWindow.document.open(),
                pageContent =
                    '<!DOCTYPE html>\n' +
                    '<html>\n' +
                    '<head>\n' +
                    '<meta charset="utf-8" />\n' +
	                '<title>'+'Detection_'+file_name+'</title>\n' +
					'<style>body{font-size:12px !important;} table{border:1px solid;font-size:12px !important;word-wrap: break-word;font-weight: bold;}  th{border:1px solid;font-size:12px !important;word-wrap: break-word;font-weight: normal;} td{border:1px solid;font-size:12px !important;word-wrap: break-word;width:auto;font-weight: normal;}</style>'+
                    '</head>\n' +
                    '<body>\n' + gridContent + '\n</body>\n</html>';
                document.write(pageContent);
                document.close();
                newWindow.print();
            });
		/*** END : JQ Grid Integration *****/

    },
    fnGetUrlVars: function () {
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars;
    },
    fnSearchDet: function () {

        if ($('#frmDetection').valid()) {
            var behavior_type = $('#selBehavior').val();
            var room_no = $('#selRooms').val();
            var det_type = $('#selDetType').val();

            var fromDate = $('#hidFromDate').val();
            var toDate = $('#hidToDate').val();

            var url = '/detection?';
            if (behavior_type != '') {
                url += '&behavior=' + behavior_type;
            }
            if (room_no != '') {
                url += '&room=' + room_no;
            }
            if (det_type != '') {
                url += '&detType=' + det_type;
            }

            if (fromDate != '') {
                url += '&fromDate=' + fromDate;
            }

            if (toDate != '') {
                url += '&toDate=' + toDate;
            }

            var curr_href = $(location).attr('href');
            var url_parts = curr_href.split('detection/');
            window.location = url;
        }
    },
    fnAcknowledge: function (event) {        
        var targetEle = $(this).attr('id');
        var split_id  = targetEle.split('_');
        var alertDet = $.parseJSON($('#hidAlert_'+split_id[1]).val());                
        var alertObject= {
            alert_id: split_id[1],
            priority: alertDet.behavior_id.behavior_level,
            start_datetime: alertDet.start_datetime,                
            actual_no_of_people:  alertDet.actual_no_of_people,
            alert_status: alertDet.alert_status ,
            notes: alertDet.notes,
            room:{
                room_no: alertDet.room_id.room_no,
                no_of_people: alertDet.no_of_people,
                camera: alertDet.room_id.camera_no
            },
            behavior: {
                behavior: alertDet.behavior_id.behavior,
                sop: alertDet.behavior_id.sop
            },
            alert_status: alertDet.alert_status ,
            notes: alertDet.notes,
            zindex:ALERTPOPUP.zindex,
            top:ALERTPOPUP.toppx,
            left:ALERTPOPUP.leftpx
        };  
        ALERTPOPUP.fnGenerateAlertPopup(alertObject);
    }
};
$(document).ready(DETECTION.onReady);