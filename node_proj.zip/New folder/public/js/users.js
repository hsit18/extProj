/**
 * Created by Sandesh.Magdum on 3/16/2015.
 */

window.onload = function(){

    $("#iframe_userdeleteconfirm").contents().find("#btnUsrDelConfirm").click(function(){
        deleteUserHandler({userid:$('#delUserId').val()});
    });

    $("#iframe_userdeleteconfirm").contents().find("#btnUsrDelCancel").click(function(){
        $('#overlay').hide();
        $('#iframe_userdeleteconfirm').hide();
    });

    $('#newUsrCreate').click(function(){
        $('#overlay').show();
        $('#iframe_createuser').show();
    });

    $('[id^="useredit_"]').click(function(){
        $thisId = $(this).attr('id');
        $thisIdOnly = $thisId.replace("useredit_","");
        $('#hidEditUserId').val($thisIdOnly);
        getUserHandler({userId: $thisIdOnly});
    });

    $("#iframe_createuser").contents().find("#userCreateCancel").click(function(){
        $("#iframe_createuser").contents().find('#userName').val('');
        $("#iframe_createuser").contents().find('#userPass').val('');
        $("#iframe_createuser").contents().find('#confUserPass').val('');
        $("#iframe_createuser").contents().find('span.error').remove();
        $("#overlay").hide();
        $("#iframe_createuser").hide();
    });

    $("#iframe_edituser").contents().find("#userEditCancel").click(function(){
        $('#overlay').hide();
        $('#iframe_edituser').hide();
    });

    $("#iframe_edituser").contents().find("#userEditBtn").click(function(){
        editUserHandler({
            userId: $("#hidEditUserId").val(),
            userRole: $("#iframe_edituser").contents().find("#selEditUser").val()
        });
    });

    $("#iframe_createuser").contents().find("#userCreateBtn").click(function(){

        $.validator.addMethod("passwordValidation", function(value, element) {
            return this.optional(element) || value == value.match(/^.*(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[\d])(?=.*[\W_]).*$/);
        }, "Please Enter valid New Password.");

        var $rulesObject = {
            userName: {
                required: true
            },
            userPass: {
                required: true,
                minlength:8,
                passwordValidation: true
            },
            confUserPass: {
                required: true,
                equalTo: $("#iframe_createuser").contents().find('#userPass')
            },
            selUserRole: {
                required: true
            }
        };

        var $messagesObject = {
            userName: {
                required: "Username is required"
            },
            userPass: {
                required: "Password is required",
                minlength : "Password must contain 8 characters."
            },
            confUserPass: {
                required: "Confirm Password is required",
                equalTo : "Does not match with new password!"
            },
            selUserRole: {
                required: "User Role is required"
            }
        };

        $("#iframe_createuser").contents().find("#frmNewUser").validate({
            rules: $rulesObject,
            messages: $messagesObject,
            errorElement: "span",
            errorClass: "error",
            onkeyup: true,
            errorPlacement: function (error, element) {
                error.insertAfter(element);
            },
            invalidHandler: function (form, validator) {

                var errors = validator.numberOfInvalids();
                if (errors) {

                    var message = errors === 1
                        ? 'Please correct the following error:\n'
                        : 'Please correct the following ' + errors + ' errors.\n';
                    var errors = "";

                    for (x = 0; x < validator.errorList.length; x++) {

                        errors += "\n\u25CF " + validator.errorList[x].message + ' ====> ' + validator.errorList[x].element.name;
                    }
                }
                validator.focusInvalid();
                console.log(errors);

            },
            success: function (span) {
                span.remove();
            },
            submitHandler: function(form) {
                var reqObj = {
                    username: $("#iframe_createuser").contents().find('#userName').val(),
                    userrole: $("#iframe_createuser").contents().find('#selUserRole').val(),
                    userpass: $("#iframe_createuser").contents().find('#userPass').val()
                };

                checkUserHandler({
                    userName: $("#iframe_createuser").contents().find('#userName').val()
                }, reqObj);
            }
        });
    });

    $("#deleteuserconfirm").contents().find('#btnUsrDelCancel').on("click", function(){
        $('#overlay').hide();
        $('#iframe_userdeleteconfirm').hide();
    });

    $('span[id^="userdelete"]').on("click", function(){
        $('#overlay').show();
        $('#iframe_userdeleteconfirm').show();
        $thisId = $(this).attr('id');
        $thisValue = $thisId.replace("userdelete_","");
        $('#delUserId').val($thisValue);
    });
};

function deleteUserHandler(reqObj){
    $('#overlay').hide();
    $('#iframe_userdeleteconfirm').hide();
    $.ajax('/deleteuser', {
        type: 'POST',
        data: reqObj,
        success: function(res){
            console.log(res);
            $('#oprUserMsg').show().empty().html(res.message).fadeOut(3000);
            setTimeout(function(){ window.location.reload(true); }, 1000);
        },
        error: function(err){
            console.log(err);
        }
    });
}

function createUserHandler(reqObj){

    $('#overlay').hide();
    $('#iframe_createuser').hide();

    $.ajax('/createuser', {
        type: 'POST',
        data: reqObj,
        success: function(res){
            console.log(res);
            $('#oprUserMsg').show().empty().html(res.message).fadeOut(3000);
            setTimeout(function(){ window.location.reload(true); }, 1000);
        },
        error: function(err){
            console.log(err);
        }
    });
}

function checkUserHandler(reqObj, reqObj1){

    $.ajax('/checkuser', {
        type: 'POST',
        data: reqObj,
        dataType:'json',
        success: function(res){
            if(res.message=='Username available'){
                createUserHandler(reqObj1);
            } else{
                $("#iframe_createuser").contents().find('#usrAvlMsg').show().empty().html(res.message).fadeOut(3000);
                $("#iframe_createuser").contents().find('#usrAvlMsg').addClass('error').removeClass('success');
            }
        },
        error: function(err){
            console.log(err);
        }
    });
}

function getUserHandler(reqObj){
    $.ajax('/getuser', {
        type: 'POST',
        data: reqObj,
        success: function(res){
            console.log(res);
            $("#iframe_edituser").contents().find('#editUserId').val(res.user.username);
            $("#iframe_edituser").contents().find('#editUserId').prop('disabled',true);

            $("#iframe_edituser").contents().find("#selEditUser option").filter(function() {
                return $(this).val() === res.user.role;
            }).prop("selected", true);

            $('#overlay').show();
            $("#iframe_edituser").show();
        },
        error: function(err){
            console.log(err);
        }
    });
}

function editUserHandler(reqObj){
    $.ajax('/edituser', {
        type: 'POST',
        data: reqObj,
        success: function(res){
            console.log(res);
            $('#overlay').hide();
            $('#iframe_edituser').hide();
            $('#oprUserMsg').show().empty().html(res.message).fadeOut(3000);
            setTimeout(function(){ window.location.reload(true); }, 1000);
        },
        error: function(err){
            console.log(err);
        }
    });
}