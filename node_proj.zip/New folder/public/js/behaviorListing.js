
function getChangedBehaviorValue(currentObj){

    var data = JSON.parse($("#behaviorDataDet").val());
    var currentBehavior = $(currentObj).data().value;
    var tempBehavior = currentBehavior;
    var behaviorLevelPresent = 0;

    var behaviorPopup = document.getElementById('behaviorUpdate');
    var popupCloseBtn = document.getElementById('btnConfUpdClose');
    var popupConfirm = document.getElementById('btnConfUpdConfirm');
    var modalOverlay = document.getElementById('overlay');

    $(popupCloseBtn).on('click',function(){
        $(behaviorPopup).hide();
        $(modalOverlay).hide();
        window.location.reload();
    });

    for(var index=0; index < data.length ; index++){
        if(data[index].behavior_level == currentObj.value){

            behaviorLevelPresent++;
            (function(index){
                $(modalOverlay).show();
                $(behaviorPopup).show();
                $(popupConfirm).on('click',function(){

                    data[index].behavior_level = tempBehavior.behavior_level;
                    $.ajax( {
                        url: '/updateBehavior',
                        type: 'POST',
                        data: data[index],
                        success:function(res){
//                            window.location.reload();
                        }
                    });

                    currentBehavior.behavior_level = currentObj.value;
                    $.ajax( {
                        url: '/updateBehavior',
                        type: 'POST',
                        data: currentBehavior,
                        success:function(res){
                        window.location.reload();
                        }
                    });


                });
            }(index));

        }
    }

    if(behaviorLevelPresent == 0){

        console.log("tempBehavior.behavior_level"+tempBehavior.behavior_level);
        console.log("currentBehavior.behavior_level"+currentBehavior.behavior_level);
        console.log("currentObj.value"+currentObj.value);

        currentBehavior.behavior_level = currentObj.value;
        $.ajax( {
            url: '/updateBehavior',
            type: 'POST',
            data: currentBehavior,
            success:function(res){
                window.location.reload();
            }
        });
    }


}

function getChangedSopValue(currentObj){
    var currentBehavior = $(currentObj).data().value;
    currentBehavior.sop = currentObj.value;
    $.ajax( {
        url: '/updateBehavior',
        type: 'POST',
        data: currentBehavior,
        success:function(res){
            window.location.reload();
        }
    });
}

function getChangedCaptionValue(currentObj){
    var currentBehavior = $(currentObj).data().value;
    currentBehavior.caption = currentObj.value;
    $.ajax( {
        url: '/updateBehavior',
        type: 'POST',
        data: currentBehavior,
        success:function(res){
            window.location.reload();
        }
    });
}

$(document).ready(function(){
    var behaviorTable = document.getElementById("pageContainer");
    var behaviourLevelInput = $(".behaviourLevelInput");
    var behaviourLevel = $(".behaviourLevel");

    $(behaviorTable).on("click",function(event){
        behaviourLevelInput.hide();
        behaviourLevel.show();
        var currentClassName = event.target.className.split(" ")[0];
        switch (currentClassName){
            case "editableBehavior":
                $(event.target.children[0]).hide();
                $(event.target.children[1]).show().focus();
                break;
            case "behaviourLevel":
            case "behaviourLevelInput":
                $(event.target.parentElement.children[0]).hide();
                $(event.target.parentElement.children[1]).show().focus();
                break;
            default :
                behaviourLevelInput.hide();
                behaviourLevel.show();


        }
    });



});
