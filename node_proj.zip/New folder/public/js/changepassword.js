$(document).ready(function(){ 
	 
	 $.validator.addMethod("passwordValidation", function(value, element) {
	    return this.optional(element) || value == value.match(/^.*(?=.{8,})(?=.*[a-z])(?=.*[A-Z])(?=.*[\d])(?=.*[\W_]).*$/);
	 }, "Please Enter valid New Password.");

	var validator = $("#resetForm").validate( {
		rules : {
			currentpassword : {
				required : true				
			},
			password : {
				required : true,
				minlength:8,
				passwordValidation: true
			},
			confirmpassword : {
				required : true,
				equalTo: "#password"				
			}  
		},
		messages : {
			password : {
				minlength : "Password must contain 8 characters." 				
			},
			confirmpassword : {
				equalTo : "Does not match with new password!"

			} 
		}, 
		errorElement : "span",
		errorPlacement: function(error, element) {
			if(element.attr("name") == "password") {
				error.insertAfter($(".hint-msg"));		    	
		  	}else{
				error.insertAfter(element);	
			}			
        }    	
	}); 
		
	$('.pass-hint').on('click', function () {
		$('.hint-msg').slideToggle(500);
	});
});