// attach event handlers
var sampleNotifications = [
    "Aggression_39",
    "Aggression_40",
    "Aggression_41",
    "Aggression_42",
    "Aggression_55",
    "Aggression_56",
    "Aggression_57",
    "Aggression_58"
];

function sendAlertLoop(){
    var sendAudioAlert = setInterval(function () {
        var notification = sampleNotifications[Math.floor(Math.random() * sampleNotifications.length)];
        $.ajax({
            url: "/api/audio",
            type: "POST",
            dataType: "json",
            data: {
                "notification": notification
            }
        });
    }, 1000);
}

function sendAlertOnce(){
    var notification = sampleNotifications[Math.floor(Math.random() * sampleNotifications.length)];
    $.ajax({
        url: "/api/audio",
        type: "POST",
        dataType: "json",
        data: {
            "notification": notification
        }
    });
}

window.addEventListener('load', function () {
    sendAlertLoop();
});

// Define console for Internet Explorer
if (!window.console) {
    console = {
        log: function () {
        }
    };
}



