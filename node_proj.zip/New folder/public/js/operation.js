
var OPERATION = {
	onReady: function() {

		ALERTPOPUP.roomsAlertCount = $.parseJSON($("#floorPlanData").attr('rel'));
		OPERATION.monthArr = $.parseJSON($('#hidMonthArr').val());
		//Alerts and Acknowledgements
        $( document ).on( "click", ".ackBtn", OPERATION.fnAcknowledge );
        $( document ).on( "click", ".close-btn", OPERATION.fnClosePopup );
        $( document ).on( "click", "span.cameraplay", OPERATION.fnPlayVideo );
        $( document ).on( "click", "#btnSaveSpeInst", OPERATION.fnConfirmSplInst );
        $( document ).on( "click", ".dialog", OPERATION.fnPopupClick );

		updateAlertLogList();

        var cameraNumber;
        OPERATION.floorPlanNotification();
        cameraNumber=$("span.current-view").attr('camera');
        Load(cameraNumber);
        updateAlertLogList();
	},
 	fnPopupClick:function(){
		$(this).css('z-index', OPERATION.zindex);
	    OPERATION.zindex= OPERATION.zindex+1;
 	},
 	fnPlayVideo: function(e){

 		var thisObject = $(this);
	    if (thisObject.hasClass('clicked')){
	    	//"Double click"
	       thisObject.removeClass('clicked');

	       $("#overlay").show();
	       $("#iframe_people").show();

		   var iframeObj  = $('#iframe_people')[0];

			/** Start : If room sensor is offline, do not allow him to edit no. of people of that room **/
		   $('.cameraplay').each(function(index,Ele){
				var room_no = $(Ele).attr('room');
				var divInside = $(Ele).find('div');
				if($(divInside).hasClass('cross') || $(divInside).hasClass('acknowledgedGrey') ){
					$(iframeObj).contents().find('input[room_no="room_no_'+room_no+'"]').attr('disabled',true);
				}else{
					$(iframeObj).contents().find('input[room_no="room_no_'+room_no+'"]').attr('disabled',false);
				}
		   });
   			/** END : If room sensor is offline, do not allow him to edit no. of people of that room **/

	    }else{
	    	//Just one click!
			thisObject.addClass('clicked');
			setTimeout(function() {
				if (thisObject.hasClass('clicked')){
			    	thisObject.removeClass('clicked');
					if(thisObject.hasClass('current-view') || thisObject.hasClass('cross'))
						return false;
					var cameraNumber=thisObject.attr('camera');
					/*if(cameraNumber > 3 )
						return false;*/
					var roomNumber=thisObject.attr('room');
					$('span.cameraplay').removeClass('current-view')
					thisObject.addClass('current-view')
					$(".dash-head > span").html('Room '+roomNumber);
					Load(cameraNumber);
			 	}
			}, 300);
	    }
	},
	fnUpdatePeople:function(event){
        event.preventDefault();
        var values = {};
        $.each($(this).serializeArray(), function(i, field) {
           values[field.name] = field.value;
        });
        $.ajax( {
            url: '/getpeople',
            type: 'POST',
            data: values,
            success:function(res){
                OPERATION.fnClosePeople();
            }
        });
    },
	fnClosePeople: function(){
        $("#overlay").hide();
        $('#iframe_people').hide();
    }/*,
   	fnGetPeople:function(id){
		$(".people-popup-container").show();
		$("#overlay").show();
	}*/,
	fnValidateSplInstForm : function(){
		$("#frmSpecialInst").validate( {
			rules : {
				txtSplInst : {
					required : true,
					maxlength: 1000
				}
			},
			messages : {
				txtSplInst : {
					required : "Enter your special instructions.",
					maxlength : "Maximum 1000 characters are allowed."
				}
			},
			errorElement : "span"
		});
	},
	fnAcknowledge:  function(event){
		var targetEle =  event.target.id;
		var split_id  = targetEle.split('_');
		var alertDet = $.parseJSON($('#hidAlert_'+split_id[1]).val());
		var alertObject= {
			alert_id: split_id[1],
			priority: alertDet.behavior_id.behavior_level,
			start_datetime: alertDet.start_datetime,
			actual_no_of_people:  alertDet.actual_no_of_people,
			room:{
				room_no: alertDet.room_id.room_no,
				no_of_people: alertDet.no_of_people,
				camera: alertDet.room_id.camera_no
			},
			behavior: {
				behavior: alertDet.behavior_id.behavior,
				sop: alertDet.behavior_id.sop
			},
			alert_status: alertDet.alert_status,
            notes: alertDet.notes,
			zindex:ALERTPOPUP.zindex,
			top:ALERTPOPUP.toppx,
			left:ALERTPOPUP.leftpx
		};
		//console.log(alertObject);

		ALERTPOPUP.fnGenerateAlertPopup(alertObject);
	},
	fnConfirmSplInst: function(){
		OPERATION.fnValidateSplInstForm();
		if($('#txtSplInst').valid()){
			$('#overlay').show();
			$('#iframe_special').show();
		}
	},
	fnSaveSplInst : function(event){
		OPERATION.fnCancelSplInst();
		if($('#txtSplInst').valid()){
			$.post('/submitSplInst',{'note': $('#txtSplInst').val()},function(res){
			$('#splInstUl').html(res); $('#txtSplInst').val('');});
		}
	},
	fnCancelSplInst : function(){
        $('#overlay').hide();
        $('#iframe_special').hide();
    },
	floorPlanNotification: function(){
		socket.on('floorPlan', function (dataObj) {
			var no_of_people = ALERTPOPUP.roomsAlertCount[dataObj.room].nop_th;
			switch(dataObj.action){
				case 'alert':
					$('#room_'+[dataObj.room]+'_people').html(no_of_people);
					var theElement = $('#'+'room_'+dataObj.room+'_camera').find('div');
					if(dataObj.data===1){
						theElement.html('');
						theElement.removeClass().addClass('acknowledged sprite');
					}
				break;
				case 'people':
					$('#room_'+[dataObj.room]+'_people').html(no_of_people);
					var theElement = $('#'+'room_'+dataObj.room+'_people');
					if(dataObj.data===''){
						theElement.html('X');
					}else{
						theElement.html(''+dataObj.data);
					}
				break;
				case 'camera':
					var theElement = $('#'+'room_'+dataObj.room+'_camera').find('div');
					if(dataObj.data===1){
						if(ALERTPOPUP.roomsAlertCount[dataObj.room].count > 0){
							$('#room_'+[dataObj.room]+'_people').html(no_of_people);
							theElement.removeClass().addClass('acknowledged sprite');
							//theElement.html(''+ dataObj.room);
						}else{
							$('#room_'+[dataObj.room]+'_people').html(no_of_people);
							theElement.removeClass().addClass('avail sprite');
							theElement.html(''+ dataObj.room);
						}
					}else{
						$('#room_'+[dataObj.room]+'_people').html('');
						if(ALERTPOPUP.roomsAlertCount[dataObj.room].count > 0){
							theElement.removeClass().addClass('acknowledgedGrey sprite');
							theElement.html('');
						}else{
							theElement.removeClass().addClass('cross sprite');
							theElement.html('');
						}
					}
				break;
			}
		});
	}
};
$( document ).ready( OPERATION.onReady);
