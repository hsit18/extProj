$(document).ready(function(){ 
	 
	 $.validator.addMethod("alpha_numeric", function(value, element) {
	    return this.optional(element) || value == value.match(/^[a-zA-Z0-9_ \b]+$/);
	 }, "Invalid username");

	var validator = $("#loginForm").validate( {
		rules : {
			username : {
				required : true,
				alpha_numeric: true
			},
			password : {
				required : true
			}  
		},
		messages : {
			username : {
				required : "Enter your username." 				
			},
			password : {
				required : "Enter your password."				
			} 
		}, 
		errorElement : "span"	
	});

	$( "#logincancel" ).on( "click", function() {		
		$(".error-msg").remove();
		validator.resetForm();	
	});

	$( ".close-btn" ).on( "click", function() {		
		location.href="/";	
	});
		
});
