/**
 * Created by Sandesh.Magdum on 3/18/2015.
 */

/**
 * Created by Sandesh.Magdum on 3/16/2015.
 */

window.onload = function(){

    var cameraList = sessionStorage.getItem('available_camera_list');
    var splitCamList = cameraList.split(',');

    $.each(splitCamList, function (i, item) {
        $("#iframe_editroom").contents().find('#editRoomCameraNo').append($('<option>', {
            value: item,
            text : item
        }));
    });

    $('[id^="roomedit_"]').click(function(){
        $thisId = $(this).attr('id');
        $thisIdOnly = $thisId.replace("roomedit_","");
        $('#hidEditRoomId').val($thisIdOnly);
        getRoomHandler({roomId: $thisIdOnly});
    });

    $.ajax('/getsetting', {
        type: 'POST',
        data: {settingName:'csvcommonpath'},
        success: function(res){
            console.log(res);
            $('#csvcommonpath').val(res.setting.settingvalue);
        },
        error: function(err){
            console.log(err);
        }
    });

    $("#iframe_editroom").contents().find('#roomEditCancel').click(function(){
        $('#overlay').hide();
        $('#iframe_editroom').hide();
    });

    $('#comPathSaveBtn').click(function(){
        settingSaveHandler({csvCommonPath: $('#csvcommonpath').val()});
    });

    $("#iframe_editroom").contents().find('#btnRoomUpdConfirm').click(function(){
        editRoomHandler({
            roomId: $('#hidEditRoomId').val(),
            cameraNo: $("#iframe_editroom").contents().find('#editRoomCameraNo').val(),
            sensor1: $("#iframe_editroom").contents().find('#editRoomSensor1').val(),
            sensor2: $("#iframe_editroom").contents().find('#editRoomSensor2').val()
        });
    });

    $("#iframe_editroom").contents().find('#btnRoomUpdClose').click(function(){
        $('#overlay').hide();
        $('#roomUpdateConfirm').hide();
        $('#iframe_editroom').hide();
    });

    $("#iframe_editroom").contents().find('#roomEditBtn').click(function(){
        $("#iframe_editroom").contents().find('#roomUpdateConfirm').show();
    });
};

function getRoomHandler(reqObj){
    $.ajax('/getroom', {
        type: 'POST',
        data: reqObj,
        success: function(res){
            console.log(res);
            $("#iframe_editroom").contents().find('#editRoomNumber').val(res.room[0].room_no);
            $("#iframe_editroom").contents().find('#editRoomCameraNo').val(res.room[0].camera_no);
            $("#iframe_editroom").contents().find('#editRoomSensor1').val(res.room[0].sensor1);
            $("#iframe_editroom").contents().find('#editRoomSensor2').val(res.room[0].sensor2);
            $('#overlay').show();
            $('#iframe_editroom').show();
        },
        error: function(err){
            console.log(err);
        }
    });
}

function editRoomHandler(reqObj){

    $("#iframe_editroom").contents().find('#roomUpdateConfirm').hide();
    $('#overlay').hide();
    $('#iframe_editroom').hide();

    $.ajax('/editroom', {
        type: 'POST',
        data: reqObj,
        success: function(res){
            console.log(res);
            $('#roomSaveMsg').show().empty().html(res.message).fadeOut(3000);
            setTimeout(function(){ window.location.reload(true); }, 1000);
        },
        error: function(err){
            console.log(err);
        }
    });
}

function settingSaveHandler(reqObj){
    $.ajax('/settingsave', {
        type: 'POST',
        data: reqObj,
        success: function(res){
            console.log(res);
            $('#settingSaveMsg').show().empty().html(res.message).fadeOut(3000);
        },
        error: function(err){
            console.log(err);
        }
    });
}
