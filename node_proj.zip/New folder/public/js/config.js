window.onload = function(){

	var frmElem = document.getElementById('frm_threshold');
	frmElem.addEventListener('submit', thresholdUpdateHandler);

    $(document).on("click","#frm_threshold_reset", function(){
        resetProbabilities();
    });

    $("#iframe_resetconfig").contents().find('#btnConfUpdClose').on("click", function(){
        $('#overlay').hide();
        $('#iframe_resetconfig').hide();
    });

    $("#iframe_resetconfig").contents().find('#btnConfUpdConfirm').on("click", function(){
        resetProbHandler({cmp_people:0});
    });

    if($('#behavior').find('option:contains("People Count")').length === 0){
        $('#behavior').append($('<option>', {
            value: 'People Count',
            text: 'People Count'
        }));
    }

    $('#behavior').change(function(){
       var selectedBehavior = $('#behavior option:selected').text();
        if(selectedBehavior==='People Count'){
            $('#threshold').prop('disabled',true);
            $('#threshold_div').hide();
            $('#cmp_people_drpdown').prop('disabled',false);
            $('#cmp_people_div').show();
        }
        else{
            $('#threshold').prop('disabled',false);
            $('#threshold_div').show();
            $('#cmp_people_drpdown').prop('disabled',true);
            $('#cmp_people_div').hide();
        }
    });

}

function thresholdUpdateHandler(event){
    var selectedBehavior = $('#behavior option:selected').text();
    if(selectedBehavior=='People Count'){
        var reqObj = {room_id:$('#room').val(),cmp_people:parseInt($('#cmp_people_drpdown').val())};
        console.log(reqObj);
        updatePeopleCount(reqObj);
    }
    else {
        var formData = $(event.target).serializeArray();
        var reqObj = {};
        for(var i =0;i<formData.length;i++){
            reqObj[formData[i].name] = formData[i].value;
        }
        //console.log(reqObj);
        updateBehaviorThreshold(reqObj);
    }
}

function updateBehaviorThreshold(reqObj){
	$.ajax('/config/update', {
		type: 'POST',
		data: reqObj,
		success: function(res){
			console.log(res);
            $('#oprConfigMsg').show().empty().html(res.message).fadeOut(3000);
            setTimeout(function(){ window.location.reload(true); }, 1000);
		},
		error: function(err){
			console.log(err);
		}
	});
}
 function updatePeopleCount(reqObj){
     console.log("reqObj =========> "+reqObj);
     $.ajax('/editRoomCmpPeople', {
         type: 'POST',
         data: reqObj,
         success: function(res){
             console.log(res);
             $('#oprConfigMsg').show().empty().html(res.message).fadeOut(3000);
             setTimeout(function(){ window.location.reload(true); }, 1000);
         },
         error: function(err){
             console.log(err);
         }
     });
 }

function resetProbabilities() {
    $('#overlay').show();
    $('#iframe_resetconfig').show();
}

function resetProbHandler(reqObj){

    $('#overlay').hide();
    $('#iframe_resetconfig').hide();

    $.ajax('/resetProbabilities', {
        type: 'POST',
        data: reqObj,
        success: function(res){
            console.log(res);
            $('#oprConfigMsg').show().empty().html(res.message).fadeOut(3000);
            setTimeout(function(){ window.location.reload(true); }, 1000);
        },
        error: function(err){
            console.log(err);
        }
    });
}