var CameraIndex = -1;
var PlaybackState = 0; //0:No, In live mode; 1: Initialising; 2: other; 3: finished initialisation, stopped; 4: Running playback; 5: Paused
var CurrentDate = new Date();
var AudioPlayerState = 0; //0: Not connected; 1: connecting; 2: connected; 3:playing live; 4: connected: playback; 5: Paused
var audioGuid = "";
var ReplayPermitted = true;
var PlaybackIRPS = 10;
var PlaybackSpeed = 1.0;
var cameraNumber;
var roomNumber;
var ReplayCursor;
var ReplayCursorStop;
var InPlaybackMode = false;
var tempReplayCursor;
var ReplayIncrement;



function Load(camera,room,startTime,endTime)
{
    cameraNumber = camera;

    console.log("Load Called");
    console.log("camera "+camera);
    //Image Viewer init
    engineManager.Init();
    imageViewer.Init();
    imageViewer.SetShowImageHeaderStatus(false, 1, 1, 1);
    imageViewer.SetOnConnectResponseReceivedEventStatus(true);
    imageViewer.SetOnImageReceivedEventStatus(false);
    //AudioPlayer Init
    audioPlayer.Init();
    audioPlayer.SetOnConnectionAttemptCompletedEventStatus(true);
    audioPlayer.SetAutoReconnectStatus(1);

    window.setTimeout(Connect, 1000);

    }

function Connect()
{
    console.log("Connect Called");
    engineManager.SetAuthentication(0);
	var vms_ip = sessionStorage.getItem('vms_server_ip');
	var vms_server_username = sessionStorage.getItem('vms_server_username');
	var vms_server_pwd = sessionStorage.getItem('vms_server_pwd');

    var Url = "http://"+vms_ip+ "/systeminfo.xml"; // XProtect Enterprise Url
    engineManager.QueryEngineAsynchronous(vms_server_username, vms_server_pwd, Url);
    window.setTimeout(CamerasChange, 1000);

    }


var CameraConnectionXml = "";
// Camera selection changed in the combo box
function CamerasChange() {
    console.log("CamerasChange Called");
	//var engineName = "localhost";


	var engineName = sessionStorage.getItem('vms_engine_name');
	var vms_server_username = sessionStorage.getItem('vms_server_username');
	var vms_server_pwd = sessionStorage.getItem('vms_server_pwd');

    var cameraCount = engineManager.GetCameraCount(engineName);
    var availableCameraList = [];
    for(var index = 0; index < cameraCount ;index++){
        (function(){
            if(engineManager.GetCameraName(engineName,index+1) != '' && engineManager.GetCameraName(engineName,index+1) != null){
//                console.log(engineManager.GetCameraName(engineName,index+1));
                if(engineManager.GetCameraCapLive(engineName,engineManager.GetCameraName(engineName,index+1))){
//                    console.log("Available Cameras are ------------------------>"+(index+1));
//                    availableCameraList.push(engineManager.GetCameraName(engineName,index+1));
                    availableCameraList.push(index+1);

                }
            }

        }(index))
    }
    if(availableCameraList.length > 0){
//        console.log(availableCameraList);
        sessionStorage.setItem('available_camera_list', availableCameraList);
    }


    var index = String(cameraNumber);
    var camera = "Camera "+cameraNumber;

    CameraIndex = index;
    var Xml = engineManager.GetCameraConfigurationXml(engineName, camera);
    CameraConnectionXml = Xml;
    imageViewer.SetXmlEncoding(engineManager.GetEncoding());
    imageViewer.ConnectUsingCameraConfigurationXml(vms_server_username, vms_server_pwd, Xml);

    ReplayPermitted = !(engineManager.GetCameraCapBrowse(engineName, camera) == "no");

    //Audio:
    var cameraGuid = engineManager.GetCameraGuid(engineName, CameraIndex - 1);
    audioGuid = engineManager.GetCameraDefaultAudio(engineName, cameraGuid);
    if (audioGuid != "") {
    //var authenticationTypeValue = 0;
    var xmlAudio = engineManager.GetAudioConfigurationXml(engineName, audioGuid);
    if (xmlAudio != "") {
    var res = audioPlayer.ConnectUsingConfigurationXml(vms_server_username, vms_server_pwd, xmlAudio);
    //Check res
    if (res == true) {
    AudioPlayerState = 1;  //Connecting

    }
    }

    }

    }
function AudioOnChange(checked) {
    console.log("AudioOnChange Called");
    console.log(checked);
    console.log("AudioPlayerState"+AudioPlayerState);

    if (checked)
    switch (AudioPlayerState) {
    case 0: //Not initialised. do nothing.
    case 1: //Connecting. wait for the onConnectResponseReceivedFromViewer call
    break;
    case 2: //Connected, but inactive.
    case 3: //In live mode
    case 4: //In playback mode
    if (InPlaybackMode) { //I am going into playback mode
    if ((PlaybackState == 4) && (PlaybackSpeed >= 1.0)) {
    audioPlayer.PlaybackStart(ReplayCursor, 1, PlaybackSpeed);
    AudioPlayerState = 4;
    }
    else //Playback is not ready.
    AudioPlayerState = 5;
    }
    else { //Go live mode
    var res = audioPlayer.LiveStart();
    AudioPlayerState = 3;
    }
    break;
    case 5: // Pause
    break;
    } else
    switch (AudioPlayerState) {
    case 0: //Not initialised. do nothing.
    case 1: //Connecting.
    case 2: //Connected, but inactive.
    break;
    case 3: //In live mode
    audioPlayer.LiveStop();
    break;
    case 4: //In playback mode
    audioPlayer.PlaybackStop();
    break;
    case 5: //Paused.
    break;
    }
    }
function AudiOnChangedUpdate() {
    console.log("AudiOnChangedUpdate Called");
    console.log("AudioOnCheckbox.checked"+AudioOnCheckbox.checked);
    AudioOnChange(AudioOnCheckbox.checked);
    }

// Event handler for connection to camera succeeded/failed
function onConnectResponseReceivedFromViewer(connectionGranted) {
    console.log("onConnectResponseReceivedFromViewer Called");
    imageViewer.LiveStart();
    AudioPlayerState = 2;
    window.setTimeout(AudiOnChangedUpdate, 100);

    }
function onConnectResponseReceivedFromViewer(connectionGranted) {
    console.log("onConnectResponseReceivedFromViewer Called");
    //start live feed if connection was granted
    if (connectionGranted) {
    IsConnected = true;
    if (!InPlaybackMode) {
    imageViewer.LiveStart();
    } else {
    // Enable playback controls
    }
    AudioPlayerState = 2;
    //                AudioOnChange(AudioOnCheckbox.checked);
    window.setTimeout(AudiOnChangedUpdate, 100);
    } else {
    IsConnected = false;
    AudioPlayerState = 0;
    PlaybackState = 0;
    }
    }
function onConnectionAttemptCompleted(result) {
    console.log("onConnectionAttemptCompleted Called");
    }

function onEngineManagerLoginTokenChanged(sToken) {
    console.log("onEngineManagerLoginTokenChanged Called");
    }

function onImageReceived(timestamp) {
    console.log("onImageReceived Called");
    imageViewer.SetOnImageReceivedEventStatus(0);
    }
