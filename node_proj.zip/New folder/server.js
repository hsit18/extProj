// Dependencies
var express = require('express');
var session = require('express-session');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var seeder = require('./helpers/Seeder');
var path = require('path');
var passport = require('passport');
var app = express();
var server = require('http').Server(app);
var io = require('socket.io')(server);
var router = require('./routes');
var routeruser = require('./routes/user');
var paginate = require('express-paginate');
var routerdetection = require('./routes/detection');
var routerconfig = require('./routes/config');
var routerroom = require('./routes/rooms');
var routersetting = require('./routes/settings');
var routerbehavior = require('./routes/behaviors');
var routerplayback = require('./routes/playback');
var csvWriter = require('./routes/csvwriter');
var CONSTANT = require('./utilities/Constant').CONSTANTS;
//var zip = require('express-zip');
//var wsnotification = require('./helpers/notifications').createWsNotification;
//var brodcastWsNotification = require('./helpers/notifications').brodcastWsNotification;

global.monthArr = new Array('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec');

global.io = io;
app.locals.inspect = require('util').inspect;
module.exports = app;

server.listen(4000);

app.use(session({
    secret: '84uw9qrjg93y2tq9hr9eh43qhfre9f7h3478ffkdsjgklhm4i493tudf',
    saveUninitialized: true,
    resave: true,
    cookie:{maxAge:604800000} /* 1 week 604800000 */ /* For testing : 2 min : 100000 */
}));

var userController = require('./controllers/User/UserController').UserController;

// EJS Template 
app.set('view engine', 'ejs');

// MongoDB 
var connection = mongoose.connect('mongodb://localhost/visualdb');

mongoose.connection.on('open', function () {
    seeder.populateDB;
    seeder.populateDB.wireToDB().done(function (mesg) {
        //console.log(mesg);
        //console.log("CSV PATH ========> " + CONSTANT.CSV_PATH);
        var csvControllerObject = require('./controllers/csv/CSVReadController').CSVReader;
        csvControllerObject.initialize();
    });
});

// Express
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// keep this before all routes that will use pagination
app.use(paginate.middleware(5, 50));

// Configuring Passport
app.use(passport.initialize());
app.use(passport.session());

var flash = require('connect-flash');
app.use(flash());

var initPassport = require('./passport/init');
initPassport(passport);


var loggedIn = function (req, res, next) {
    if (req.user) {
        next();
    } else {
        res.redirect('/login');
    }
};

var checkAdmin = function (req, res, next) {
    if (req.user) {
		//console.log(' user role',req.user.role);
        if (req.url == '/config' && (req.user.role == 'admin' || req.user.role == 'superadmin')) {
            next();
        } else {
            res.redirect('/operation');
        }
    } else {
        res.redirect('/login');
    }
};

var checkSuperAdmin = function (req, res, next) {
    if (req.user) {
        if ((req.url == '/rooms' || req.url == '/behaviors' || req.url == '/users') && (req.user.role == 'superadmin' || req.user.role == 'admin')) {
			if(req.user.role == 'superadmin'){
	            next();
			}
			else if(req.user.role == 'admin' && req.url != '/users'){
				res.redirect('/operation');
			}else{
	            next();
			}
        } else {
            res.redirect('/operation');
        }
    } else {
        res.redirect('/login');
    }
};

var firstTime = function (req, res, next) {
    if (req.user.first_time_login === 1) {
        res.redirect('/changepassword');
    } else {
        next();
    }
};

//Login and Change password page
app.get('/', loggedIn, firstTime, router.operation);
app.get('/login', routeruser.login);
app.get('/logout', routeruser.logout);
app.get('/changepassword', loggedIn, routeruser.changepassword);
app.post('/reset', routeruser.resetpassword);
app.post('/loginprocess', routeruser.loginprocess);

//Operation Page
app.get('/operation', loggedIn, firstTime, router.operation);
app.post('/getpeople', router.getpeople);
app.post('/submitAcknowledement', router.submitAcknowledement);
app.post('/submitSplInst', router.submitSplInst);
app.get('/showpeople', router.showpeople);
app.get('/spclinsonfm', router.specialInstructionConfirm);
app.post('/getLatestAlertLogs',router.getLatestAlertLogs);

//Detection page
app.get('/detection', loggedIn, firstTime, routerdetection.detection);
//Detection page : for Jq Grid
app.get('/detectionList', loggedIn, firstTime, routerdetection.detectionList);


//Config page
app.get('/config', checkAdmin, firstTime, routerconfig.config);
app.get('/resetconfigconfirm', routerconfig.configResetConfirm);
app.post('/config/update', routerconfig.updateConfig);
app.post('/editRoomCmpPeople', router.editRoomCmpPeople);
app.post('/resetProbabilities', router.resetProbabilities);

// Audio
app.get('/api/audio', router.audio);

// Disrupt System
app.get('/api/disruptsystem', router.disruptsystem);

//Live/Playback page
app.get('/playback', loggedIn, firstTime, routerplayback.playback);

//CSVWriter
app.get('/csvwriter', loggedIn, firstTime, csvWriter.csvwriter);

//User Page
app.get('/users', checkSuperAdmin, firstTime, routeruser.users);
app.post('/deleteuser', loggedIn, firstTime, routeruser.deleteuser);
app.post('/createuser', loggedIn, firstTime, routeruser.createuser);
app.post('/checkuser', loggedIn, firstTime, routeruser.checkuser);
app.post('/getuser', loggedIn, firstTime, routeruser.getuser);
app.post('/edituser', loggedIn, firstTime, routeruser.edituser);
app.get('/deleteuserconfirm', routeruser.userDeleteConfirm);
app.get('/createusermodal', routeruser.userCreateModal);
app.get('/editusermodal', routeruser.userEditModal);

//Room Page
app.get('/rooms', checkSuperAdmin, firstTime, routerroom.rooms);
app.post('/getroom', loggedIn, firstTime, routerroom.getroom);
app.post('/editroom', loggedIn, firstTime, routerroom.editroom);
app.get('/editroommodal', routerroom.roomEditModal);

//Behavior Page
app.get('/behaviors', checkSuperAdmin, firstTime, routerbehavior.behaviors);
app.post('/updateBehavior', router.updateBehavior);

//Settings
app.post('/settingsave', loggedIn, routersetting.editsetting);
app.post('/getsetting', loggedIn, routersetting.getsetting);

/*
 app.get('/exportzip', function(req, res) {
 res.zip([
 { path: 'C:\\Temp\\export_‎12‎_‎08‎_‎34‎PM.avi', name: 'export_‎12‎_‎08‎_‎34‎PM.avi' },
 { path: 'C:\\Temp\\export_‎12‎_‎11‎_‎35‎PM.avi', name: 'export_‎12‎_‎11‎_‎35‎PM.avi' }
 ],'export_date_string.zip');
 });
 */


/* Note: This method will send notification only once! */
//wsnotification('sampleNotify',{status:'Ok',message:'Hello World'});
/* Caution: The method below will continuously send notifications with defined frequency as last parameter!!
 *  To check the implementation @ client side, uncomment listeners in views/header.ejs file.
 * */

//brodcastWsNotification('broadcast',{status:'Ok',message:'Mismatch in people count in room 58!!!'},6000);
console.log('Server listening on port 4000....');