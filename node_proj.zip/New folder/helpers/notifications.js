/**
 * Created by Sandesh.Magdum on 2/6/2015.
 */
exports.createWsNotification = function (notificationName, notificationData) {
    io.emit(notificationName, notificationData);
};

exports.brodcastWsNotification = function (notificationName, notificationData, broadcastFrequency) {
    var sendingMsg = setInterval(function () {
        io.emit(notificationName, notificationData);
    }, broadcastFrequency);
};