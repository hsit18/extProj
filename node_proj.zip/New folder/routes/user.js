﻿var async = require("async");
var passport = require('passport');
var bCrypt = require('bcrypt-nodejs');
var CONSTANT = require('../utilities/Constant').CONSTANTS;

module.exports.login = function (req, res) {
    res.render('login', {message: req.flash('loginMessage'), pagetitle: 'Login', passchange: req.flash('passchange')});
};

module.exports.logout = function (req, res) {
    req.logout();
    res.redirect('/');
};

module.exports.loginprocess = passport.authenticate('login', {
    successRedirect: '/operation',
    failureRedirect: '/login',
    failureFlash: 'Invalid username or password.'
});

module.exports.changepassword = function (req, res) {
    res.render('changepassword', {pagetitle: 'Change Password', message: ''});
};

module.exports.resetpassword = function (req, res) {
    if (bCrypt.compareSync(req.body.currentpassword, req.user.password)) {
        if (req.body.password === req.body.confirmpassword) {
            var user_id = req.user._id;
            var updateUser = {
                password: bCrypt.hashSync(req.body.password, bCrypt.genSaltSync(8), null),
                first_time_login: 0
            };
            var status;
            UserController = require('../controllers/User/UserController').UserController;

            if(req.body.currentpassword!=req.body.password){
                UserController.editUser(user_id, updateUser).done(function () {
                    req.logout();
                    req.flash('passchange', 'Password changed successfully. Please login to continue.');
                    res.redirect('/login');
                });
            } else {
                res.render('changepassword', {pagetitle: 'Change Password', message: 'New password could not be the same as old password!'});
            }
        } else {
            res.render('changepassword', {pagetitle: 'Change Password', message: 'Does not math with new password!'});
        }

    } else {
        res.render('changepassword', {pagetitle: 'Change Password', message: 'Current password is incorrect'});
    }
};


module.exports.deleteuser = function (req, res) {
    var user_id = req.body.userid;
    var updateUserStatus = {
        status: 'inactive'
    };

    if (req.user._id != user_id) {
        userController = require('../controllers/User/UserController').UserController;
        userController.editUser(user_id, updateUserStatus).done(function (users) {
            res.json({
                user: users,
                message: 'User deleted successfully.'
            });
        });
    }
};

module.exports.userDeleteConfirm = function (req, res) {
    res.render('userdelete_confirm');
};

module.exports.userCreateModal = function (req, res) {
    res.render('usercreate');
};

module.exports.userEditModal = function (req, res) {
    res.render('useredit');
};

module.exports.createuser = function (req, res) {
    var userName = req.body.username;
    var userPass = req.body.userpass;
    var userPassEnc = bCrypt.hashSync(userPass, bCrypt.genSaltSync(8), null);
    var userRole = req.body.userrole;

    var createUser = {
        username: userName,
        password: userPassEnc,
        role: userRole,
        status: 'active',
        first_time_login: 1,
        modified_by: req.user.username,
        modified_at: new Date()
    };

    var userController = require('../controllers/User/UserController').UserController;

    userController.getUserByName(userName).done(function (user) {
        if (!user) {
            userController.addUser(createUser).done(function (user) {
                res.json({
                    message: 'User created successfully.'
                });
            });
        } else {
            res.json({
                message: 'Username exists'
            });
        }
    });
};

module.exports.checkuser = function (req, res) {
    var userName = req.body.userName;

    var userController = require('../controllers/User/UserController').UserController;
    userController.getUserByName(userName).done(function (users) {
        var result = null;
        //console.log(users[0]);
        if (users == undefined) {
            result = "Username available";
        } else {
            result = "Username exists!";
        }
        res.json({
            message: result
        });
    });
};

module.exports.getuser = function (req, res) {
    var userId = req.body.userId;

    var userController = require('../controllers/User/UserController').UserController;
    userController.getUserById(userId).done(function (user) {
        res.json({
            user: user
        });
    });
};

module.exports.edituser = function (req, res) {
    var userId = req.body.userId;
    var userRole = req.body.userRole;

    var editUser = {
        role: userRole,
        modified_by: req.user.username,
        modified_at: new Date()
    };

    var userController = require('../controllers/User/UserController').UserController;
    userController.editUser(userId,editUser).done(function (user) {
        res.json({
            user: user,
            message: 'User updated successfully.'
        });
    });
};

module.exports.users = function (req, res) {
    var locals = {};
    locals.LoggedInUser = req.user;
    if (req.user.role == 'superadmin' || req.user.role=='admin') {
        locals.hdrCls = 'super-header';
    } else {
        locals.hdrCls = 'header';
    }
    locals.activeTab = 'users';
    locals.prioThreshold = CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD;
    var usersMap = [];

    var userController = require('../controllers/User/UserController').UserController;
    var jsonObj = '';
    async.parallel([
        function (callback) {
            userController.getAllUsers(req.user._id).done(function (users) {
                for (var i = 0; i < users.length; i++) {
                    usersMap.push({userid: users[i]._id, username: users[i].username, role: users[i].role});
                }
                locals.users = usersMap;
                jsonObj = {
                    object: 'list',
                    data: usersMap
                };
                callback();
                //res.render('user', locals);
            })
        }], function (err) {
        if (err) return next(err);
        res.format({
            html: function () {
                //console.log(locals);
                res.render('user', locals);
            },
            json: function () {
                res.json(jsonObj);
            }
        });
    });
};