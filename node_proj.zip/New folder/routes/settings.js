/**
 * Created by Sandesh.Magdum on 3/19/2015.
 */

var async = require("async");
var passport = require('passport');
var CONSTANT = require('../utilities/Constant').CONSTANTS;

module.exports.getsetting = function (req, res) {
    var settingName = req.body.settingName;

    var settingController = require('../controllers/Settings/SettingsController').SettingController;
    settingController.getSettingByName(settingName).done(function (setting) {
        res.json({
            setting: setting
        });
    });
};

module.exports.editsetting = function (req, res) {

    var settingController = require('../controllers/Settings/SettingsController').SettingController;

    settingController.getSettingByName('csvcommonpath').done(function (setting) {
        var settingValue = req.body.csvCommonPath;

        if(setting!=undefined){
            var settingId = setting._id;

            var editSetting = {
                settigname: 'csvcommonpath',
                settingvalue: settingValue,
                status: 'active',
                modified_by: req.user.username,
                modified_at: new Date()
            };

            settingController.editSettingById(settingId,editSetting).done(function (setting) {
                var message = 'Setting with csvcommonpath updated successfully!';
                console.log(message);
                res.json({
                    message: 'Common path for CSV\'s updated successfully.'
                });
            });

        }else {
            console.log('Setting with csvcommonpath not found!');
            console.log('Inserting setting with name csvcommonpath.');

            settingController.addSetting({
                'settingname':'csvcommonpath',
                'settingvalue':settingValue,
                modified_by: req.user.username,
                modified_at: new Date(),
                status: 'active'
            }).done(function (setting) {
                var message = 'Setting csvcommonpath added with insertion id: '+ setting._id;
                console.log(message);
                res.json({
                    message: 'Common path for CSV\'s updated successfully.'
                });
            });
        }
    });
};

module.exports.settings = function (req, res) {
    var locals = {};
    locals.LoggedInUser = req.user;
    if (req.user.role == 'superadmin' || req.user.role=='admin') {
        locals.hdrCls = 'super-header';
    } else {
        locals.hdrCls = 'header';
    }
    locals.activeTab = 'rooms';
    locals.prioThreshold = CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD;
    var settingsMap = [];

    var settingController = require('../controllers/Settings/SettingsController').SettingController;
    var jsonObj = '';
    async.parallel([
        function (callback) {
            settingController.getAllSettings().done(function (settings) {
                for (var i = 0; i < settings.length; i++) {
                    //usersMap[String(users[i]._id)] = {username: users[i].username, userrole: users[i].role};
                    settingsMap.push({settingid: settings[i]._id, settingname: settings[i].settingname, settingvalue: settings[i].settingvalue});
                }
                locals.settings = settingsMap;
                jsonObj = {
                    object: 'list',
                    data: settingsMap
                };
                callback();
                //res.render('user', locals);
            })
        }], function (err) {
        if (err) return next(err);
        res.format({
            html: function () {
                //console.log(locals);
                res.render('rooms', locals);
            },
            json: function () {
                res.json(jsonObj);
            }
        });
    });
};