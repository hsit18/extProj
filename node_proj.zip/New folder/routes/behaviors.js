/**
 * Created by Sandesh.Magdum on 3/16/2015.
 */

var async = require("async");
var CONSTANT = require('../utilities/Constant').CONSTANTS;
var behaviorController = require('../controllers/Behavior/BehaviorController').BehaviorController;

module.exports.behaviors = function (req, res) {
    var locals = {};
    locals.LoggedInUser = req.user;
    locals.activeTab = 'behaviors';

    if(req.user.role=='superadmin' || req.user.role=='admin'){
        locals.hdrCls = 'super-header';
    } else {
        locals.hdrCls = 'header';
    }
    locals.prioThreshold = CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD;

    behaviorController.getAllBehaviors().done(function(behavior){
        locals.behavior = behavior;
        res.render('behaviors', locals);
    });



};