var async = require("async");
var CONSTANT = require('../utilities/Constant').CONSTANTS;
module.exports.detection = function (req, res) {
	req.accepts(['html', 'jsonp']);
	
	var locals = {};
	locals.LoggedInUser = req.user;
	locals.activeTab = 'detection';

    if(req.user.role=='superadmin' || req.user.role=='admin'){
        locals.hdrCls = 'super-header';
    } else {
        locals.hdrCls = 'header';
    }

	locals.prioThreshold = CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD;
	var jsonObj ={};
	/*console.log(req);
	console.log(' PAGE '+req.query.page);
	console.log(' LIMIT '+req.query.limit);*/

	   async.parallel([
        
	   //Load behavior
        function(callback) {
			behaviorController = require('../controllers/Behavior/BehaviorController').BehaviorController;
			behaviorController.getAllBehaviors().done(function (behavior) {
				//if (err) return callback(err);
				locals.behavior = behavior;
				jsonObj.behavior= behavior;
				callback();
			});
        },
        //Load Rooms data
        function(callback) {
			roomController = require('../controllers/Rooms/RoomsController').RoomsController;
			roomController.getAllRoom().done(function (rooms) {
				locals.rooms = rooms;
				jsonObj.rooms= rooms;

				callback();
			});			 
        },
		function(callback){
			
			alertLogController = require('../controllers/AlertLog/AlertLogController').AlertLogController;
			
			alertLogController.getAllAlertLog().done(function (alerts) {
                
				  locals.alerts = alerts;
				  //locals.pageCount = alertData.pageCount;
				  //locals.itemCount = alertData.itemCount;
				  locals.LoggedInUser = locals.LoggedInUser;
				  locals.activeTab = locals.activeTab;

				  jsonObj.object= 'list';
				  jsonObj.data= alerts;
	              callback();
            });
			
			//Paginate code commented
			/*
			alertLogController.getAllAlertLogPaginate(req.query.page,req.query.limit,req.query.sort,req.query.behavior,req.query.room,req.query.detType,req.query.fromDate,req.query.toDate).done(function (alertData) {
				//locals.alerts = alerts;
				console.log(alertData.pageCount);

				  locals.alerts = alertData.alerts;
				  locals.pageCount = alertData.pageCount;
				  locals.itemCount = alertData.itemCount;
				  locals.LoggedInUser = locals.LoggedInUser;
				  locals.activeTab = locals.activeTab;

				  jsonObj = {
					  object: 'list',
					  //has_more: paginate.hasNextPages(req)(alertData.pageCount),
					  data: alertData.alerts
					}
					callback();
			}); */
		}

    ], function(err) { //This function gets called after the two tasks have called their "task callbacks"
        if (err) return next(err); //If an error occured, we let express/connect handle it by calling the "next" function
        //Here locals will be populated with 'Alert Logs' and 'Occurrence Notes'
			//res.render('index',locals);

				res.format({
					  html: function() {
						res.render('detection', locals);
					  },
					  json: function() {
						// inspired by Stripe's API response for list objects
						//console.log(jsonObj);
						res.json(jsonObj);
					  }
					});
			
    });

}



module.exports.detectionList = function (req, res) {
	//console.log(req);
	var locals = {};
	 var monthArr = global.monthArr;

	alertLogController = require('../controllers/AlertLog/AlertLogController').AlertLogController;
	alertLogController.getDetectionAlertLog(req.query.behavior,req.query.room,req.query.detType,req.query.fromDate,req.query.toDate).done(function (alerts) {
		
		var formattedJsonArr = [];
		for(i=0;i<alerts.length;i++){
			var formattedJson= {};

			/*
			for (var prop in alerts[i]) {
				//console.log(typeof alerts[i][prop]);
				if ((typeof alerts[i][prop] === 'string' || typeof alerts[i][prop] === 'number') && alerts[i].hasOwnProperty(prop))
				{
					if(prop!= 'room_id' && prop!= 'behavior_id'){
						//formattedJsonObj[prop] = alerts[i][prop];
					}
				}
			}*/

			/****  Ack Date Fomatting ****/
			
				var ackDate = ackTime = '';
				if (alerts[i].acknowleged_datetime != '' && typeof(alerts[i].acknowleged_datetime) !== undefined && alerts[i].acknowleged_datetime !== null) {
					var ackdateObj = new Date(alerts[i].acknowleged_datetime);
					ackDate = ackdateObj.getDate() + '-' + monthArr[ackdateObj.getMonth()] + '-' + ackdateObj.getFullYear();
					ackTime = ackdateObj.getHours() + ':' + ackdateObj.getMinutes() + ':' + ackdateObj.getSeconds();
				}

				var ackAt = '';

				if(ackDate != ''){
					ackAt = ackDate+' | '+ackTime;
				}
				formattedJson['ackAt'] = ackAt;
			/****  Ack Date Fomatting ****/

			/***  user name formatting *****/

				var username = '';
				if (alerts[i].acknowleged_by && typeof(alerts[i].acknowleged_by.username) !== 'undefined') {
					username = alerts[i].acknowleged_by.username;
				}

				formattedJson['username'] = username;
			/**** user name formatting ****/


			/***  Behavior formatting *****/

			  //console.log(' oimg gfile '+alerts[i]);

				formattedJson['behavior'] = "<input type='hidden' name='hidAlert_"+alerts[i]._id+"'  id='hidAlert_"+alerts[i]._id+"' value='"+JSON.stringify(alerts[i])+"'><a href='javascript:;' class='ackBtn' id='alertId_"+alerts[i]._id+"' data-id='"+alerts[i]._id+"'>&nbsp; <span>"+alerts[i].behavior_id.behavior+"</span>&nbsp;<span class='sprite "+alerts[i].behavior_id.img_file+"'></span></a>";
				
			/**** Behavior formatting ****/


			/***  Start Time  formatting *****/
				var dateObj = new Date(alerts[i].start_datetime);
				//console.log(monthArr);
				//console.log(dateObj.getMonth());
				var startDate = dateObj.getDate() + '-' + monthArr[dateObj.getMonth()] + '-' + dateObj.getFullYear();
				var startTime = dateObj.getHours() + ':' + dateObj.getMinutes() + ':' + dateObj.getSeconds();

				formattedJson['startTime'] = startTime;
				formattedJson['startDate'] = startDate;

			/**** Start Time  formatting ****/


			/***  Priority  formatting *****/ 

				var priority = 'Low';
				if (alerts[i].priority < CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD) {
					priority = 'High';
				}
				else if (alerts[i].priority == 100) {
					priority = 'Medium';
				}

				formattedJson['priority'] = priority;
			/***  Priority  formatting *****/

			  formattedJson['_id'] = alerts[i]._id;
			  formattedJson['sensor_name'] = alerts[i].sensor_name;
			  formattedJson['alert_status'] = alerts[i].alert_status;
			  formattedJson['start_datetime'] = alerts[i].start_datetime;
			  formattedJson['end_datetime'] = alerts[i].end_datetime;
			  formattedJson['acknowleged_datetime'] = alerts[i].acknowleged_datetime;
			  formattedJson['acknowleged_by'] = alerts[i].acknowleged_by;
			  //formattedJson['priority = alerts[i].priority;
			  formattedJson['confidence_value'] = alerts[i].confidence_value;
			  formattedJson['notes'] = alerts[i].notes;
			  formattedJson['actual_no_of_people'] = alerts[i].actual_no_of_people;
			  formattedJson['no_of_people'] = alerts[i].no_of_people;
			  formattedJson['room_id'] = alerts[i].room_id._id;
  			  formattedJson['room_no'] = alerts[i].room_id.room_no;
  			  formattedJson['camera_no'] = alerts[i].room_id.camera_no;
  			  formattedJson['sensor1'] = alerts[i].room_id.sensor1;
   			  formattedJson['behavior_text'] = alerts[i].behavior_id.behavior;
			  
		
			formattedJsonArr.push(formattedJson);
		}
		//console.log(formattedJsonArr); 
		locals.alerts = formattedJsonArr;
			  
		res.format({
		  json: function() {
			res.json(locals);
		  }
		});
	});

};