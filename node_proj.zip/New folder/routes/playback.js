var CONSTANT = require('../utilities/Constant').CONSTANTS;
module.exports.playback = function (req, res) {
	var locals = {};
	locals.LoggedInUser = req.user;
	locals.activeTab = 'playback';

    if(req.user.role=='superadmin' || req.user.role=='admin'){
        locals.hdrCls = 'super-header';
    } else {
        locals.hdrCls = 'header';
    }

	locals.prioThreshold = CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD;	

	 roomController = require('../controllers/Rooms/RoomsController').RoomsController;
            roomController.getAllRoom().done(function (rooms) {
//				console.log(rooms);
                locals.rooms = rooms;
				res.render('playback',locals);
            });

 	
}