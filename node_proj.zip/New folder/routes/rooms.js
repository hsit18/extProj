/**
 * Created by Sandesh.Magdum on 3/16/2015.
 */

var async = require("async");
var CONSTANT = require('../utilities/Constant').CONSTANTS;

module.exports.getroom = function (req, res) {
    var roomId = req.body.roomId;

    var roomController = require('../controllers/Rooms/RoomsController').RoomsController;
    roomController.getRoomById(roomId).done(function (room) {
        res.json({
            room: room
        });
    });
};

module.exports.editroom = function (req, res) {
    var roomId = req.body.roomId;
    var cameraNo = req.body.cameraNo;
    var sensor1 = req.body.sensor1;
    var sensor2 = req.body.sensor2;

    var editRoom = {
        camera_no: cameraNo,
        sensor1: sensor1,
        sensor2: sensor2
    };

    var roomController = require('../controllers/Rooms/RoomsController').RoomsController;
    roomController.editRoom(roomId,editRoom).done(function (room) {
        res.json({
            room: room,
            message: 'Room updated successfully.'
        });
    });
};

module.exports.rooms = function (req, res) {
    var locals = {};
    locals.LoggedInUser = req.user;
    locals.activeTab = 'rooms';

    if(req.user.role=='superadmin' || req.user.role=='admin'){
        locals.hdrCls = 'super-header';
    } else {
        locals.hdrCls = 'header';
    }

    locals.prioThreshold = CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD;
    var roomsMap = [];

    var roomController = require('../controllers/Rooms/RoomsController').RoomsController;
    var jsonObj = '';
    async.parallel([
        function (callback) {
            roomController.getAllRoom().done(function (rooms) {
                for (var i = 0; i < rooms.length; i++) {
                    roomsMap.push({
                        roomid: rooms[i]._id,
                        roomnumber: rooms[i].room_no,
                        camerano: rooms[i].camera_no,
                        sensor1: rooms[i].sensor1,
                        sensor2: rooms[i].sensor2
                    });
                }
                locals.rooms = roomsMap;
                jsonObj = {
                    object: 'list',
                    data: roomsMap
                };
                callback();
                //res.render('user', locals);
            })
        }], function (err) {
        if (err) return next(err);
        res.format({
            html: function () {
                //console.log(locals);
                res.render('rooms', locals);
            },
            json: function () {
                res.json(jsonObj);
            }
        });
    });
};

module.exports.roomEditModal = function (req, res) {
    res.render('roomedit');
};
