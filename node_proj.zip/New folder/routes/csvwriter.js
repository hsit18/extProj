module.exports.csvwriter = function (req, res) {
var csv = require('csv');
var fs = require('fs');
var allCSVS = {};
stringify = require('csv-stringify');
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

function random (low, high) {
    return Math.random() * (high - low) + low;
}

function getRandomRecords(){
	var streamData=[];

	for(i=1;i<=1;i++){
		var curr_date = dd+'-'+mm+'-'+yyyy;
		var curr_time = today.getHours()+':'+today.getMinutes()+':'+today.getSeconds()+'.'+today.getMilliseconds();
		streamData[i] = new Array(curr_date,curr_time,1,128);
		var temp_arr = [];
		var fixedPos = getRandomInt(1,16);
		for(j=1;j<=14;j++){
			if(fixedPos == j){
				streamData[i].push(random(0.401,1.000).toFixed(3));
			}else{
				streamData[i].push(0);
			}
		}
	}
	return streamData;
}
	
	function updateCSVData(){
		for(p=9;p<=10;p++){
			var fileObj = fs.createWriteStream("csv/csv"+p+".csv", {'flags': 'a'});
			console.log("csv/csv"+p+".csv");
			var input = getRandomRecords();
			
			fnWriteFile(input,"csv/csv"+p+".csv");
			function fnWriteFile(input,filePath){
				stringify(input,{delimiter: ';'}, function(err, output){
						var wstream = fs.createWriteStream(filePath,{ flags: 'a+',encoding: null,fd: null,mode: 0666 });
						wstream.on('finish', function () {
						  console.log('file has been written '+filePath);
						  
						});
						wstream.write(output);
						wstream.end();
				}); 
			}//function fnWriteFile ends here
		}
		//document.write('file has been written'+filePath);
	}//function updateCSVData ends here

	var csvInterval = setInterval(function(){
		updateCSVData();
	}, 1000);
	
	/*setTimeout(function(){
		clearInterval(csvInterval);
	}, 30000);*/
}