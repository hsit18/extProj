var async = require("async");
var parse = require('csv-parse');
var fs = require("fs");
var Promise = require('promise');
var wsnotification = require('../helpers/notifications');
var CONSTANT = require('../utilities/Constant').CONSTANTS;
module.exports.home = function (req, res) {
    res.render('index');
};

module.exports.audio = function (req, res) {
    var audioAlertLogController = require('../controllers/audio/audioAlertLogController').audioAlertLogController;
    var roomController = require('../controllers/rooms/RoomsController').RoomsController;
    var notification = req.query.notification;
    console.log(" notification =========> " + notification);
    if (notification !== null && notification !== undefined && notification.length > 0) {
        var notificationSplit = notification.split("_");
        var notificationWithRoomNo = notificationSplit[1];

        var curDate = new Date();
        var year = curDate.getFullYear();
        var month = curDate.getMonth();
        var date = curDate.getDate();
        var hour = curDate.getHours();
        var minute = curDate.getMinutes();
        var second = curDate.getSeconds();
        var roomMessage = "room no=" + notificationWithRoomNo;
        var ctsMessage = "timestamp=" + curDate;
        //console.log(roomMessage);
        //console.log(ctsMessage);
        roomController.getRoomIdByRoomNumber(notificationWithRoomNo).done(function (room) {
            if (room[0]) {
                getNumberOfpeopleFromCSV(room[0].sensor1, room[0].sensor2).done(function (actualNoOfPeople) {
                    audioAlertLogController.audioAlert(notificationWithRoomNo).done(function (fightDetected) {
                        //console.log("fightDetected="+fightDetected);
                        var behaviorController = require('../controllers/behavior/BehaviorController').BehaviorController;
                        behaviorController.getBehaviorByName("Stressed Voice").done(function (behavior) {
                            if (behavior !== null && behavior !== undefined && behavior.length > 0) {
                                //console.log("Behavior ********** " + behavior[0]._id);
                                var behavior_id = behavior[0]._id;

                                var room_id = room[0]._id;
                                var no_of_people = room[0].no_of_people;
                                var newAlertLog = {
                                    "room_id": room_id,
                                    "behavior_id": behavior_id,
                                    "sensor_name": "",
                                    "alert_status": "",
                                    "start_datetime": new Date(),
                                    "end_datetime": null,
                                    "acknowleged_datetime": null,
                                    "acknowleged_by": null,
                                    "priority": 100,
                                    "confidence_value": "0",
                                    "notes": "",
                                    "actual_no_of_people": parseInt(actualNoOfPeople),
                                    "no_of_people": no_of_people,
                                    "current_notification": 0
                                };

                                if (fightDetected > 0) {
                                    newAlertLog.alert_status = "shadow";
                                }
                                else {
                                    newAlertLog.alert_status = "new";
                                }

                                if (fightDetected == 'no_alerts') {
                                    newAlertLog.alert_status = "new";
                                }

                                var alertLogController = require('../controllers/alertlog/AlertLogController').AlertLogController;

                                var CONSTANT = require('../utilities/Constant').CONSTANTS;

                                var log_insert_frequency = CONSTANT.AUDIO_ALERT_LOG_INSERTION_INTERVAL;

                                var dateToCheck = new Date(year, month, date, hour, minute - log_insert_frequency, second);

                                alertLogController.getLogByBehaviorIdAndInsertTime(behavior_id, room_id, dateToCheck).done(function (alertInserted) {

                                    if (alertInserted.length == 0) {
                                        alertLogController.addAlertLog(newAlertLog).done(function (alertInserted) {
                                            var message = roomMessage + '<br />' + ctsMessage + '<br />Alert log inserted successfully with id = ' + alertInserted._id + ' for the behavior Stressed Voice and room no. ' + notificationWithRoomNo;
                                            //res.send(message);
                                            if (newAlertLog.alert_status == 'new') {
                                                //console.log(message);
                                                wsnotification.createWsNotification('alertpopup', {
                                                    "alert_id": alertInserted._id,
                                                    "priority": alertInserted.priority,
                                                    "start_datetime": alertInserted.start_datetime,
                                                    "actual_no_of_people": parseInt(actualNoOfPeople),
                                                    "room": {
                                                        "room_no": notificationWithRoomNo,
                                                        "no_of_people": room[0].no_of_people,
                                                        "camera": room[0].camera_no
                                                    },
                                                    "behavior": {
                                                        "behavior": behavior[0].behavior,
                                                        "sop": behavior[0].sop
                                                    },
                                                    "notify": true
                                                });
                                            }
                                        });
                                    }
                                    else {
                                        //res.send(roomMessage+'<br />'+ctsMessage+'<br />Please wait...');
                                    }
                                });

                            }
                        });
                    });
                });
            }
        });
    }
    res.end();
};

module.exports.disruptsystem = function (req, res) {
    var roomController = require('../controllers/rooms/RoomsController').RoomsController;
    var notification = req.query.notification;
    console.log(" notification =========> " + notification);
    if (notification !== null && notification !== undefined && notification.length > 0) {
        var notificationSplit = notification.split("_");
        var notificationWithRoomNo = notificationSplit[1];

        var curDate = new Date();
        var year = curDate.getFullYear();
        var month = curDate.getMonth();
        var date = curDate.getDate();
        var hour = curDate.getHours();
        var minute = curDate.getMinutes();
        var second = curDate.getSeconds();
        var roomMessage = "room no=" + notificationWithRoomNo;
        var ctsMessage = "timestamp=" + curDate;
       // console.log(roomMessage);
       // console.log(ctsMessage);
        roomController.getRoomIdByRoomNumber(notificationWithRoomNo).done(function (room) {
            if (room[0]) {
                getNumberOfpeopleFromCSV(room[0].sensor1, room[0].sensor2).done(function (actualNoOfPeople) {
                    var behaviorController = require('../controllers/behavior/BehaviorController').BehaviorController;
                    behaviorController.getBehaviorByName("Disrupt System").done(function (behavior) {
                        if (behavior !== null && behavior !== undefined && behavior.length > 0) {
                           // console.log("Behavior ********** " + behavior[0]._id);
                            var behavior_id = behavior[0]._id;

                            var room_id = room[0]._id;
                            var no_of_people = room[0].no_of_people;

                            var newAlertLog = {
                                "room_id": room_id,
                                "behavior_id": behavior_id,
                                "sensor_name": "",
                                "alert_status": "new",
                                "start_datetime": new Date(),
                                "end_datetime": null,
                                "acknowleged_datetime": null,
                                "acknowleged_by": null,
                                "priority": 5,
                                "confidence_value": "0",
                                "notes": "",
                                "actual_no_of_people": parseInt(actualNoOfPeople),
                                "no_of_people": no_of_people,
                                "current_notification": 0
                            };

                            var alertLogController = require('../controllers/alertlog/AlertLogController').AlertLogController;

                            var CONSTANT = require('../utilities/Constant').CONSTANTS;

                            var log_insert_frequency = CONSTANT.AUDIO_ALERT_LOG_INSERTION_INTERVAL;

                            var dateToCheck = new Date(year, month, date, hour, minute - log_insert_frequency, second);

                            //alertLogController.getLogByBehaviorIdAndInsertTime(behavior_id, room_id, dateToCheck).done(function (alertInserted) {

                                //if (alertInserted.length == 0) {
                                    alertLogController.addAlertLog(newAlertLog).done(function (alertInserted) {
                                        var message = roomMessage + '<br />' + ctsMessage + '<br />Alert log inserted successfully with id = ' + alertInserted._id + ' for the behavior Disrupt System and room no. ' + notificationWithRoomNo;
                                        //res.send(message);
                                        console.log(message);

                                        wsnotification.createWsNotification('alertpopup', {
                                            "alert_id": alertInserted._id,
                                            "priority": alertInserted.priority,
                                            "start_datetime": alertInserted.start_datetime,
                                            "actual_no_of_people": parseInt(actualNoOfPeople),
                                            "room": {
                                                "room_no": notificationWithRoomNo,
                                                "no_of_people": room[0].no_of_people,
                                                "camera": room[0].camera_no
                                            },
                                            "behavior": {
                                                "behavior": behavior[0].behavior,
                                                "sop": behavior[0].sop
                                            },
                                            "notify": true
                                        });
                                    });
                               // }
                                //else {
                                    //res.send(roomMessage+'<br />'+ctsMessage+'<br />Please wait...');
                                //}
                            //});
                        }
                    });
                });
            }
        });
    }
    res.end();
};

function getNumberOfpeopleFromCSV(sensor1, sensor2) {
    return new Promise(function (resolve, reject) {
        var settingController = require('../controllers/Settings/SettingsController').SettingController;
        settingController.getSettingByName('csvcommonpath').done(function (setting) {
            fs.readFile(setting.settingvalue + '/' + sensor1 + '.csv', function (err, data) {
                var parser = parse({delimiter: ';'}, function (err, data) {
                    if (err) {
                        console.log('Error: ' + err);
                        reject(err);
                    }
                    // console.log('Data : ' + data.length);
                    if (data) {
                        var numPeopleIndex = data[0].indexOf('number of people');
                        sensorRecords = data.splice(1, data.length);
                        var numberOfPeople = 0;
                        for (var ind = 0; ind < sensorRecords.length; ind++) {
                            //console.log("nofoorecirds =====>" + sensorRecords[ind][numPeopleIndex]);
                            numberOfPeople = Math.max(numberOfPeople, sensorRecords[ind][numPeopleIndex]);
                        }
                        //console.log('Abdi1 ------> ' + numberOfPeople);
                    }
                    fs.readFile(setting.settingvalue + '/' + sensor2 + '.csv', function (err, data) {
                        var parser = parse({delimiter: ';'}, function (err, data) {
                            if (err) {
                                console.log('Error: ' + err);
                                reject(err);
                            }
                            // console.log('Data : ' + data.length);
                            if (data) {
                                var numPeopleIndex = data[0].indexOf('number of people');
                                sensorRecords = data.splice(1, data.length);
                                var numberOfPeople2 = 0;
                                for (var ind = 0; ind < sensorRecords.length; ind++) {
                                    numberOfPeople2 = Math.max(numberOfPeople, sensorRecords[ind][numPeopleIndex]);
                                }
                                //console.log('Abdi2 ------> ' + numberOfPeople2);
                                var actualNumberOfPeople = Math.max(numberOfPeople, numberOfPeople2);
                                resolve(parseInt(actualNumberOfPeople));
                            }
                        });
                        fs.createReadStream(setting.settingvalue + '/' + sensor2 + '.csv').pipe(parser);
                    });
                });
                fs.createReadStream(setting.settingvalue + '/' + sensor1 + '.csv').pipe(parser);
            });
        });
    });
}

module.exports.operation = function (req, res) {
    var locals = {};
    locals.LoggedInUser = req.user;
    locals.activeTab = 'operation';

    if (req.user.role == 'superadmin' || req.user.role == 'admin') {
        locals.hdrCls = 'super-header';
    } else {
        locals.hdrCls = 'header';
    }

    locals.prioThreshold = CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD;
    locals.vms_server_ip = CONSTANT.VMS_SERVER_IP;
    locals.vms_engine_name = CONSTANT.VMS_ENGINE_NAME;
    locals.vms_server_username = CONSTANT.VMS_SERVER_USERNAME;
    locals.vms_server_pwd = CONSTANT.VMS_SERVER_PWD;
    locals.video_export_path = CONSTANT.VIDEO_EXPORT_PATH;

    async.parallel([
        //Load Alert Logs 
        function (callback) {
            alertLogController = require('../controllers/AlertLog/AlertLogController').AlertLogController;
            alertLogController.getAllUnackAlertLog().done(function (alerts) {
                //if (err) return callback(err);
                //console.log(alerts);
                locals.alerts = alerts;
                callback();
            });
        },
        //Load Occurrence Notes
        function (callback) {
            OccurrenceNotesController = require('../controllers/OccurrenceNotes/OccurrenceNotesController').OccurrenceNotesController;
            OccurrenceNotesController.getAllOccurrenceNote().done(function (occNotes) {
                //if (err) return callback(err);
                locals.occNotes = occNotes;
                callback();
            });
        },
        //Load Rooms data
        function (callback) {
            roomController = require('../controllers/Rooms/RoomsController').RoomsController;
            roomController.getAllRoom().done(function (rooms) {
                locals.rooms = rooms;
                locals.roomsAlertCount = {};
                async.forEach(rooms, function (room, callback) {
                    alertLogController.getCountOfUnackAlertByRoom(room._id, room.room_no).done(function (alerts) {
                        var roomsDetails = {};
                        roomsDetails["count"] = alerts.count;
                        roomsDetails["nop_th"] = room.no_of_people;
                        roomsDetails["camera"] = room.camera_no;
                        locals.roomsAlertCount[alerts.room_no] = roomsDetails;
                        callback();

                    });
                }, callback);
            });
        }
    ], function (err) { //This function gets called after the two tasks have called their "task callbacks"
        if (err) return next(err); //If an error occured, we let express/connect handle it by calling the "next" function
        //console.log(locals.roomsAlertCount);
        res.render('index', locals);
    });
};

module.exports.showpeople = function (req, res) {
    var locals = {};
    RoomsController = require('../controllers/Rooms/RoomsController').RoomsController;
    roomController.getAllRoom().done(function (rooms) {
        locals.rooms = rooms;
        res.render('people', locals);
    });
};

module.exports.specialInstructionConfirm = function (req, res) {
    res.render('special_confirm');
};


module.exports.getpeople = function (req, res) {
    var rooms = req.body;
    //console.log(rooms);
    RoomsController = require('../controllers/Rooms/RoomsController').RoomsController;
    for (var myKey in rooms) {
        var roomsDetails = {
            no_of_people: rooms[myKey]
        };
        RoomsController.editRoom(myKey, roomsDetails).done(function () {

        });
    }
    res.json(1);
};

module.exports.editRoomCmpPeople = function (req, res) {
    var room_id = req.body.room_id;
    var cmp_people = req.body.cmp_people;
    RoomsController = require('../controllers/Rooms/RoomsController').RoomsController;
    RoomsController.editRoom(room_id, {room_id: room_id, cmp_people: cmp_people}).done(function () {

    });
    res.json(1);
};

module.exports.resetProbabilities = function (req, res) {
    RoomsController = require('../controllers/Rooms/RoomsController').RoomsController;
    ThresholdsController = require('../controllers/Threshold/ThresholdController').ThresholdController;
    RoomsController.editRoomAll({cmp_people: 0}).done(function () {

    });
    ThresholdsController.editThresholdAll({confidence: 0.6}).done(function () {

    });
    res.json({message:'Config reset successfully'});
};

module.exports.submitAcknowledement = function (req, res) {

    var alert_id = req.body.alert_id;
    var updateAlert = {
        notes: req.body.note,
        alert_status: 'acknowledged',
        acknowleged_datetime: (new Date).getTime(),
        acknowleged_by: req.user._id
    };
    var status;

    alertLogController = require('../controllers/AlertLog/AlertLogController').AlertLogController;
    alertLogController.editAlertLog(alert_id, updateAlert).done(function (alerts) {
        status = alerts;

        alertLogController.getAllUnackAlertLog().done(function (alerts) {
            //console.log(alerts);
            res.render('alertLog.ejs', {
                alerts: alerts,
                prioThreshold: CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD
            });
        });
    });
};


module.exports.getLatestAlertLogs = function (req, res) {

	if(req.user){
	    alertLogController = require('../controllers/AlertLog/AlertLogController').AlertLogController;

        alertLogController.getAllUnackAlertLog().done(function (alerts) {
			res.setHeader('Cache-Control', 'no-cache');
            res.render('alertLog.ejs', {
                alerts: alerts
            });
        });
	}else{
			res.setHeader('Cache-Control', 'no-cache');
            res.send('logout');
	}
};

module.exports.submitSplInst = function (req, res) {

    var insertSplInst = {
        notes: req.body.note,
        notes_datetime: (new Date).getTime(),
        user_id: req.user._id
    };
    var status;

    OccurrenceNotesController = require('../controllers/OccurrenceNotes/OccurrenceNotesController').OccurrenceNotesController;
    OccurrenceNotesController.addOccurrenceNote(insertSplInst).done(function (occNotes) {

        OccurrenceNotesController.getAllOccurrenceNote().done(function (occNotes) {
            var resStr = '';
            var monthArr = global.monthArr;
            for (var i = occNotes.length - 1; i >= 0; i--) {
                var dateObj = new Date(occNotes[i].notes_datetime);
                var noteDate = dateObj.getDate() + '-' + monthArr[dateObj.getMonth()] + '-' + dateObj.getFullYear();
                var noteTime = dateObj.getHours() + ':' + dateObj.getMinutes() + ':' + dateObj.getSeconds();

                resStr += "<li>" + occNotes[i].notes + "  <b>Updated by: " + occNotes[i].user_id.username + '  ' + noteDate + " | " + noteTime + "</b></li>";
            }
            res.send(resStr);
        });
    });
}


module.exports.updateBehavior = function (req, res) {
    var behaviorDet = req.body;
   // console.log(behaviorDet);
    var behaviorController = require('../controllers/Behavior/BehaviorController').BehaviorController;
    behaviorController.editBehavior(behaviorDet._id,behaviorDet).done(function(){
        res.json(1);
    });

};