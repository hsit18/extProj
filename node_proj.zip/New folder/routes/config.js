var async = require("async");
var CONSTANT = require('../utilities/Constant').CONSTANTS;
var underscore = require('underscore');

module.exports.config = function (req, res) {
	var locals = {};
	locals.LoggedInUser = req.user;
	locals.activeTab = 'sensitivity';

    if(req.user.role=='superadmin' || req.user.role=='admin'){
        locals.hdrCls = 'super-header';
    } else {
        locals.hdrCls = 'header';
    }

	locals.prioThreshold = CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD;
	var jsonObj ='';
	var behaviorIDMap = {};
	var roomIDMap = {};

    Array.prototype.contains = function(obj) {
        var i = this.length;
        while (i--) {
            if (this[i] === obj) {
                return true;
            }
        }
        return false;
    };

	async.series([
        
	   	//Load behavior
        function(callback) {
			behaviorController = require('../controllers/Behavior/BehaviorController').BehaviorController;
			behaviorController.getAllBehaviors().done(function (behavior) {
				//if (err) return callback(err);
                var skip_behavior_list = ["Aggression","Extra People","People Missing","Stressed Voice"];
				for(var i = 0; i < behavior.length; i++){
                    if(!skip_behavior_list.contains(behavior[i].behavior)){
                        behaviorIDMap[String(behavior[i]._id)] = behavior[i].behavior;
                    }
				}
				locals.behaviors = behaviorIDMap;
				callback();
			});
        },
        //Load Rooms data
        function(callback) {
			roomController = require('../controllers/Rooms/RoomsController').RoomsController;
			roomController.getAllRoom().done(function (rooms) {
				for(var i = 0; i < rooms.length; i++){
					roomIDMap[String(rooms[i]._id)] = rooms[i].room_no;
				}
				var rooms = underscore.sortBy(rooms, 'room_no');
				locals.rooms = rooms;
				callback();
			});			 
        },
		function(callback){
			
			thresholdController = require('../controllers/Threshold/ThresholdController').ThresholdController;
			thresholdController.getAllThreshold().done(function (thresholds) {
				var thresholdArray = [];
				var thresholdValueArray = [];

				for(var i =0; i < thresholds.length; i++){
                    //console.log("behavior ====> "+thresholds[i].behavior);
                    //if(thresholds[i].behavior_id!='54fe8d9f196fb9cc1f371ea3'){
                        thresholds[i].room_id = roomIDMap[thresholds[i].room_id];
                        thresholds[i].behavior_id = behaviorIDMap[thresholds[i].behavior_id];
                    //}
				}

				var sortedThresholds = underscore.sortBy(thresholds, 'room_id');
				for(var id in behaviorIDMap){
					thresholdValueArray = [];
					var behaviorArray = underscore.where(sortedThresholds, {behavior_id: behaviorIDMap[id]});
					thresholdValueArray.push(behaviorIDMap[id]);
					for(var ind=0;ind<behaviorArray.length;ind++){
						thresholdValueArray.push(behaviorArray[ind].confidence); 
					}
					thresholdArray.push(thresholdValueArray);
				} 

				thresholdValueArray = [];
				thresholdValueArray.push('People Count');
				for(var ind=0;ind<locals.rooms.length;ind++){
                    var cmp_people = (locals.rooms[ind].cmp_people===0)?'Off':'On';
					thresholdValueArray.push(cmp_people);
				}
				thresholdArray.push(thresholdValueArray);

				  locals.thresholds = thresholdArray;
				  locals.LoggedInUser = locals.LoggedInUser;
				  locals.activeTab = locals.activeTab;
				  jsonObj = {
					  object: 'list',
					  data: thresholds
					}
					callback();
			});
		}

    ], function(err) { 
        if (err) return next(err); 
		res.format({
		  	html: function() {
	  			console.log('done');
				res.render('config', locals);
		  	},
		  	json: function() {
				res.json(jsonObj);
		  	}
		});
    });
};

module.exports.updateConfig = function(req, res){
	var locals = {};
	locals.LoggedInUser = req.user;
	locals.activeTab = 'config';
	locals.prioThreshold = CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD;
    var data = req.body;
    var thresholdControllerObject = require('../controllers/Threshold/ThresholdController').ThresholdController;
    thresholdControllerObject.getThresholdsByRoomAndBehaviorId(data.room, data.behavior).done(function(threshold){
    	threshold[0].confidence = data.threshold;
    	thresholdControllerObject.editThreshold(threshold[0]._id, threshold[0].toObject()).done(function(response){
            res.json(1);
    	});
    });
};

module.exports.configResetConfirm = function (req, res) {
    res.render('configreset_confirm');
};