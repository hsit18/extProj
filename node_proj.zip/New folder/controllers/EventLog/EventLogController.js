// Dependencies
var mongoose = require('mongoose');
var EventLogModel = require('../../models/EventLog');
var Promise = require('promise');

function EventLogController() {

}


//Get All Event Log
EventLogController.prototype.getAllEventLog= function () {
    return new Promise(function (resolve, reject) {
        EventLogModel.find({}).lean().exec(function (err, eventlogs) {
            if (err) {
                console.log('Error fetching all Event Log.');
                reject(err);
            } else {
                resolve(eventlogs);
            }
        })
    });
};

//Get All Event Log By ID
EventLogController.prototype.getEventLogById = function (EventLogId) {
    return new Promise(function (resolve, reject) {
        EventLogModel.find({ _id: EventLogId }).lean().exec(function (err, eventlogs) {
            if (err) {
                console.log('Error fetching Event Log by Id.');
                reject(err);
            } else {
                resolve(eventlogs);
            }
        })
    });
};

//Add Event Log
EventLogController.prototype.addEventLog = function (eventlog) {
    return new Promise(function (resolve, reject) {
        var eventLogDocument = new EventLogModel(eventlog);
        eventLogDocument.save(function (err, eventlogs) {
            if (err) {
                console.log('Error while adding Event log.');
                reject(err);
            } else {
                console.log('Event log added successfully.');
                resolve(eventlogs);
            }
        })
    });
};

//Edit Event Log
EventLogController.prototype.editEventLog = function (id, eventlog) {
    return new Promise(function (resolve, reject) {
        EventLogModel.update({ _id: id }, eventlog, { upsert: false }, function (err, numOfRows, eventlogs) {
            if (err) {
                console.log('Error while updating Event log.');
                reject(err);
            } else {
                console.log('Event Log updated successfully.');
                resolve(eventlogs);
            }
        });
    });
};

//Delete Event Log
EventLogController.prototype.deleteEventLog = function (id) {
    return new Promise(function (resolve, reject) {
        EventLogModel.findByIdAndRemove(id, function (err, eventlog) {
            if (err) {
                console.log('Error while deleting Event Log.');
                reject(err);
            } else {
                console.log('Event Log deleted successfully.');
                resolve(eventlog);
            }
        });
    });
};


module.exports = { 'EventLogController': new EventLogController() }