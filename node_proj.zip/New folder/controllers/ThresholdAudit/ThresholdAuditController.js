// Dependencies
var mongoose = require('mongoose');
var ThresholdAuditModel = require('../../models/ThresholdAudit');
var Promise = require('promise');

function ThresholdAuditController() {

}

//Get All Threshold Audit
ThresholdAuditController.prototype.getAllThresholdAudit= function () {
    return new Promise(function (resolve, reject) {
        ThresholdAuditModel.find({}).lean().exec(function (err, thresholdAudits) {
            if (err) {
                console.log('Error fetching all Threshold Audit.');
                reject(err);
            } else {
                resolve(thresholdAudits);
            }
        })
    });
};

//Get All Threshold Audit By ID
ThresholdAuditController.prototype.getThresholdAuditById = function (ThresholdAuditId) {
    return new Promise(function (resolve, reject) {
        ThresholdAuditModel.find({ _id: ThresholdAuditId }).lean().exec(function (err, thresholdAudits) {
            if (err) {
                console.log('Error fetching Threshold Audit by Id.');
                reject(err);
            } else {
                resolve(thresholdAudits);
            }
        })
    });
};

//Add Threshold Audit
ThresholdAuditController.prototype.addThresholdAudit = function (ThresholdAudit) {
    return new Promise(function (resolve, reject) {
        var ThresholdAuditDocument = new ThresholdAuditModel(ThresholdAudit);
        ThresholdAuditDocument.save(function (err, thresholdAudits) {
            if (err) {
                console.log('Error while adding Threshold Audit.');
                reject(err);
            } else {
                console.log('Threshold Audit added successfully.');
                resolve(thresholdAudits);
            }
        })
    });
};

//Edit Threshold Audit
ThresholdAuditController.prototype.editThresholdAudit = function (id, ThresholdAudit) {
    return new Promise(function (resolve, reject) {
        ThresholdAuditModel.update({ _id: id }, ThresholdAudit, { upsert: false }, function (err, numOfRows, thresholdAudits) {
            if (err) {
                console.log('Error while updating Threshold Audit.');
                reject(err);
            } else {
                console.log('Threshold Audit updated successfully.');
                resolve(thresholdAudits);
            }
        });
    });
};

//Delete Threshold Audit
ThresholdAuditController.prototype.deleteThresholdAudit = function (id) {
    return new Promise(function (resolve, reject) {
        ThresholdAuditModel.findByIdAndRemove(id, function (err, ThresholdAudit) {
            if (err) {
                console.log('Error while deleting Threshold Audit.');
                reject(err);
            } else {
                console.log('Threshold Audit deleted successfully.');
                resolve(ThresholdAudit);
            }
        });
    });
};


module.exports = { 'ThresholdAuditController': new ThresholdAuditController() }