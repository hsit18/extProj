// Dependencies
var mongoose = require('mongoose');
var OccurrenceNotesModel = require('../../models/OccurrenceNotes');
var Promise = require('promise');

function OccurrenceNotesController() {

}


//Get All Occurrence Note
OccurrenceNotesController.prototype.getAllOccurrenceNote= function () {
    return new Promise(function (resolve, reject) {
        OccurrenceNotesModel.find({}).lean().populate('user_id').sort({notes_datetime: 'descending'}).limit(10).exec(function (err, occurrenceNotes) {
            if (err) {
                console.log('Error fetching all Occurrence Note.');
                reject(err);
            } else {
                resolve(occurrenceNotes);
            }
        })
    });
};

//Get All Occurrence Note By ID
OccurrenceNotesController.prototype.getOccurrenceNoteById = function (occurrenceNoteId) {
    return new Promise(function (resolve, reject) {
        OccurrenceNotesModel.find({ _id: occurrenceNoteId }).lean().exec(function (err, occurrenceNotes) {
            if (err) {
                console.log('Error fetching Occurrence Note by Id.');
                reject(err);
            } else {
                resolve(occurrenceNotes);
            }
        })
    });
};

//Add Occurrence Note
OccurrenceNotesController.prototype.addOccurrenceNote = function (occurrenceNote) {
    return new Promise(function (resolve, reject) {
        var occurrenceNoteDocument = new OccurrenceNotesModel(occurrenceNote);
        occurrenceNoteDocument.save(function (err, occurrenceNotes) {
            if (err) {
                console.log('Error while adding Occurrence Note.');
                reject(err);
            } else {
                console.log('Occurrence Note added successfully.');
                resolve(occurrenceNotes);
            }
        })
    });
};

//Edit Occurrence Note
OccurrenceNotesController.prototype.editOccurrenceNote = function (id, occurrenceNote) {
    return new Promise(function (resolve, reject) {
        OccurrenceNotesModel.update({ _id: id }, occurrenceNote, { upsert: false }, function (err, numOfRows, occurrenceNotes) {
            if (err) {
                console.log('Error while updating Occurrence Note.');
                reject(err);
            } else {
                console.log('Occurrence Note updated successfully.');
                resolve(occurrenceNotes);
            }
        });
    });
};

//Delete Occurrence Note
OccurrenceNotesController.prototype.deleteOccurrenceNote = function (id) {
    return new Promise(function (resolve, reject) {
        OccurrenceNotesModel.findByIdAndRemove(id, function (err, occurrenceNote) {
            if (err) {
                console.log('Error while deleting Occurrence Note.');
                reject(err);
            } else {
                console.log('Occurrence Note deleted successfully.');
                resolve(occurrenceNote);
            }
        });
    });
};

module.exports = { 'OccurrenceNotesController': new OccurrenceNotesController() }