// Dependencies
var mongoose = require('mongoose');
var AlertLogModel = require('../../models/AlertLog');
var Promise = require('promise');
var RoomsModel = require('../../models/Rooms');

function AlertLogController() {

}

//Get All Alert Log
AlertLogController.prototype.getAllAlertLog= function () {
    return new Promise(function (resolve, reject) {
		var sortByC = {start_datetime: 'descending'};
        AlertLogModel.find({}).populate('room_id behavior_id acknowleged_by').sort(sortByC).exec(function (err, alertLogs) {
            if (err) {
                console.log('Error fetching all Alert Log.');
                reject(err);
            } else {
                resolve(alertLogs);
            }
        })
    });
};

//Get All Alert Log
AlertLogController.prototype.getDetectionAlertLog= function (behavior,room_no,detStatus,fromDate,toDate) {
    return new Promise(function (resolve, reject) {

		var findByCond = {};

		sortByC = {start_datetime: 'descending'};

		if(behavior !== undefined){
			findByCond.behavior_id = behavior;
		}
		if(room_no !== undefined){
			findByCond.room_id = room_no;
		}
		if(detStatus !== undefined){
			findByCond.alert_status = detStatus;
		}else{
			findByCond.alert_status = { $not:{$eq:'shadow'}};
		}

		if(fromDate !== undefined && toDate !== undefined && fromDate === toDate ){
			var fromDateParts = fromDate.split('-');
			findByCond.start_datetime = {$gte: new Date(Date.UTC(fromDateParts[0],fromDateParts[1]-1,fromDateParts[2],0,0,0,0)).toISOString(),$lt: new Date(Date.UTC(fromDateParts[0],fromDateParts[1]-1,fromDateParts[2],24,0,0,0)).toISOString()};
		}else{
			if(fromDate !== undefined){
				var fromDateParts = fromDate.split('-');
				findByCond.start_datetime = {$gte: new Date(Date.UTC(fromDateParts[0],fromDateParts[1]-1,fromDateParts[2],0,0,0,0)).toISOString()};
			}
			if(toDate !== undefined){
				var toDateParts = toDate.split('-');
				findByCond.end_datetime = {$lte: new Date(Date.UTC(toDateParts[0],toDateParts[1]-1,toDateParts[2],24,0,0,0)).toISOString()};
			}
		}

		//console.log(findByCond);

        AlertLogModel.find(findByCond).populate('room_id behavior_id acknowleged_by').sort(sortByC).limit(10000).lean().exec(function (err, alertLogs) {
            if (err) {
                console.log('Error fetching all Alert Log.');
                reject(err);
            } else {
                resolve(alertLogs);
            }
        })
    });
};

//Get All Alert Log
AlertLogController.prototype.getAllAlertLogPaginate= function (pageNum,pageLimit,sortByC,behavior,room_no,detStatus,fromDate,toDate) {

    return new Promise(function (resolve, reject) {

		var findByCond = {};

		//console.log('det status '+detStatus);

		sortByC = {start_datetime: 'descending'};

		if(behavior !== undefined){
			findByCond.behavior_id = behavior;
		}
		if(room_no !== undefined){
			findByCond.room_id = room_no;
		}
		if(detStatus !== undefined){
			findByCond.alert_status = detStatus;
		}else{
			findByCond.alert_status = { $not:{$eq:'shadow'}};
		}
		if(fromDate !== undefined){
			var fromDateParts = fromDate.split('-');
			findByCond.start_datetime = {$gte: new Date(Date.UTC(fromDateParts[0],fromDateParts[1]-1,fromDateParts[2],0,0,0,0)).toISOString()};
		}
		if(toDate !== undefined){
			var toDateParts = toDate.split('-');
			findByCond.end_datetime = {$lte: new Date(Date.UTC(toDateParts[0],toDateParts[1]-1,toDateParts[2],0,0,0,0)).toISOString()};
		}

		AlertLogModel.paginate({}, pageNum, pageLimit, function(error, pageCount, paginatedResults, itemCount) {
		  if (error) {
			console.error(error);
		  } else {
			//console.log('Pages:', pageCount);
			//console.log('Results Count',paginatedResults.length);
			//console.log('item count ',itemCount);
			
			if(paginatedResults.length > 0){
				pageCountCalc = (paginatedResults.length)/5;
			}
			 var varList =  { alerts: paginatedResults,
			    pageCount: pageCount,
			    itemCount: itemCount
			 }
			resolve(varList);
		  }
		}, { columns: '', populate: 'room_id behavior_id acknowleged_by', sortBy : sortByC,findBy:findByCond}
		);
   });
};

//Get All UNACKNOWEDGED Alert Log
AlertLogController.prototype.getAllUnackAlertLog= function () {
    return new Promise(function (resolve, reject) {
        AlertLogModel.find({alert_status: /New/i }).populate('room_id behavior_id').sort({start_datetime: 'descending'}).limit(5).exec(function (err, alertLogs) {
            if (err) {
                console.log('Error fetching all Alert Log.');
                reject(err);
            } else {
				resolve(alertLogs);
            }
        })
    });
};
AlertLogController.prototype.getCountOfUnackAlertByRoom= function (room_id,globalI) {
    return new Promise(function (resolve, reject) {
        AlertLogModel.count({room_id: room_id,alert_status: /New/i }).exec(function (err, alertLogs) {
            if (err) {               
                reject(err);
            } else {
                //console.log(room_no+':'+alertLogs);
                resolve({'room_no': globalI,'count': alertLogs});
            }
        })
    });
};

//Get All Alert Log By ID
AlertLogController.prototype.getAlertLogById = function (alertLogId) {
    return new Promise(function (resolve, reject) {
        AlertLogModel.find({ _id: alertLogId }).lean().exec(function (err, alertLogs) {
            if (err) {
                console.log('Error fetching Alert Log by Id.');
                reject(err);
            } else {
                resolve(alertLogs);
            }
        })
    });
};

//Get All Alert Log By Behavior ID and insertion time
AlertLogController.prototype.getLogByBehaviorIdAndInsertTime = function (behaviorId, roomId, insertTime) {
    return new Promise(function (resolve, reject) {
        AlertLogModel.find({ behavior_id: behaviorId, room_id: roomId, start_datetime: {'$gte': insertTime} }).lean().exec(function (err, alertLogs) {
            if (err) {
                console.log('Error fetching Alert Log by Id.');
                reject(err);
            } else {
                resolve(alertLogs);
            }
        })
    });
};

//Add Alert Log
AlertLogController.prototype.addAlertLog = function (alertLog) {
    return new Promise(function (resolve, reject) {
        var alertLogDocument = new AlertLogModel(alertLog);
        alertLogDocument.save(function (err, alertLogs) {
            if (err) {
                console.log(err);
                console.log('Error while adding alert log.');
                reject(err);
            } else {
                console.log('Alert log added successfully.');
                resolve(alertLogs);
            }
        })
    });
};

//Edit Alert Log
AlertLogController.prototype.editAlertLog = function (id, alertLog) {
    return new Promise(function (resolve, reject) {
        AlertLogModel.update({ _id: id }, alertLog, { upsert: false }, function (err, numOfRows, alertLogs) {
            if (err) {
                console.log('Error while updating alert log.');
                reject(err);
            } else {
                //console.log('Alert Log updated successfully.');
                resolve(alertLogs);
            }
        });
    });
};

//Delete Alert Log
AlertLogController.prototype.deleteAlertLog = function (id) {
    return new Promise(function (resolve, reject) {
        AlertLogModel.findByIdAndRemove(id, function (err, alertLog) {
            if (err) {
                console.log('Error while deleting alert Log.');
                reject(err);
            } else {
                console.log('Alert Log deleted successfully.');
                resolve(alertLog);
            }
        });
    });
};


//Get New alert logs by room id
AlertLogController.prototype.getAllNewAlertLogByRoomId = function (roomId, checkTime) {
    return new Promise(function (resolve, reject) {
        AlertLogModel.find({start_datetime: {'$gte':  checkTime }}).where('room_id').equals(roomId).where('alert_status').equals("new").exec(function (err, alertLog) {
            if (err) {
                //console.log('Error fetching Alert Log.');
                console.log(err);
                reject(err);
            } else {
                //console.log('Alert Log fetched successfully.');
                resolve(alertLog);
            }
        });
    });
};

AlertLogController.prototype.fetchLastMinuteBehavior = function(roomId, behaviorID, sdate, edate){
    return new Promise(function (resolve, reject){
        AlertLogModel.find({
            room_id: roomId,
            behavior_id: behaviorID,
            alert_status: 'new',
            start_datetime: {
                $gte: sdate,
                $lt: edate
            }
        }, function(err, response){
            if(err){
                reject(err);
            }
            if(response){
                resolve(response);
            }
        })
    });
};

module.exports = { 'AlertLogController': new AlertLogController() };