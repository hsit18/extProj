/**
 * Created by Sandesh.Magdum on 3/19/2015.
 */

// Dependencies
var mongoose = require('mongoose');
var settingModel = require('../../models/Setting');
var Promise = require('promise');

function SettingController() {

}

SettingController.prototype.getAllSettings = function () {
    return new Promise(function (resolve, reject) {
        settingModel.find({status:'active'}).lean().exec(function (err, settings) {
            if (err) {
                console.log('Error fetching all settings.');
                reject(err);
            } else {
                resolve(settings);
            }
        })
    });
};

SettingController.prototype.getSettingById = function (settingId) {
    return new Promise(function (resolve, reject) {
        settingModel.findOne({ _id: settingId }).lean().exec(function (err, setting) {
            if (err) {
                console.log('Error fetching setting by id.');
                reject(err);
            } else {
                console.log(setting);
                resolve(setting);
            }
        })
    });
};

SettingController.prototype.getSettingByName = function (settingName) {
    return new Promise(function (resolve, reject) {
        settingModel.findOne({ settingname: settingName }).lean().exec(function (err, setting) {
            if (err) {
                console.log('Error fetching setting by name.');
                reject(err);
            } else {
                console.log(setting);
                resolve(setting);
            }
        })
    });
};

SettingController.prototype.addSetting = function (setting) {
    return new Promise(function (resolve, reject) {
        var settingDocument = new settingModel(setting);
        settingDocument.save(function (err, setting) {
            if (err) {
                console.log('Error while adding setting.');
                reject(err);
            } else {
                console.log('Setting added successfully.');
                resolve(setting);
            }
        })
    });
};

SettingController.prototype.editSettingById = function (settingId, setting) {
    return new Promise(function (resolve, reject) {
        settingModel.update({ _id: settingId }, setting, { upsert: false }, function (err, numOfRows, settings) {
            if (err) {
                console.log('Error while updating setting.');
                reject(err);
            } else {
                console.log('Setting updated successfully.');
                resolve(settings);
            }
        });
    });
};

SettingController.prototype.editSettingByName = function (settingName, setting) {
    return new Promise(function (resolve, reject) {
        settingModel.update({ settingname: settingName }, setting, { upsert: false }, function (err, numOfRows, settings) {
            if (err) {
                console.log('Error while updating setting.');
                reject(err);
            } else {
                console.log('Setting updated successfully.');
                resolve(settings);
            }
        });
    });
};

SettingController.prototype.deleteSetting = function (id) {
    return new Promise(function (resolve, reject) {
        settingModel.findByIdAndRemove(id, function (err, setting) {
            if (err) {
                console.log('Error while deleting setting.');
                reject(err);
            } else {
                console.log('Setting deleted successfully.');
                resolve(setting);
            }
        });
    });
};

module.exports = { 'SettingController': new SettingController() };