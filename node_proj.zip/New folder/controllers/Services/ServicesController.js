// Dependencies
var mongoose = require('mongoose');
var ServicesModel = require('../../models/Services');
var Promise = require('promise');

function ServicesController() {

}

//Get All Service
ServicesController.prototype.getAllService= function () {
    return new Promise(function (resolve, reject) {
        ServicesModel.find({}).lean().exec(function (err, services) {
            if (err) {
                console.log('Error fetching all Service.');
                reject(err);
            } else {
                resolve(services);
            }
        })
    });
};

//Get All Service By ID
ServicesController.prototype.getServiceById = function (ServiceId) {
    return new Promise(function (resolve, reject) {
        ServicesModel.find({ _id: ServiceId }).lean().exec(function (err, services) {
            if (err) {
                console.log('Error fetching Service by Id.');
                reject(err);
            } else {
                resolve(services);
            }
        })
    });
};

//Add Service
ServicesController.prototype.addService = function (Service) {
    return new Promise(function (resolve, reject) {
        var ServiceDocument = new ServicesModel(Service);
        ServiceDocument.save(function (err, services) {
            if (err) {
                console.log('Error while adding Service.');
                reject(err);
            } else {
                console.log('Service added successfully.');
                resolve(services);
            }
        })
    });
};

//Edit Service
ServicesController.prototype.editService = function (id, Service) {
    return new Promise(function (resolve, reject) {
        ServicesModel.update({ _id: id }, Service, { upsert: false }, function (err, numOfRows, services) {
            if (err) {
                console.log('Error while updating Service.');
                reject(err);
            } else {
                console.log('Service updated successfully.');
                resolve(services);
            }
        });
    });
};

//Delete Service
ServicesController.prototype.deleteService = function (id) {
    return new Promise(function (resolve, reject) {
        ServicesModel.findByIdAndRemove(id, function (err, Service) {
            if (err) {
                console.log('Error while deleting Service.');
                reject(err);
            } else {
                console.log('Service deleted successfully.');
                resolve(Service);
            }
        });
    });
};


module.exports = { 'ServicesController': new ServicesController() }