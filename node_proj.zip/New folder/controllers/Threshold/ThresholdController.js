// Dependencies
var mongoose = require('mongoose');
var ThresholdModel = require('../../models/Threshold');
var Promise = require('promise');

function ThresholdController() {

}

//Get All Threshold
ThresholdController.prototype.getAllThreshold = function () {
    return new Promise(function (resolve, reject) {
        ThresholdModel.find({}).lean().exec(function (err, thresholds) {
            if (err) {
                console.log('Error fetching all Threshold.');
                reject(err);
            } else {
                resolve(thresholds);
            }
        })
    });
};

//Get All Threshold By ID
ThresholdController.prototype.getThresholdById = function (ThresholdId) {
    return new Promise(function (resolve, reject) {
        ThresholdModel.find({ _id: ThresholdId }).lean().exec(function (err, thresholds) {
            if (err) {
                console.log('Error fetching Threshold by Id.');
                reject(err);
            } else {
                resolve(thresholds);
            }
        })
    });
};

//Add Threshold
ThresholdController.prototype.addThreshold = function (Threshold) {
    return new Promise(function (resolve, reject) {
        var ThresholdDocument = new ThresholdModel(Threshold);
        ThresholdDocument.save(function (err, thresholds) {
            if (err) {
                console.log('Error while adding Threshold.');
                reject(err);
            } else {
                console.log('Threshold added successfully.');
                resolve(thresholds);
            }
        })
    });
};

//Edit Threshold
ThresholdController.prototype.editThreshold = function (id, Threshold) {
    return new Promise(function (resolve, reject) {
        ThresholdModel.update({ _id: id }, Threshold, { upsert: false }, function (err, numOfRows, thresholds) {
            if (err) {
                console.log('Error while updating Threshold.');
                reject(err);
            } else {
                console.log('Threshold updated successfully.');
                resolve(thresholds);
            }
        });
    });
};

ThresholdController.prototype.editThresholdAll = function (Threshold) {
    return new Promise(function (resolve, reject) {
        ThresholdModel.update({}, Threshold, { upsert: false , multi: true}, function (err, numOfRows, thresholds) {
            if (err) {
                console.log('Error while updating Thresholds.');
                reject(err);
            } else {
                console.log('Thresholds updated successfully.');
                resolve(thresholds);
            }
        });
    });
};

//Delete Threshold
ThresholdController.prototype.deleteThreshold = function (id) {
    return new Promise(function (resolve, reject) {
        ThresholdModel.findByIdAndRemove(id, function (err, Threshold) {
            if (err) {
                console.log('Error while deleting Threshold.');
                reject(err);
            } else {
                console.log('Threshold deleted successfully.');
                resolve(Threshold);
            }
        });
    });
};

// Get thresholds by room id.

ThresholdController.prototype.getThresholdsByRoomId = function (roomId) {
    return new Promise(function (resolve, reject) {
        ThresholdModel.find({ 'room_id': roomId }, function (err, threshold) {
            if (err) {
                console.log('Error while deleting Threshold.');
                reject(err);
            } else {
                console.log('Threshold deleted successfully.');
                resolve(threshold);
            }
        });
    });
};

ThresholdController.prototype.getThresholdsByRoomAndBehaviorId = function (roomId, behaviorId) {
    return new Promise(function (resolve, reject) {
        ThresholdModel.find({ 'room_id': roomId, 'behavior_id': behaviorId }, function (err, threshold) {
            if (err) {
                console.log('Error while fetching Threshold.');
                reject(err);
            } else {
                console.log('Threshold returned successfully.');
                resolve(threshold);
            }
        });
    });
};

module.exports = { 'ThresholdController': new ThresholdController() }