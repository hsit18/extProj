// Dependencies
var mongoose = require('mongoose');
var RoomsModel = require('../../models/Rooms');
var Promise = require('promise');

function RoomsController() {

}


//Get All Room
RoomsController.prototype.getAllRoom = function () {
    return new Promise(function (resolve, reject) {
        
        RoomsModel.find({}).sort( { room_no: 1} ).lean().exec(function (err, rooms) {
            if (err) {
                console.log('Error fetching all Room.');
                reject(err);
            } else {
                resolve(rooms);
            }
        })
    });
};

RoomsController.prototype.getAllRoomWithAlertCount = function () {
    return new Promise(function (resolve, reject) {
        
        RoomsModel.find({}).sort( { room_no: 1} ).lean().exec(function (err, rooms) {
            if (err) {
                console.log('Error fetching all Room.');
                reject(err);
            } else {
                resolve(rooms);
            }
        })
    });
};


//Get All Room By ID
RoomsController.prototype.getRoomById = function (RoomId) {
    return new Promise(function (resolve, reject) {
        RoomsModel.find({ _id: RoomId }).lean().exec(function (err, rooms) {
            if (err) {
                console.log('Error fetching Room by Id.');
                reject(err);
            } else {
                resolve(rooms);
            }
        })
    });
};

//Add Room
RoomsController.prototype.addRoom = function (Room) {
    return new Promise(function (resolve, reject) {
        var RoomDocument = new RoomsModel(Room);
        RoomDocument.save(function (err, rooms) {
            if (err) {
                console.log('Error while adding Room.');
                reject(err);
            } else {
                console.log('Room added successfully.');
                resolve(rooms);
            }
        })
    });
};

//Edit Room
RoomsController.prototype.editRoom = function (id, Room) {
    return new Promise(function (resolve, reject) {
        RoomsModel.update({ _id: id }, Room, { upsert: false }, function (err, numOfRows, rooms) {
            if (err) {
                console.log('Error while updating Room.');
                reject(err);
            } else {
                console.log('Room updated successfully.');
                resolve(rooms);
            }
        });
    });
};

RoomsController.prototype.editRoomAll = function (Room) {
    return new Promise(function (resolve, reject) {
        RoomsModel.update({}, Room, { upsert: false , multi: true}, function (err, numOfRows, rooms) {
            if (err) {
                console.log('Error while updating Rooms.');
                reject(err);
            } else {
                console.log('Rooms updated successfully.');
                resolve(rooms);
            }
        });
    });
};

//Delete Room
RoomsController.prototype.deleteRoom = function (id) {
    return new Promise(function (resolve, reject) {
        RoomsModel.findByIdAndRemove(id, function (err, Room) {
            if (err) {
                console.log('Error while deleting Room.');
                reject(err);
            } else {
                console.log('Room deleted successfully.');
                resolve(Room);
            }
        });
    });
};

// Get room by sensor name.

RoomsController.prototype.getRoomBySensorName = function (sensorName) {
    return new Promise(function (resolve, reject) {
        RoomsModel.find({
            $or: [
                    { sensor1: { $exists: true, $in: [sensorName] } },
                    { sensor2: { $exists: true, $in: [sensorName] } }
            ]
        }, function (err, room) {
            if (err) {
                reject(err);
            } else {
                resolve(room);
            }
        });
    });
};


// Get All room

RoomsController.prototype.getRoomIdByRoomNumber = function (roomNo) {
    return new Promise(function (resolve, reject) {
        RoomsModel.find({ room_no: roomNo}).exec(function (err, roomId) {
            if (err) {
                console.log('Error fetching Room Id.');
                reject(err);
            } else {
                resolve(roomId);
            }
        })
    });
};

// Get all room numbers.

RoomsController.prototype.getAllRoomNumbers = function () {
    return new Promise(function (resolve, reject) {
        RoomsModel.find({}, {room_no: 1}, function (err, room) {
            if (err) {
                reject(err);
            } else {
                resolve(room);
            }
        });
    });
};


RoomsController.prototype.getSensorNames = function () {
    return new Promise(function (resolve, reject) {
        RoomsModel.find({}, {sensor1: true, sensor2: true, _id: false}, function (err, sensors) {
            if (err) {
                reject(err);
            } else {
                resolve(sensors);
            }
        });
    });
};

module.exports = { 'RoomsController': new RoomsController() }