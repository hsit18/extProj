// Dependencies
var mongoose = require('mongoose');
var LastRecordModel = require('../../models/LastRecord');
var Promise = require('promise');

function LastRecordController() {

}


//Get All Last Record
LastRecordController.prototype.getAllLastRecord= function () {
    return new Promise(function (resolve, reject) {
        LastRecordModel.find({}).lean().exec(function (err, lastRecords) {
            if (err) {
                console.log('Error fetching all Last Record.');
                reject(err);
            } else {
                resolve(lastRecords);
            }
        })
    });
};

//Get All Last Record By ID
LastRecordController.prototype.getLastRecordById = function (lastRecordId) {
    return new Promise(function (resolve, reject) {
        LastRecordModel.find({ _id: lastRecordId }).lean().exec(function (err, lastRecords) {
            if (err) {
                console.log('Error fetching Last Record by Id.');
                reject(err);
            } else {
                resolve(lastRecords);
            }
        })
    });
};

//Add Last Record
LastRecordController.prototype.addLastRecord = function (lastRecord) {
    return new Promise(function (resolve, reject) {
        var lastRecordDocument = new LastRecordModel(lastRecord);
        lastRecordDocument.save(function (err, lastRecords) {
            if (err) {
                console.log('Error while adding Last Record.');
                reject(err);
            } else {
                console.log('Last Record added successfully.');
                resolve(lastRecords);
            }
        })
    });
};

//Edit Last Record
LastRecordController.prototype.editLastRecord = function (id, lastRecord) {
    return new Promise(function (resolve, reject) {
        LastRecordModel.update({ _id: id }, lastRecord, { upsert: false }, function (err, numOfRows, lastRecords) {
            if (err) {
                console.log('Error while updating Last Record.');
                reject(err);
            } else {
                console.log('Last Record updated successfully.');
                resolve(lastRecords);
            }
        });
    });
};

//Delete Last Record
LastRecordController.prototype.deleteLastRecord = function (id) {
    return new Promise(function (resolve, reject) {
        LastRecordModel.findByIdAndRemove(id, function (err, lastRecord) {
            if (err) {
                console.log('Error while deleting Last Record.');
                reject(err);
            } else {
                console.log('Last Record deleted successfully.');
                resolve(lastRecord);
            }
        });
    });
};


module.exports = { 'LastRecordController': new LastRecordController() }