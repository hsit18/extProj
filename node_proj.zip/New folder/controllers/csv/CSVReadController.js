var parse = require('csv-parse');
var Promise = require('promise');
var fs = require('fs');
var CONSTANT = require('../../utilities/Constant').CONSTANTS;
var roomController = require('../Rooms/RoomsController').RoomsController;
var behaviorController = require('../Behavior/BehaviorController').BehaviorController;
var thresholdController = require('../Threshold/ThresholdController').ThresholdController;
var alertLogController = require('../AlertLog/AlertLogController').AlertLogController;
var settingsController = require('../Settings/SettingsController').SettingController;
var wsnotification = require('../../helpers/notifications');
var brodcastWsNotification = require('../../helpers/notifications').brodcastWsNotification;

function CSVReader() {
    var that = this;
    this._numberOfPeopleIndex = null;
    this._dateIndex = null;
    this._timeIndex = null;
    this._behaviorNamesArray = [];
    this._behaviorNamesMap = {};
    this._behaviorColumnIndexesMap = {};
    this._thresholdData = [];
    this._csvDataCounterMap = {};
    this._csvReadCounterMap = {};
    this._behaviorPriorityMap = {};
    this.wsnotification = wsnotification;
    this._behaviorActualNamesMap = {};

    behaviorController.getAllBehaviors().done(function (data) {
        if (data) {
            for (var i = 0; i < data.length; i++) {
                that._behaviorNamesArray.push(((data[i].behavior).toLowerCase()));
                that._behaviorNamesMap[(data[i].behavior).toLowerCase()] = data[i]._id;
                that._behaviorActualNamesMap[(data[i].behavior).toLowerCase()] = {};
                that._behaviorActualNamesMap[(data[i].behavior).toLowerCase()]['name'] = data[i].behavior;
                that._behaviorActualNamesMap[(data[i].behavior).toLowerCase()]['sop'] = data[i].sop;
                that._behaviorPriorityMap[(data[i].behavior).toLowerCase()] = data[i].behavior_level;
            }
        }
    });

    thresholdController.getAllThreshold().done(function (thresholdData) {
        that._thresholdData = thresholdData;
    });
}

CSVReader.prototype.initializeSensorDetector = function(wsnotification){
    var that = this;
    var csvUpdateTimeCounter = setInterval(function(){
        for(var i in that._csvReadCounterMap){
            that._csvReadCounterMap[i] = that._csvReadCounterMap[i] + 1;
            if(that._csvReadCounterMap[i] === CONSTANT.SENSOR_OFFLINE_TIME_THRESHOLD){
                //console.log(i + ' is offline..................');
                roomController.getRoomBySensorName(i).done(function (roomData) {
                    wsnotification.createWsNotification('floorPlan', { 
                        room: roomData[0].room_no, 
                        action: 'camera',
                        data: 0
                    });
                });
            }else if (that._csvReadCounterMap[i] < CONSTANT.SENSOR_OFFLINE_TIME_THRESHOLD) {
                //console.log(i + ' is online..................');
                roomController.getRoomBySensorName(i).done(function (roomData) {
                    wsnotification.createWsNotification('floorPlan', { 
                        room: roomData[0].room_no, 
                        action: 'camera',
                        data: 1
                    });
                });
            }
        }
    }, 1000);
};

CSVReader.prototype.initialize = function () {
    var filesWatched = [];
    var that = this;
    var path = null;

    settingsController.getAllSettings().done(function(settingResponse){
        console.log(settingResponse);
        for(var i=0;i<settingResponse.length;i++){
            var settingObject = settingResponse[i];
            if(settingObject.settingname === 'csvcommonpath'){
                path = settingObject.settingvalue;
            }
        }
        console.log('CSVPath: ' + settingObject.settingvalue);

        roomController.getSensorNames().done(function(sensorNames){
            var sensorNamesArr = [];
            for(var ind = 0; ind < sensorNames.length; ind++){
                var roomObj = sensorNames[ind];
                sensorNamesArr.push(roomObj.sensor1);
                sensorNamesArr.push(roomObj.sensor2);
            }
            CONSTANT.CSV_FILES_NAMES = sensorNamesArr;

            that.initializeCSVDataCounterMap();
            that.watchCombinedResults(path);
            that.initializeSensorDetector(wsnotification);

            for (var i = 0; i < CONSTANT.CSV_FILES_NAMES.length; i++) {
                (function(i,wsnotification){
                    console.log('Start watching ' + path + '/' + CONSTANT.CSV_FILES_NAMES[i] + '.csv');
                    fs.watchFile(path + '/' + CONSTANT.CSV_FILES_NAMES[i] + '.csv', { persistent: true, interval: 3000 }, function (curr, prev) {
                        console.log('Watching file ' + path + '/' + CONSTANT.CSV_FILES_NAMES[i] + '.csv');
                        console.log('File Size :----->  ' + curr.size);

                        var filename = path + '/' + CONSTANT.CSV_FILES_NAMES[i] + '.csv';
                        if (curr.mtime > prev.mtime) { // Check if the file is updated
                            if (filesWatched.indexOf(filename) < 0) { // If file is modified just once in the given time.
                                filesWatched.push(filename);

                                if (filename) {
                                    if (filesWatched.indexOf(filename) >= 0) {
                                        (function () {
                                            var parser = parse({ delimiter: ';' }, function (err, data) {
                                                if (err) {
                                                    console.log('Error: ' + err);
                                                }
                                                var csvArchiveData = JSON.parse(JSON.stringify(data));
                                                // console.log('Data : ' + data.length);
                                                if (data) {
                                                    var csvOperationObject = new CSVOperations();
                                                    var coulumnNamesArray = data[0];
                                                    var dataLength = data.length;
                                                    var subArray = [];

                                                    if (dataLength > that._csvDataCounterMap[CONSTANT.CSV_FILES_NAMES[i]]) {
                                                        var deltaLength = dataLength - that._csvDataCounterMap[CONSTANT.CSV_FILES_NAMES[i]];

                                                        // console.log('Delta Length : ' + deltaLength);
                                                        if(that._csvDataCounterMap[CONSTANT.CSV_FILES_NAMES[i]] == 0){
                                                            subArray = data.slice(dataLength - (deltaLength-1), dataLength);
                                                        }else{
                                                            subArray = data.slice(dataLength - deltaLength, dataLength);
                                                        }
                                                        // console.log('Subarray Length : ' + subArray.length);
                                                        that._csvDataCounterMap[CONSTANT.CSV_FILES_NAMES[i]] = dataLength;
                                                    }

                                                    if (Object.keys(that._behaviorColumnIndexesMap).length == 0) {
                                                        for (var index = 0; index < coulumnNamesArray.length; index++) {
                                                            if (coulumnNamesArray[index] === 'number of people') {
                                                                that._numberOfPeopleIndex = index;
                                                            }
                                                            if (coulumnNamesArray[index] === CONSTANT.DATE_CSV_INDEX_NAME) {
                                                                that._dateIndex = index;
                                                            }
                                                            if (coulumnNamesArray[index] === CONSTANT.TIME_CSV_INDEX_NAME) {
                                                                that._timeIndex = index;
                                                            }                                                    
                                                            if (coulumnNamesArray[index] === CONSTANT.SENSOR_CONNECTED_CSV_INDEX_NAME) {
                                                                that._sensorConnectedIndex = index;
                                                            }
                                                            if (that._behaviorNamesArray.indexOf((coulumnNamesArray[index]).toLowerCase()) >= 0) {
                                                                that._behaviorColumnIndexesMap[(coulumnNamesArray[index]).toLowerCase()] = index;
                                                            }
                                                        }
                                                    }
                                                    console.log("subArray.length"+subArray.length);
                                                    if (subArray.length) {
                                                        that.getRoomNumber(path, subArray, CONSTANT.CSV_FILES_NAMES[i], wsnotification);
                                                    } 

                                                    // if(curr.size >= CONSTANT.CSV_THRESHOLD_FILE_SIZE){
                                                    //     var dir = path + '/archive/' + CONSTANT.CSV_FILES_NAMES[i] + '/';
                                                    //     if (!fs.existsSync(dir)){
                                                    //         fs.mkdirSync(dir);
                                                    //     }else{
                                                    //         console.log('Directory exits.');
                                                    //     }
                                                    //     fs.writeFile(dir + CONSTANT.CSV_FILES_NAMES[i] + '_' +(new Date().toLocaleDateString())+'.csv', csvArchiveData, function (err) {
                                                    //       if (err) throw err;
                                                    //         fs.createReadStream(filename).pipe(fs.createWriteStream(dir + CONSTANT.CSV_FILES_NAMES[i] + '_' +(new Date().toLocaleDateString())+'.csv'));
                                                    //         fs.writeFile(filename, coulumnNamesArray.join(';'), function(){
                                                    //             that._csvDataCounterMap[CONSTANT.CSV_FILES_NAMES[i]] = 1;
                                                    //             console.log('File ' + CONSTANT.CSV_FILES_NAMES[i] + ' Archived.');
                                                    //         });
                                                    //     });
                                                    // }

                                                    filesWatched.splice(filesWatched.indexOf(filename), 1);
                                                }
                                            });
                                            fs.createReadStream(filename).pipe(parser);
                                        })();
                                    }
                                }
                            }
                        }
                    });
                })(i, that.wsnotification);
            }
        });
    });
};

CSVReader.prototype.watchCombinedResults = function(path){
    var that = this;
    roomController.getAllRoomNumbers().done(function(roomNumbers){
        for(var index = 0; index < roomNumbers.length; index++){
            (function(index, path, wsnotification){
                var filename = path + '/rooms/room_' + roomNumbers[index].room_no + '.json';
                fs.watchFile(filename, { persistent: true, interval: 13000 }, function(curr, prev){
                    var jsonPath = filename;
                    if (curr.mtime > prev.mtime) {
                        fs.readFile(jsonPath, function(err, data){
                            if(data.length){
                                var data = String(data).substring(1, data.length);
                                var str = "["+data+"]";
                                var data = JSON.parse(str);
                                var csvOperationObject = new CSVOperations();
                                csvOperationObject.behaviorColumnIndexesMap = that._behaviorColumnIndexesMap;
                                csvOperationObject.dateIndex = that._dateIndex;
                                csvOperationObject.timeIndex = that._timeIndex;
                                csvOperationObject._thresholdData = that._thresholdData;
                                csvOperationObject._behaviorNamesMap = that._behaviorNamesMap;
                                csvOperationObject._behaviorActualNamesMap = that._behaviorActualNamesMap;
                                csvOperationObject._behaviorPriorityMap = that._behaviorPriorityMap;
                                csvOperationObject.calculatePeopleCount(roomNumbers[index]._id, data, that._numberOfPeopleIndex ,wsnotification);
                                csvOperationObject.calculateConfidenceValue(roomNumbers[index]._id, data, wsnotification);
                                fs.truncate(jsonPath, 0, function(){

                                });
                            }
                        }); 
                    }
                });
            })(index, path, that.wsnotification);
        }
    });
};

CSVReader.prototype.getRoomNumber = function (path, sensorRecords, sensorName, wsnotification) {
    var that = this;
    roomController.getRoomBySensorName(sensorName).done(function (roomData) {
        that.checkSensorConnection(sensorRecords, sensorName, wsnotification, roomData[0].room_no);
        if(sensorRecords.length > 0){
            for(var record in sensorRecords){
                if(Array.isArray(sensorRecords[record]) == true){
                    sensorRecords[record].push(sensorName);
                }
            }
            var finalStr = JSON.stringify(sensorRecords).substring(1, JSON.stringify(sensorRecords).length-1);
            var dataToInsert = "," + finalStr;
            fs.appendFile(path + '/rooms/room_' + roomData[0].room_no + '.json', dataToInsert, function(err, data){
                if(err){
                    console.log(err);
                }
                if(data){
                    //console.log(data);
                }
            });
        }
    });
};

CSVOperations.prototype.calculatePeopleCount = function(roomId, sensorRecords, numberOfPeopleIndex, wsnotification){
    var that = this;
    if(sensorRecords.length > 0){
        var numberOfPeople = 0;
        for(var ind = 0; ind < sensorRecords.length; ind++){
//            console.log('num ---------------> ' + sensorRecords[ind][numberOfPeopleIndex] + ' ------ ' + parseInt(sensorRecords[ind][numberOfPeopleIndex]));
           // numberOfPeople = Math.max(parseInt(numberOfPeople), parseInt(sensorRecords[ind][numberOfPeopleIndex]));
            if(parseInt(sensorRecords[ind][numberOfPeopleIndex]) > numberOfPeople){
                numberOfPeople = parseInt(sensorRecords[ind][numberOfPeopleIndex]);
            }
        }
        console.log('final ----------> ' + numberOfPeople);
        this.numberOfPeople = numberOfPeople;

        var dateString = sensorRecords[sensorRecords.length-1][this.dateIndex] + ' ' + sensorRecords[sensorRecords.length-1][this.timeIndex];
        this.dateString = dateString;
        console.log('dateString ----> ' + dateString);
        
        roomController.getRoomById(roomId).done(function (roomData) {
            if(numberOfPeople !== roomData[0].no_of_people){
                var behaviorId = null;                
                if(numberOfPeople > roomData[0].no_of_people){
                    var behaviorName = CONSTANT.PEOPLE_COUNT_EXCEEDED_BEHAVIOR;
                    behaviorId = that._behaviorNamesMap[behaviorName];
                }else{
                    var behaviorName = CONSTANT.PEOPLE_COUNT_LESS_BEHAVIOR;
                    behaviorId = that._behaviorNamesMap[behaviorName];
                }            

//                console.log(that._behaviorActualNamesMap);
//                console.log(behaviorName);
//                console.log('------------------> ' + that._behaviorActualNamesMap[behaviorName].name + ' ' + that._behaviorActualNamesMap[behaviorName].sop);
                if(roomData[0].cmp_people){
                    alertLogController.addAlertLog({
                        room_id: roomData[0]._id,
                        behavior_id: behaviorId,
                        sensor_name: roomData[0].sensor1,
                        alert_status: 'new',
                        start_datetime: getCurrentDate(dateString),
                        end_datetime: getCurrentDate(dateString),
                        acknowleged_datetime: '',
                        acknowleged_by: null,
                        priority: CONSTANT.NUMBER_OF_PEOPLE_PRIORITY,
                        confidence_value: CONSTANT.NUMBER_OF_PEOPLE_CONFIDENCE_VALUE,
                        notes: '',
                        actual_no_of_people: numberOfPeople,
                        no_of_people: roomData[0].no_of_people,
                        current_notification: 0
                    }).done(function(alertInserted){
                        console.log('Alert log inserted sucessfully with id = ' + alertInserted._id + ' for people count.');
                        
                            console.log('Mismatch in the count of people in room ' + roomData[0].room_no + '.');
                            wsnotification.createWsNotification('alertpopup', {
                                "alert_id": alertInserted._id,
                                "priority": alertInserted.priority,
                                "start_datetime": alertInserted.start_datetime,
                                "actual_no_of_people": alertInserted.actual_no_of_people,
                                "room": {
                                    "room_no": roomData[0].room_no,
                                    "no_of_people": alertInserted.no_of_people,
                                    "camera": roomData[0].camera_no
                                },
                                "behavior": {
                                    "behavior":  that._behaviorActualNamesMap[behaviorName].name ,
                                    "sop": that._behaviorActualNamesMap[behaviorName].sop
                                },
                                "notify": true  
                            });
                        
                    });
                }
            } else {
                console.log('People count matches in room ' + roomData[0].room_no + '.');
            }
        });
    }
};

CSVOperations.prototype.calculateConfidenceValue = function(roomId, csvData, wsnotification){
    var confidenceObject = {};
    var that = this;

    roomController.getRoomById(roomId).done(function (roomData) {
        for (var i = 0; i < that._thresholdData.length; i++) {
            var thresholdObject = that._thresholdData[i];
            if (thresholdObject.room_id == String(roomData[0]._id)) {
                for(var behaviorId in that._behaviorNamesMap){
                    if(String(that._behaviorNamesMap[behaviorId]) == String(thresholdObject.behavior_id)){
                        confidenceObject[behaviorId] = thresholdObject.confidence;
                    }
                }
            }
        }

        for(var recordIndex = 0; recordIndex < csvData.length; recordIndex++){
            var record = csvData[recordIndex];
            for(var behavior in that.behaviorColumnIndexesMap){
                // console.log(record[record.length-1] + ' ----> ' + behavior + ' ----> ' + record[that.behaviorColumnIndexesMap[behavior]]);
                if(record[that.behaviorColumnIndexesMap[behavior]] > 0){
                    if(that.detectionMapperObject[record[record.length-1]]){
                        if(that.detectionMapperObject[record[record.length-1]][behavior]){
                            var detectionValueCountArray = that.detectionMapperObject[record[record.length-1]][behavior].split('|');
                            var detectionValue = parseFloat(detectionValueCountArray[0]);
                            var detectionCount = parseInt(detectionValueCountArray[1]);

                            if(round(parseFloat(record[that.behaviorColumnIndexesMap[behavior]]), 4) > confidenceObject[behavior]){
                                if(detectionCount > 0){
                                    var newDetectionCount = detectionCount + 1;
                                    var newDetectionValue = (detectionValue + parseFloat(record[that.behaviorColumnIndexesMap[behavior]]));
                                    that.detectionMapperObject[record[record.length-1]][behavior] = round(parseFloat(newDetectionValue), 4) + '|' + newDetectionCount;        
                                }else{
                                    that.detectionMapperObject[record[record.length-1]][behavior] = round(parseFloat(record[that.behaviorColumnIndexesMap[behavior]]), 4) + '|' + 1;    
                                }
                            }else{
                                if(detectionCount > 0){

                                }else{
                                    if(round(parseFloat(record[that.behaviorColumnIndexesMap[behavior]]), 4) > detectionValue){
                                        detectionValue = round(parseFloat(record[that.behaviorColumnIndexesMap[behavior]]), 4);
                                        that.detectionMapperObject[record[record.length-1]][behavior] = detectionValue + '|' + 0;
                                    }
                                }
                            }
                        }else{
                            that.detectionMapperObject[record[record.length-1]][behavior] = {};
                            if(round(parseFloat(record[that.behaviorColumnIndexesMap[behavior]]), 4) > confidenceObject[behavior]){
                                that.detectionMapperObject[record[record.length-1]][behavior] = round(parseFloat(record[that.behaviorColumnIndexesMap[behavior]]), 4) + '|' + 1;
                            }else{
                                that.detectionMapperObject[record[record.length-1]][behavior] = round(parseFloat(record[that.behaviorColumnIndexesMap[behavior]]), 4) + '|' + 0;
                            }
                        }
                    }else{
                        that.detectionMapperObject[record[record.length-1]] = {};
                        that.detectionMapperObject[record[record.length-1]][behavior] = {};
                        if(round(parseFloat(record[that.behaviorColumnIndexesMap[behavior]]), 4) > confidenceObject[behavior]){
                            that.detectionMapperObject[record[record.length-1]][behavior] = round(parseFloat(record[that.behaviorColumnIndexesMap[behavior]]), 4) + '|' + 1;
                        }else{
                            that.detectionMapperObject[record[record.length-1]][behavior] = round(parseFloat(record[that.behaviorColumnIndexesMap[behavior]]), 4) + '|' + 0;
                        }
                    }
                }
            }
        }
    //    console.log('Abdi here ---->');
    //    console.log(that.detectionMapperObject);
        that.formRoomDetectionMap(that.detectionMapperObject, roomId, wsnotification);
    });
};

CSVOperations.prototype.formRoomDetectionMap = function(detectionMap, roomId, wsnotification){
    for(var sensorName in detectionMap){
        var sensorbehaviorobject = detectionMap[sensorName];
        for(var behavior in sensorbehaviorobject){
            if(this.roomDetectionMapperObject[behavior]){
                var valueCountArr = sensorbehaviorobject[behavior].split('|');
                if(parseInt(valueCountArr[1]) > 0){
                    var averageValue = parseFloat(valueCountArr[0])/parseInt(valueCountArr[1]);
                    if(averageValue > this.roomDetectionMapperObject[behavior] && averageValue >= CONSTANT.MINIMUM_CONFIDENCE_THRESHOLD){
                        this.roomDetectionMapperObject[behavior] = round(averageValue, 4);
                    }
                }else{
                    if(round(parseFloat(valueCountArr[0]), 4) > this.roomDetectionMapperObject[behavior]){
                        this.roomDetectionMapperObject[behavior] = round(parseFloat(valueCountArr[0]), 4);
                    }
                }
            }else{
                var valueCountArr = sensorbehaviorobject[behavior].split('|');
                if(parseInt(valueCountArr[1]) > 0){
                    var averageValue = parseFloat(valueCountArr[0])/parseInt(valueCountArr[1]);
                    if(averageValue >= CONSTANT.MINIMUM_CONFIDENCE_THRESHOLD){
                        this.roomDetectionMapperObject[behavior] = round(averageValue, 4);
                    }                
                }else{
                    this.roomDetectionMapperObject[behavior] = round(parseFloat(valueCountArr[0]), 4);
                }
            }
        }
    }

    this.calculateDetection(roomId, wsnotification);
};

CSVOperations.prototype.calculateDetection = function(roomId, wsnotification){
    var threshholdsForThisRoom = [];
    var that = this;
    
    console.log(that.roomDetectionMapperObject);
    roomController.getRoomById(roomId).done(function (roomData) {
        for (var i = 0; i < that._thresholdData.length; i++) {
            var thresholdObject = that._thresholdData[i];
            if (thresholdObject.room_id == String(roomData[0]._id)) {
                threshholdsForThisRoom.push(thresholdObject);
            }
        }

        if(Object.keys(that.roomDetectionMapperObject).length > 0){
            var highPriorityBehaviors = that.getHighPriorityBehaviors();
            console.log(highPriorityBehaviors);
            var shadowBehaviors = that.getShadowBehaviors();
            console.log(shadowBehaviors);
            if(highPriorityBehaviors.length > 0){
                that.notifyUser(highPriorityBehaviors, threshholdsForThisRoom, roomData[0], true, wsnotification);
                if(shadowBehaviors.length > 0){
                    that.addShadowDetections(shadowBehaviors, false, threshholdsForThisRoom, roomData[0]);
                }
            }else if(shadowBehaviors.length > 0){
                that.notifyUser(shadowBehaviors, threshholdsForThisRoom, roomData[0], false, wsnotification);
            }
        }
    });
};

CSVOperations.prototype.getPreviousDetections = function(dStr, roomId, behaviorId){
    return new Promise(function (resolve, reject){
        var endDateString = dStr; //'12-03-2015 13:21:24.488';
        var dateStrArr = endDateString.split('-');
        var tempDate = dateStrArr[0];
        dateStrArr[0] = dateStrArr[1];
        dateStrArr[1] = tempDate;
        var dateStr = dateStrArr.join('-');
        // var startDate = new Date('03-12-2015 13:19:24.488').toISOString();
        var endDate = new Date(dateStr).toISOString();
        var endSecs = new Date(dateStr).getSeconds();
        var endMins = new Date(dateStr).getMinutes();
        var endHours = new Date(dateStr).getHours();
        var newSecs = endSecs - 60;
        if(newSecs > 0){

        }else{
            newSecs = 60 + newSecs;
            if(endMins == 00){
                newSecs = 00;
                endHours = endHours -1;
            }else{
                endMins = endMins - 1;
            }
        }
        
        var dateSpaceSplitArr = endDateString.split(' ');
        var dateStrArr = dateSpaceSplitArr[0].split('-');

        var tempDate = dateStrArr[0];
        dateStrArr[0] = dateStrArr[1];
        dateStrArr[1] = tempDate;
        var dateStr = dateStrArr.join('-');

        var timeColonSplitArr = dateSpaceSplitArr[1].split(':');
        var timeStr = timeColonSplitArr[timeColonSplitArr.length-1];
        var secsArr = timeStr.split('.');

        var finalStr = dateStr + ' ' + endHours + ':' + endMins + ':' + newSecs + '.' + secsArr[1];
        console.log('finalStr ----------------------------------------> ' + finalStr);
        var startDate = new Date(finalStr).toISOString();

        alertLogController.fetchLastMinuteBehavior(roomId, behaviorId, startDate, endDate).done(function(response){
            console.log('Result -------------------------------------------->' + response.length);
//            console.log(response);
            resolve(response.length);
        });
    });
};


CSVOperations.prototype.notifyUser = function(highPriorityBehaviors, threshholdsForThisRoom, roomData, toBeNotified, wsnotification){
    var behavior = highPriorityBehaviors[0];
    var that = this;
    
    for(var index in threshholdsForThisRoom){
        var thresholdObject = threshholdsForThisRoom[index];
        if(String(thresholdObject.behavior_id) == this._behaviorNamesMap[behavior]){
            (function(thresholdObject){
                that.getPreviousDetections(that.dateString, roomData._id, that._behaviorNamesMap[behavior]).done(function(result){
                    if(result == 0){
                        // console.log('------------------> ' + that._behaviorActualNamesMap[behavior].name + ' ' + that._behaviorActualNamesMap[behavior].sop);
                        // console.log(that._behaviorPriorityMap[behavior]);
                        var notify = null;
                        if(that.roomDetectionMapperObject[behavior] > thresholdObject.confidence){                        
                            var behaviorPriority = that._behaviorPriorityMap[behavior];            
                            alertLogController.addAlertLog({
                                room_id: roomData._id,
                                behavior_id: that._behaviorNamesMap[behavior],
                                sensor_name: null,
                                alert_status: 'new',
                                start_datetime: getCurrentDate(that.dateString),
                                end_datetime: getCurrentDate(that.dateString),
                                acknowleged_datetime: '',
                                acknowleged_by: null,
                                priority: behaviorPriority,
                                confidence_value: that.roomDetectionMapperObject[behavior] ,
                                notes: '',
                                actual_no_of_people: that.numberOfPeople,
                                no_of_people: roomData.no_of_people,
                                current_notification: 0
                            }).done(function(alertInserted){
                                console.log('Alert log inserted sucessfully with id = ' + alertInserted._id + ' for the behavior ' + behavior + '.');
                                console.log("that.roomDetectionMapperObject[behavior] ============"+that.roomDetectionMapperObject[behavior]);
                                console.log("thresholdObject.confidence ============"+thresholdObject.confidence);
                                console.log("toBeNotified ============"+toBeNotified);
                                
                                if(toBeNotified){
                                    notify = true;    
                                }else{
                                    notify = false;    
                                }
                                // console.log("toBeNotified =============="+toBeNotified);
                                wsnotification.createWsNotification('alertpopup', {
                                    "alert_id": alertInserted._id,
                                    "priority": alertInserted.priority,
                                    "start_datetime": alertInserted.start_datetime,
                                    "actual_no_of_people": alertInserted.actual_no_of_people,
                                    "room": {
                                        "room_no": roomData.room_no,
                                        "no_of_people": alertInserted.no_of_people,
                                        "camera": roomData.camera_no
                                    },
                                    "behavior": {
                                        "behavior":  that._behaviorActualNamesMap[behavior].name ,
                                        "sop": that._behaviorActualNamesMap[behavior].sop
                                    },
                                    "notify": notify        
                                });
                                that.addShadowDetections(highPriorityBehaviors, true, threshholdsForThisRoom, roomData);
                            });
                        }
                    }
                });
            })(thresholdObject);
        }
    }
};

CSVOperations.prototype.addShadowDetections = function(behaviorNames, spliceNames, threshholdsForThisRoom, roomData){
    var that = this;        
    if(spliceNames){
        behaviorNames.shift();
    }
    if(behaviorNames.length > 0){
        for(var i =0; i<behaviorNames.length;i++){
            var behavior = behaviorNames[i];

            for(var index in threshholdsForThisRoom){
                var thresholdObject = threshholdsForThisRoom[index];
                if(String(thresholdObject.behavior_id) == this._behaviorNamesMap[behavior]){
                    if(that.roomDetectionMapperObject[behavior] > thresholdObject.confidence){ 
                        console.log(behavior + ' is detected as the shadow detection.');
                        var curDate = new Date();
                        var year = curDate.getFullYear();
                        var month = curDate.getMonth();
                        var date = curDate.getDate();

                        var dateToInsert = new Date(year, month, date, 13, 00, 00);                        

                        alertLogController.addAlertLog({
                            room_id: roomData._id,
                            behavior_id: this._behaviorNamesMap[behavior],
                            sensor_name: null,
                            alert_status: 'shadow',
                            start_datetime: getCurrentDate(that.dateString),
                            end_datetime: getCurrentDate(that.dateString),
                            acknowleged_datetime: '',
                            acknowleged_by: null,
                            priority: this._behaviorPriorityMap[behavior].behavior_level,
                            confidence_value: this.roomDetectionMapperObject[behavior] ,
                            notes: '',
                            actual_no_of_people: that.numberOfPeople,
                            no_of_people: roomData.no_of_people,
                            current_notification: 0
                        }).done(function(alertInserted){
                            console.log('Alert log inserted sucessfully with id = ' + alertInserted._id + ' for the behavior ' + behavior + '.');
                        });
                    }
                }
            }      
        }  
    }
};

CSVOperations.prototype.getHighPriorityBehaviors = function(){
    var priorityBehaviors = [];
    var tempPriority = CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD + 1;
//    console.log("this.roomDetectionMapperObject");
//    console.log(this.roomDetectionMapperObject);

    for(var behavior in this.roomDetectionMapperObject){
        if(this._behaviorPriorityMap[behavior] <= CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD){
            if(this._behaviorPriorityMap[behavior] < tempPriority){
                priorityBehaviors.unshift(behavior);
                tempPriority = this._behaviorPriorityMap[behavior];
            }else{
                priorityBehaviors.push(behavior);
            }
        }
    }
    return priorityBehaviors;
};

CSVOperations.prototype.getShadowBehaviors = function(){
    var priorityBehaviors = [];
    var tempPriority = CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD;

    for(var behavior in this.roomDetectionMapperObject){
        if(this._behaviorPriorityMap[behavior] > CONSTANT.HIGH_PRIORITY_BEHAVIOR_THRESHOLD){
            if(this._behaviorPriorityMap[behavior] > tempPriority){
                priorityBehaviors.push(behavior);
                tempPriority = this._behaviorPriorityMap[behavior];
            }else{
                priorityBehaviors.unshift(behavior);
            }
        }
    }
    return priorityBehaviors;
};

function getCurrentDate(dateTime){
    // var curDate = new Date();
    // var year = curDate.getFullYear();
    // var month = curDate.getMonth();
    // var date = curDate.getDate();

    // return new Date(year, month, date, 13, 00, 00); 

    var dateArray = dateTime.split('-');
    var tempDate = dateArray[0];
    dateArray[0] = dateArray[1];
    dateArray[1] = tempDate;
    var dateStr = dateArray.join('-');
    return new Date(dateStr).toISOString();
}

CSVReader.prototype.checkSensorConnection = function (records, sensorName, wsnotification, roomNumber){
    var sensorConnectedFlag = true;
    var disconnectionCounter = 0;
    for(var i = 0; i < records.length; i++){
        if(parseInt(records[i][this._sensorConnectedIndex]) == false){
            disconnectionCounter++;
            if(disconnectionCounter === 2){
                sensorConnectedFlag = false;
            }
        }
    }

    if(sensorConnectedFlag == false){
        console.log('Sensor' + sensorName + ' is not connected.');
        wsnotification.createWsNotification('floorPlan', { 
            room: roomNumber, 
            action: 'camera',
            data: 0
        });
    }else{
        wsnotification.createWsNotification('floorPlan', { 
            room: roomNumber, 
            action: 'camera',
            data: 1
        });
    }
};

CSVReader.prototype.initializeCSVDataCounterMap = function () {
    for (var i = 0; i < CONSTANT.CSV_FILES_NAMES.length; i++) {
        this._csvDataCounterMap[CONSTANT.CSV_FILES_NAMES[i]] = 0;
        this._csvReadCounterMap[CONSTANT.CSV_FILES_NAMES[i]] = 0;
    }
};


function CSVOperations() {
    this.detectionMapperObject = {};
    this.roomDetectionMapperObject = {};
}

function round(value, decimals) {
    return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
}

module.exports = { CSVReader: new CSVReader() }
