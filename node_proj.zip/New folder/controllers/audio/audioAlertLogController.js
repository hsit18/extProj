// Dependencies
var mongoose = require('mongoose');
var AlertLogModel = require('../../models/AlertLog');
var Promise = require('promise');
var RoomsModel = require('../../models/Rooms');
var roomsController = require('../Rooms/RoomsController').RoomsController;
var alertLogController = require('../AlertLog/AlertLogController').AlertLogController;
var behaviorController = require('../behavior/BehaviorController').BehaviorController;

function audioAlertLogController() {

}

/*Get Audio alert*/
audioAlertLogController.prototype.audioAlert = function (roomNo) {
    return new Promise(function (resolve, reject) {
        var curDate = new Date();
        var year = curDate.getFullYear();
        var month = curDate.getMonth();
        var date = curDate.getDate();
        var hour = curDate.getHours();
        var minute = curDate.getMinutes();
        var second = curDate.getSeconds();
        var dateToCheck = new Date(year, month, date, hour, minute-5, second);
        console.log("roomNo ====> "+roomNo);
        roomsController.getRoomIdByRoomNumber(roomNo).done(function (room) {
            if (room !== null && room !== undefined && room.length > 0) {
                alertLogController.getAllNewAlertLogByRoomId(room[0]._id, dateToCheck.toISOString()).done(function (alert) {
                    if (alert !== null && alert !== undefined && alert.length > 0) {
                        var check = new checkBehavior();
                        check.fightDetection(alert).done(function (err,isFightingDetected) {
                            resolve(isFightingDetected);
                        });
                    }
                    else{
                        resolve('no_alerts');
                    }
                });
            }
        });
    });
};

function checkBehavior() {

}

checkBehavior.prototype.fightDetection = function (alert) {
    return new Promise(function (resolve, reject) {
        var isFightingDetected = 0;
        var counter = 0;
        for (var i = 0; i < alert.length; i++) {
            //console.log("Before Edit Alert Log the ID is *****************" + alert[i].behavior_id);
            behaviorController.getBehaviorById(alert[i].behavior_id).done(function (behavior) {
                if (behavior !== null && behavior !== undefined && behavior.length > 0) {
                    //console.log("Behavior **********" + behavior[0].behavior);
                    if (behavior[0].behavior == 'fight') {
                        isFightingDetected++;
                    }
                }
                counter++;
                //console.log(counter + ' == ' + alert.length);
                if (counter == alert.length) {
                    //console.log('resolved');
                    resolve(isFightingDetected);
                }
            });
        }
    });
};

module.exports = {'audioAlertLogController': new audioAlertLogController()};