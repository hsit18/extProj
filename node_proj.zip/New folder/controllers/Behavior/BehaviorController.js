// Dependencies
var mongoose = require('mongoose');
var BehaviorModel = require('../../models/Behavior');
var Promise = require('promise');

function BehaviorController() {

}

//Get All Behavior
BehaviorController.prototype.getAllBehaviors= function () {
    return new Promise(function (resolve, reject) {
        BehaviorModel.find({}).sort({behavior:'ascending'}).lean().exec(function (err, behaviors) {
            if (err) {
                console.log('Error fetching all Behavior.');
                reject(err);
            } else {
                resolve(behaviors);
            }
        })
    });
};

//Get All Behavior By ID
BehaviorController.prototype.getBehaviorById = function (behaviorId) {
    return new Promise(function (resolve, reject) {
        BehaviorModel.find({ _id: behaviorId }).lean().exec(function (err, behaviors) {
            if (err) {
                console.log('Error fetching Behavior by Id.');
                reject(err);
            } else {
                resolve(behaviors);
            }
        })
    });
};

//Get Behavior By Name
BehaviorController.prototype.getBehaviorByName = function (behaviorName) {
    return new Promise(function (resolve, reject) {
        BehaviorModel.find({ behavior: behaviorName }).lean().exec(function (err, behavior) {
            if (err) {
                console.log('Error fetching Behavior by Name.');
                reject(err);
            } else {
                resolve(behavior);
            }
        })
    });
};

//Add Behavior
BehaviorController.prototype.addBehavior = function (behavior) {
    return new Promise(function (resolve, reject) {
        var behaviorDocument = new BehaviorModel(behavior);
        behaviorDocument.save(function (err, behaviors) {
            if (err) {
                console.log('Error while adding Behavior.');
                reject(err);
            } else {
                console.log('Behavior added successfully.');
                resolve(behaviors);
            }
        })
    });
};

//Edit Behavior
BehaviorController.prototype.editBehavior = function (id, behavior) {
    return new Promise(function (resolve, reject) {
        BehaviorModel.update({ _id: id }, behavior, { upsert: false }, function (err, numOfRows, behaviors) {
            if (err) {
                console.log('Error while updating Behavior.');
                reject(err);
            } else {
                console.log('Behavior updated successfully.');
                resolve(behaviors);
            }
        });
    });
};

//Delete Behavior
BehaviorController.prototype.deleteBehavior = function (id) {
    return new Promise(function (resolve, reject) {
        BehaviorModel.findByIdAndRemove(id, function (err, behavior) {
            if (err) {
                console.log('Error while deleting Behavior.');
                reject(err);
            } else {
                console.log('Behavior deleted successfully.');
                resolve(behavior);
            }
        });
    });
};


module.exports = { 'BehaviorController': new BehaviorController() }