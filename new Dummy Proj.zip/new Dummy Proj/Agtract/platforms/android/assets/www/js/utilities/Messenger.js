/*
 * Messenger:
 *      version: 1.0
 *      Cross Platform: true
 *      Initialization:
 *          Initializes on object creation.
 *      Date: 2/12/2015
 *      Functionality:
 *          Message transfer throughout the app
 */
define(["js/utilities/EventDispatcher"], function (EventDispatcher) {

    // Applying strict mode for variable declarations.
    "use strict";

    //class constructor
    function Messenger() {
        //Singleton - Please use getInstance().
        //call super constructor.
        EventDispatcher.call(this);
    }
    Messenger.constants = {
        // Dispatch a error.
        DISPATCH_ERROR: "dispatcherror"
            //PARTICIPANT_LIST_EVENT: 'participantlist'

    };

    // Make it singleton.
    Messenger.instance = null;
    Messenger.getInstance = function () {
        //console.log(Messenger.instance);
        if (Messenger.instance === null) {
            Messenger.instance = new Messenger();
        }
        return Messenger.instance;
    };
    //

    //subclass definition
    //the suggested location for this code is following the Messenger function
    Messenger.prototype = new EventDispatcher;
    Messenger.prototype.constructor = Messenger;

    // Returns the object that defines this module
    return Messenger;
});
