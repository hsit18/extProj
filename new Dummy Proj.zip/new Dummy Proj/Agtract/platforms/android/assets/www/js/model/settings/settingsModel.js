
define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Messenger',
        'js/utilities/Utility',
        'js/model/baseModel/baseModel',
        'jquery',
        'js/lib/jquery.md5'
    ],

    function (Backbone, CONSTANT, Messenger, Utility, baseModel, $, md5) {

    	var messengerObject, utilityObject,p=0;

    	var SettingsModel=baseModel.extend({

            initialize: function () {
                baseModel.prototype.initialize.call(this);
                messengerObject = Messenger.getInstance();
                this._utilityObject = new Utility();
            },

            getCurrentUserData: function () {

            	var $deferred = new $.Deferred();
                var that=this;
                var employeeID=this._utilityObject.getLocalStorageStringData(CONSTANT.DB.DB_CURRENT_USER);

            	that._DBManagerObject.open().done(function(){

            		that._DBManagerObject.select(CONSTANT.DB_TABLES.EMPLOYEES_TABLE,employeeID).done(function(responseObj) {
            			console.log("getCurrentUserData:select query success");
            			$deferred.resolve(responseObj);
            		}).fail(function(){
            			//select call fails
            			console.log("getCurrentUserData:select query failed")
            			$deferred.reject();
            		});
            	}).fail(function(){
            		//DB open call failed
            		$deferred.reject();
            	});

            	return $deferred.promise();
            },


           validateUpdatePasswordFields:function(currentPassword,newPassword,confirmPassword){

            //  sendPassword:function(){
                console.log("validatePasswordFields Called");
                var $deferred = new $.Deferred();
                var that=this;
                var employeeID=this._utilityObject.getLocalStorageStringData(CONSTANT.DB.DB_CURRENT_USER);

                if(!currentPassword){
                    messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_CURRENT_PASSWORD);
                    $deferred.reject();
                }else if(!newPassword){
                     messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_NEW_PASSWORD);
                    $deferred.reject();
                }else if(!confirmPassword){
                    ///show error
                     messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_CONFIRM_PASSWORD);
                    $deferred.reject();
                }
                else if(confirmPassword !== newPassword){
                     messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_CONFIRM_AND_NEW_PASSWORDS);
                    $deferred.reject();
                } else {

                    that._DBManagerObject.open().done(function(){

                    that._DBManagerObject.select(CONSTANT.DB_TABLES.USER_TABLE,employeeID).done(function(responseObj) {
                       
                        var tempUserTblObj=responseObj[0].value;
                        
                      //  console.log("Current Password--------------->>",tempEmployeeTblObj.password);
                        var oldUserPassword =  tempUserTblObj.password;
                        currentPassword =md5(currentPassword);
                        if(oldUserPassword===currentPassword){
                            newPassword =md5(newPassword);
                            if(oldUserPassword === newPassword){
                                //password cannot be same as of previous
                                messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_OLD_AND_NEW_PASSWORD);
                                $deferred.reject();
                            }else {

                            that._DBManagerObject.select(CONSTANT.DB_TABLES.EMPLOYEES_TABLE,employeeID).done(function(responseEmployeeObj) { 
                                 var tempEmployeeTblObj=responseEmployeeObj[0].value;
                                 tempEmployeeTblObj["password"]=newPassword;
                                 tempUserTblObj.password = newPassword;

                                $.when(
                                        that._DBManagerObject.update(CONSTANT.DB_TABLES.EMPLOYEES_TABLE, {
                                            key: responseEmployeeObj[0].key,
                                            value: tempEmployeeTblObj
                                        }, true),
                                        that._DBManagerObject.update(CONSTANT.DB_TABLES.USER_TABLE, {
                                            key: responseObj[0].key,
                                            value: tempUserTblObj
                                        })
                                    ).done(function(){
                                             that.processSyncNowService().done(function(){
                                                console.log("AT sync");
                                                $deferred.resolve();
                                            }).fail(function(){
                                                console.log("Failed To update in both tables");
                                                $deferred.reject();
                                            });
                                    }).fail(function(){
                                        console.log("updatePassword:failed:could not update users password to local DB");
                                        $deferred.reject();
                                    }); 
                            }).fail(function(){
                                //select call fails
                                console.log("Couldnt Employee Table");
                                $deferred.reject();
                            });                                
                            }
                            
                        }else{
                            messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_CURRENT_PASSWORD);   
                            $deferred.reject();
                        } 
                    }).fail(function(){
                        //select call fails
                        console.log("Couldnt Get Password");
                        $deferred.reject();
                    });
                }).fail(function(){
                    //DB open call failed
                    $deferred.reject();
                });


                }

                p++;

                return $deferred.promise();

            },

	        getNewProfilePicture:function(){
	        	var $deferred = new $.Deferred();
	        	if(navigator.camera){
                	navigator.camera.getPicture(function(proPicURL){
                		//camera success
                		console.log("pro pic url!!!");
        				console.log(proPicURL);
        				$deferred.resolve(proPicURL)
                	},
                	function(message){
                		//camera not succesful
                		console.log("camera failed!!!");
        				console.log(message);
        				messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR,message);
        				$deferred.reject();
                	}, 
                	{
                		//this.cameraSuccess, this.cameraError, {
                        quality : 60, 
                        destinationType : Camera.DestinationType.NATIVE_URI,
                        sourceType : Camera.PictureSourceType.PHOTOLIBRARY,
                        targetWidth: 140,
                        targetHeight: 140,
                    });
            	} else {
            		messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR,"Gallery Could not be opened!!!");
            		$deferred.reject();
            	}
            	return $deferred.promise();
	        },

            updateNewProfilePicture:function(newPicLocalDevicePath){
                var $deferred = new $.Deferred(),
                    that=this,
                    employeeID=this._utilityObject.getLocalStorageStringData(CONSTANT.DB.DB_CURRENT_USER);
                
                that._DBManagerObject.open().done(function(){

                    that._DBManagerObject.select(CONSTANT.DB_TABLES.EMPLOYEES_TABLE,employeeID).done(function(responseObj) {
                        console.log("updateNewProfilePicture:select query success");
                        
                        var tempObj=responseObj[0].value;
                        tempObj.avatar_data="true";
                        tempObj.avatar=newPicLocalDevicePath;
                        console.log(tempObj); 
                        that._DBManagerObject.update(CONSTANT.DB_TABLES.EMPLOYEES_TABLE, {
                            key: responseObj[0].key,
                            value: tempObj
                        }).done(function () {
                            localStorage.setItem('pic_change_path', newPicLocalDevicePath);
                            that.processSyncNowService().done(function(){
                                $deferred.resolve();
                            });
                            console.log("update success pro pic");
                        }).fail(function(){
                            console.log("updateNewProfilePicture:failed:could not update users pro pic to local DB");
                            $deferred.reject();
                        });                        

                    }).fail(function(){
                        //select call fails
                        console.log("updateNewProfilePicture:select query failed")
                        $deferred.reject();
                    });
                }).fail(function(){
                    //DB open call failed
                    $deferred.reject();
                });

                return $deferred.promise();
            },

	        validateNamePhoneNumber:function(Empname,phoneNumber){
	        	var $deferred = new $.Deferred();
	        	var regEx= /^\d+$/;
                if(Empname && phoneNumber){

                    if(phoneNumber.length === 10){
                        if(regEx.test(phoneNumber)){
                           $deferred.resolve();
                        } else {
                            messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_PHONENUMBER);  
                            $deferred.reject();  
                    }

                } else {
                    messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_PHONENUMBER_DIGITS);
                    $deferred.reject();
                }

                }else{
                    messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_PHONENUMBER_NAME);
                    $deferred.reject();
                }
	        	
	        	return $deferred.promise();
	        },

	        updateEmployeeNamePhoneNumber:function(Empname,phoneNumber){
	        	var $deferred = new $.Deferred();
                var that=this;
                var employeeID=this._utilityObject.getLocalStorageStringData(CONSTANT.DB.DB_CURRENT_USER);

	        	that._DBManagerObject.open().done(function(){

            		that._DBManagerObject.select(CONSTANT.DB_TABLES.EMPLOYEES_TABLE,employeeID).done(function(responseObj) {
            			
            			var tempObj=responseObj[0].value;
                        tempObj.name =Empname;
            			tempObj.mobile =phoneNumber;
                        
            		//	console.log("Employee Object with Updated Records------->>",tempObj); 
            			that._DBManagerObject.update(CONSTANT.DB_TABLES.EMPLOYEES_TABLE, {
                        	key: responseObj[0].key,
                            value: tempObj
                        },true).done(function () {
                        	   that.processSyncNowService().done(function(){
                                $deferred.resolve(tempObj);
                            });	
                        }).fail(function(){
                        //	console.log("updatePhoneNumber:failed:could not update users phone to local DB");
                        	$deferred.reject();
                        });
            			

            		}).fail(function(){
            			//select call fails
            			console.log("updatePhoneNumber:select query failed")
            			$deferred.reject();
            		});
            	}).fail(function(){
            		//DB open call failed
            		$deferred.reject();
            	});

            	return $deferred.promise();
	        }
        });

        return SettingsModel;
    });
