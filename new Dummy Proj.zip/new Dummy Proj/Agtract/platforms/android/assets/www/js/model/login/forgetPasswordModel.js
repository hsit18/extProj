/**
 * Forget Password Model:
 * Cross Platform: True.
 * Initialization:
 * Date: 2/12/2015
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/Constant',
        'js/model/baseModel/baseModel',
        'js/utilities/Utility',
        'jquery'
    ],

    function (Backbone, CONSTANT, baseModel, Utility, $) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';

        var forgetPasswordModel = baseModel.extend({

            initialize: function () {
                baseModel.prototype.initialize.call(this);
            },

            getForgetPasswordResponse: function (userName, emailId) {
                var that = this;
                var $deferred = new $.Deferred();

                that.processForgetPasswordResponse(userName, emailId).done(function (response) {
                    $deferred.resolve(response);
                }).fail(function () {
                    $deferred.reject();
                });
                return $deferred.promise();
            }
        });

        return forgetPasswordModel;
    });
