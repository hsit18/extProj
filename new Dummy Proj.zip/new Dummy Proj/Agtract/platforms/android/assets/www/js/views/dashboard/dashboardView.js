/**
 * Dashboard View:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Messenger',
        'js/utilities/DbManager',
        'js/utilities/Utility',
        'js/model/dashboard/dashboardModel',
        'js/lib/idangerous.swiper',
        'text!templates/dashboard.html'
    ],
    //$('div').drags();
    function (Backbone, CONSTANT, Messenger, DBManager, Utility, DashboardModel, Swiper, dashboardTempl) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';

        var messengerObject, utilityObject, vehicleSwiper, equipmentSwiper;

        var DashboardView = Backbone.View.extend({

            el: null,

            initialize: function () {

                messengerObject = Messenger.getInstance();
                this.utilityObject = new Utility();
                this.utilityObject.showLoader();
                this.dashboardModel = new DashboardModel();
                //this.utilityObject.getTimeDifferenceRecords(new Date('2015-12-28 20:58:00').getTime(), new Date('2015-12-31 11:58:00').getTime());
                this.fetchDashboardData();
                //this.render();

            },
            events: {

            },

            addEventListener: function () {
                $('#completedJob').unbind('click');
                $('#completedJob').bind('click', this.loadCompletedJob);
                
                $('#clockIn').unbind('click');
                $('#clockIn').bind('click', {'context': this}, this.getTimeStamp);
                $('#clockOut').unbind('click');
                $('#clockOut').bind('click', {'context': this}, this.getTimeStampOut);
            },

            // Render the view.
            render: function (employeeDashboardData) {

                console.log("Rendering dashboard template----------------",employeeDashboardData);
                this.$el = $('#pagecontainerDiv');
                var template = _.template(dashboardTempl, employeeDashboardData);
                this.$el.html(template);

                var isLoopEquipment = false,
                    isLoopVehicle = false;

                if(employeeDashboardData && employeeDashboardData.equipments && employeeDashboardData.equipments.length>1){
                    isLoopEquipment = true;
                } 

                if(employeeDashboardData && employeeDashboardData.vehicles && employeeDashboardData.vehicles.length>1){
                    isLoopVehicle = true;
                }

                vehicleSwiper = new Swiper('.swiper-container', {
                    pagination: '.pagination',
                    loop: isLoopVehicle,
                    paginationClickable: true,
                    autoplay: false,
                    speed: 500,
                    autoplayDisableOnInteraction: false
                });
                equipmentSwiper = new Swiper('.swiper-container1', {
                    pagination: '.pagination1',
                    loop: isLoopEquipment,
                    paginationClickable: true,
                    autoplay: false,
                    speed: 500,
                    autoplayDisableOnInteraction: false
                });

                this.utilityObject.hideLoader();
                this.addEventListener();               
            },
            
            fetchDashboardData: function () {
                var that = this;

                that.dashboardModel.getEmployeeData().done(function (responseObj) {

                    var employeeData = responseObj;

                    console.log("--------------------------->>>>>>>>>>>>>", employeeData.contractor_id);

                    localStorage.setItem("contractor_id", employeeData.contractor_id);

                    that.dashboardModel.fetchUserDashboardData().done(function (response) {
                        response['employeeData'] = employeeData;
                        console.log("-----------", response);
                        that.render(response);
                    }).fail(function () {
                        console.log("failed to bring the data from the temp folder");
                    });
                }).fail(function () {
                    console.log("failed to bring the data from the temp folder");
                });
            },

            loadCompletedJob: function () {
                router.navigate('completedJob', {
                    trigger: true
                });
            },
        
            getTimeStamp: function (event) {
                var timeStamp = new Date().getTime();

                var that = event.data.context;
                
                // check internet connection
                that.utilityObject.checkConnection().done(function(isOnline){
                    if(isOnline){
                        // call to addTimestamp() method in dashboard model
                        that.dashboardModel.addTimeStamp(timeStamp).done(function () {
                            $('#clockIn').addClass("disabled");
                            $('#clockOut').removeClass("disabled");
                            //that.utilityObject.showLoader();
                            //that.fetchDashboardData();
                        }).fail(function () {
                            that.utilityObject.showLoader();
                        });
                    } else {
                        console.log("no internet");
                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.NO_CONNECTIVITY_ERROR);
                    }
                }).fail(function(){
                    console.log("no internet");
                });
            },

            getTimeStampOut: function (event) {
                var timeStampOut = new Date().getTime();

                var that = event.data.context;
                
                // check internet connection
                that.utilityObject.checkConnection().done(function(isOnline){
                    if(isOnline){
                        // call to addTimestampOut() method in dashboard model
                        that.dashboardModel.addTimeStampOut(timeStampOut).done(function () {
                            $('#clockOut').addClass("disabled");
                            $('#clockIn').removeClass("disabled");
                            that.utilityObject.showLoader();
                            that.fetchDashboardData();
                        }).fail(function () {
                            that.utilityObject.showLoader();
                        });
                    } else {
                        console.log("no internet");
                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.NO_CONNECTIVITY_ERROR);
                    }
                }).fail(function(){
                    console.log("no internet");
                });
            }
        });
        return DashboardView;
    });