/*
 * Error Handler:
 *      version: 1.0
 *      Cross Platform: true
 *      Initialization:
 *          Initializes on object creation.
 *      Date: 2/12/2015
 *      Functionality:
 *          Displays the error message.
 */

// Require JS modular pattern having dependencies of Messenger module.
define(["js/utilities/Messenger", "js/utilities/Constant"], function (Messenger, CONSTANT) {

    // Applying strict mode for variable declarations.
    "use strict";

    // Here is where it starts - The Constructor.
    function ErrorHandler() {
        // Creating the private scope object of this module.
        this._scopeObj = {
            context: this
        };

        // Class properties.
        this._message = null;
        this._messengerObject = null;
        this._type = null;

        // Let the execution begin!
        this._init();
    }

    // Initializes the properties and triggers event binding.
    ErrorHandler.prototype._init = function () {
        this._messengerObject = Messenger.getInstance();
        this._addEventListener();
    };

    // Set the error message.
    ErrorHandler.prototype.setMessage = function (message) {
        if (message) {
            this._message = message;
        }
    };

    // Get the error message.
    ErrorHandler.prototype.getMessage = function () {
        return (this._message) ? this._message : "";
    };

    // Set the error type.
    ErrorHandler.prototype.setType = function (type) {
        if (!type) {
            this._type = type;
        }
    };

    // Get the error type.
    ErrorHandler.prototype.getType = function () {
        return (this._type) ? this._type : "";
    };

    // Adding event listeners to this module.
    ErrorHandler.prototype._addEventListener = function () {
        this._messengerObject.removeEventListener(Messenger.constants.DISPATCH_ERROR);
        this._messengerObject.addEventListener(Messenger.constants.DISPATCH_ERROR, this._scopeObj, this._displayErrorHandler);
    };

    // The culprit is displayed here.
    ErrorHandler.prototype._displayErrorHandler = function (event, message, type) {
        var that = event.data.context;

        //navigator.notification.alert(message,function(){ console.log(" ErrorHandler : _displayErrorHandler : "+ message); },"Agtract","OK");
        if (navigator.notification) {
            navigator.notification.alert(message, function () {
                console.log(" ErrorHandler : _displayErrorHandler : " + message);
            }, "Agtract", "OK");
        } else {
            alert(message);
        }

    };

    // Return the class object.
    return ErrorHandler;
});
