/**
 * Login View:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:2/12/2015
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Messenger',
        'js/utilities/Utility',
        'js/model/login/loginModel',
        'js/utilities/ErrorHandler',
        'text!templates/login.html'
    ],

    function (Backbone, CONSTANT, Messenger, Utility, loginModel, ErrorHandler, loginTempl) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';

        var messengerObject, utilityObject, loginModelObject;

        var loginView = Backbone.View.extend({

            el: $('#dashboardContainer'),

            initialize: function () {

                // messengerObject = Messenger.getInstance();
                this.utilityObject = new Utility();
                var errorObj = new ErrorHandler();

                this.render();
            },
            events: {
                //'click #Submit_login': 'loadDashdoard',
            },

            addEventListener: function () {
                this.$("#Submit_login").unbind('click');
                this.$("#Submit_login").bind('click', {
                    'context': this
                }, this.loadDashdoard);
                this.$("#Forgot_password").unbind('click');
                this.$("#Forgot_password").bind('click', this.loadForgetPassword);
            },

            // Render the view.
            render: function () {

                var template = _.template(loginTempl, {
                    'headerText': 'Login Page'
                });
                this.$el.html(template);
                this.addEventListener();
            },

            loadDashdoard: function (event) {
                var $deferred = new $.Deferred();
                var username = $('#username').val();
                var password = $('#pass').val();
                var that = event.data.context;
                that.utilityObject.showLoader();
                loginModelObject = new loginModel();

                loginModelObject.checkForLoginDetails(username, password).done(function () {
                    router.navigate('home', {
                        trigger: true
                    });
                    $deferred.resolve();
                }).fail(function (errorMessage) {
                    that.utilityObject.hideLoader();
                    $deferred.reject();
                });

                return $deferred.promise();

            },

            loadForgetPassword: function () {
                router.navigate('forgetPassword', {
                    trigger: true
                });
            }
        });
        return loginView;
    });
