/*
 * Event Dispatcher:
 *      version: 1.0
 *      Cross Platform: true
 *      Initialization:
 *          Initializes on object creation.
 *      Date: 2/12/2015
 *      Functionality:
 *          Dispatches the events
 */
define([], function () {

    // Applying strict mode for variable declarations.
    "use strict";

    //class constructor
    function EventDispatcher() {
        //private property (by naming convention only)
        //Internally, we are going to keep a free-standing DOM
        //node to power our event mechanism using jQuery's
        //bind/trigger functionality.
        //NOTE: We are using a custom node type here so that we
        //don't have any unexpected event behavior based on the
        //node type.
        this._eventElement = $(document.createElement("eventelement"));

        //Create a help collection of bound event types.
        this._eventElement.data("preTrigger", {});
    }

    //private method (by naming convention only)
    //This is the first handler to be bound on this object for any
    //event type. I change the target property to be the EventDispatcher
    //instance, not the DOM node.
    EventDispatcher.prototype._preTrigger = function (event) {
        //Mutate the event to point to the right target.
        event.target = this;
    };
    //public method
    //eventType is a string
    //callback is a function
    //example usage: addEventListener("customEventName", {context:this}, this._functionName);
    EventDispatcher.prototype.addEventListener = function (eventType, callback) {
        //Check to see this event type has a pre-trigger
        //interceptor yet. Since event handlers are triggered
        //in the order in which they were bound, we can be sure
        //that our _preTrigger goes first.
        if (!this._eventElement.data("preTrigger")[eventType]) {
            //We need to bind the pre-trigger first so it can
            //change the target appropriately before any other
            //event handlers get triggered.
            this._eventElement.bind(eventType, jQuery.proxy(this._preTrigger, this));

            //Keep track of the event type so we don't re-bind this _preTrigger.
            this._eventElement.data("preTrigger")[eventType] = true;
        }

        //Replace the callback function with a proxied callback that
        //will execute in the context of this EventDispatcher object.
        arguments[arguments.length - 1] = jQuery.proxy(arguments[arguments.length - 1], this);

        //Now, when passing the execution off to bind(), we will
        //apply the arguments; this way, we can use the optional
        //data argument if it is provided.
        jQuery.fn.bind.apply(this._eventElement, arguments);

        //Return this object reference for method chaining.
        return this;
    };
    //

    //public method
    //eventType is a string
    //callback is a function
    //example usage: removeEventListener("customEventName", this._functionName);
    EventDispatcher.prototype.removeEventListener = function (eventType, callback) {
        //Pass the unbind() request onto the _eventElement.
        this._eventElement.unbind(eventType, callback);

        //Return this object reference for method chaining.
        return this;
    };
    //

    //public method
    //eventType is a string
    //dataArray is an array of optional arguments
    //example usage: dispatchEvent("customEventName", [arg1, arg2]);
    EventDispatcher.prototype.dispatchEvent = function (eventType, dataArray) {
        console.log('Dispatched Event: ' + eventType);
        //Pass the trigger() request onto the _eventElement.
        this._eventElement.trigger(eventType, dataArray);

        //Return this object reference for method chaining.
        return this;
    };
    //

    //public method
    //eventType is a string
    //dataArray is an array of optional arguments
    //example usage: dispatchDelayedEvent("customEventName", [arg1, arg2]);
    EventDispatcher.prototype.dispatchDelayedEvent = function (eventType, dataArray) {
        var that = this;
        //Pass the trigger() request onto the _eventElement, only after breaking call chain.
        setTimeout(function () {
            that._eventElement.trigger(eventType, dataArray);
        }, 0);

        //Return this object reference for method chaining.
        return this;
    };
    //

    // Returns the object that defines this module
    return EventDispatcher;
});
