define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Messenger',
        'js/utilities/Utility',
        'js/utilities/ErrorHandler',
        'js/lib/draggable',
        'js/model/draggable/draggableModel',
        'text!templates/draggable.html'
    ],

    function (Backbone, CONSTANT, Messenger, Utility, ErrorHandler, drags, DraggableModel, draggableTempl) {

        var eventType = {
            click: null,
            mousemove: null,
            mousedown: null,
            mouseup: null
        };

        var DraggableView = Backbone.View.extend({

            el: $('#dashboardContainer'),

            initialize: function () {
                this.draggablemodelObject = new DraggableModel();
                this.render();
            },

            events: {

            },

            addEventListener: function () {
                $("#draggable-cj").unbind("touchend");
                $("#draggable-cj").bind("touchend",{'context': this},this.onCurrentJobDraggableClicked);

                $("#draggable-cj").unbind("click");
                $("#draggable-cj").bind("click",{'context': this},this.onCurrentJobDraggableClicked);

                $("#currentTasks").unbind("click");
                $("#currentTasks").bind("click",{'context': this},this.loadCurrentTasks);
            },

            // Render the view.
            render: function () {    

                var that = this;            

                that.getCurrentJobData().done(function(currentTaskData){

                    if(currentTaskData){
                        var obj= {"data": currentTaskData};
                        var template = _.template(draggableTempl, obj);
                        that.$el.append(template); //.html(template);
                        $('#draggable-cj').show();
                        $('#draggable-cj').drags({}, function(){
                            isAllowToShowCurrentJob = true;
                        });
                        that.addEventListener();
                    } else {
                        $('#draggable-cj').hide();
                    }
                }).fail(function(){
                    console.log("failed load data");
                });                
            },

            onCurrentJobDraggableClicked: function (event) {
                var that = this;
                console.log("onCurrentJobDraggableClicked");
                if(isAllowToShowCurrentJob === true) {
                    console.log("isAllowToShowCurrentJob --- " +isAllowToShowCurrentJob);
                    console.log("click");
                    console.log(event);
                    $("#popup-overlay").show();
                    $('#myModal').modal('show');
                    $('#myModal').on('hide.bs.modal', function(){
                       $("#popup-overlay").hide();
                    });                    
                }                
            },

            getCurrentJobData: function() {
                var that = this,
                    $deferred = new $.Deferred();

                that.draggablemodelObject.currentJobData().done(function(data){
                    console.log("current task data", data);                    
                    $deferred.resolve(data);
                }).fail(function(){
                    console.log("failed to get current job data");
                    $deferred.reject();
                });

                return $deferred.promise();
            },

            loadCurrentTasks: function(event){
                var that = event.data.context;
                $('#myModal').modal('hide');
                router.navigate("/", {
                    trigger: false
                });
                router.navigate("manageJobs", {
                    trigger: true
                });
            }

        });

        return DraggableView;
    });
