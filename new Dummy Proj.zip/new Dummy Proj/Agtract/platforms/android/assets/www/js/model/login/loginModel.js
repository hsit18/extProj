/**
 * Login Model:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:2/12/2015
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Messenger',
        'js/utilities/Utility',
        'js/model/baseModel/baseModel',
        'jquery',
        'js/lib/jquery.md5'
    ],

    function (Backbone, CONSTANT, Messenger, Utility, baseModel, $, md5) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';

        var messengerObject, utilityObject;

        var loginModel = baseModel.extend({

            initialize: function () {
                baseModel.prototype.initialize.call(this);
                messengerObject = Messenger.getInstance();
                this._utilityObject = new Utility();
            },

            checkForLoginDetails: function (username, password) {

                var $deferred = new $.Deferred(),
                    that = this;
                if (password) {
                    password = md5(password);
                }

                //console.log(md5(password));
                this.validateFields(username, password).done(function () {
                    //user name and password are not blak
                    //console.log("checkForLoginDetails:validate fields success");
                    that.checkUser(username, password).done(function () {
                        console.log("checkForLoginDetails:checkUser success");
                        $deferred.resolve();
                    }).fail(function () {
                        console.log("checkForLoginDetails:checkUser fail")
                            //Show error
                        $deferred.reject();
                    });
                }).fail(function () {
                    //fail either usernamr or password is blank
                    //Show error
                    console.log("checkForLoginDetails:validate fields fail");
                    $deferred.reject();
                });
                return $deferred.promise();
            },

            validateFields: function (username, password) {

                var $deferred = new $.Deferred();
                if (username === "") {
                    messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_USERNAME);
                    $deferred.reject();
                } else if (password === "") {
                    messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_PASS);
                    $deferred.reject();
                } else {
                    $deferred.resolve();
                }
                return $deferred.promise();
            },

            checkUser: function (username, password) {

                var $deferred = new $.Deferred(),
                    that = this;

                this._utilityObject.checkConnection().done(function (isOnline) {

                    if (isOnline && isOnline === true) {
                        that.validateLoginCredentialsOnline(username, password).done(function (responseObj) {
                            //user validation successful
                            console.log("validateLoginCredentialsOnline:success");
                            if (responseObj && responseObj.employee_id) {

                                var tempObject = {};
                                tempObject.employee_id = responseObj.employee_id;
                                tempObject.username = username;
                                tempObject.password = password;
                                //to maintain user's session we store its user ID along with its timestamp
                                localStorage.setItem("currentUserID", tempObject.employee_id);
                                //console.log(tempObject);
                                that.createAndUpdateUserInfo(tempObject).done(function () {
                                    $deferred.resolve();
                                }).fail(function () {
                                    $deferred.reject();
                                });
                            } else {
                                //messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, errorMessage);
                                $deferred.reject();
                            }

                        }).fail(function (errorMessage) {
                            //user validation failed from server show error message,either user name or password is wrong
                            if (errorMessage) {
                                messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, errorMessage);
                            }
                            $deferred.reject();
                        });
                    } else {
                        //console.log("user is not online");
                        that.validateUserFromLocalDatabase(username, password).done(function (response) {
                            //local database validation success show dashboard page for that user
                            console.log("checkUser:validateUserFromLocalDatabase success");
                            //console.log(response);
                            if (response === true) {
                                //user name and passwords are correct and validated from local DB
                                //hit sync now service
                                //and show dashboard page for that particular user
                                router.navigate('home', {
                                    trigger: true
                                });
                                $deferred.resolve();
                            }
                            if (response === false) {
                                //username or password do not match with the database entries
                                //throw error user name or password invalid
                                messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_USER_OR_PASS);
                                $deferred.reject();
                            }
                        }).fail(function (error) {
                            //throw connection error
                            //it will come here if the app is freshly installed and there is no user table entry
                            //so select query will fail and defer will return with failure
                            //once user table is created it will always go to success callback with true or false return values
                            messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_USER_OR_PASS);
                            $deferred.reject();
                        });
                    }
                });

                return $deferred.promise();
            },

            validateLoginCredentialsOnline: function (username, password) {
                var $deferred = new $.Deferred();

                this.processLoginResponse(username, password).done(function (responseObj) {
                    $deferred.resolve(responseObj);
                }).fail(function (errorMessage) {
                    $deferred.reject(errorMessage);
                });
                return $deferred.promise();
            },

            validateUserFromLocalDatabase: function (username, password) {

                var $deferred = new $.Deferred(),
                    that = this;
                this._DBManagerObject.open().done(function (status) {
                    //database exists fire select query
                    that._DBManagerObject.select(CONSTANT.DB_TABLES.USER_TABLE).done(function (responseObj) {
                        console.log("validateUserFromLocalDatabase:DB Success responseObj:");
                        //console.log(responseObj);
                        _.each(responseObj, function (object) {
                            //console.log(object.value.username);
                            if (username === object.value.username && password === object.value.password) {
                                $deferred.resolve(true); //username password match return true
                                localStorage.setItem("currentUserID", object.value.employee_id);
                            }
                        });
                        $deferred.resolve(false); //username password dont match return false
                    }).fail(function (error) {
                        //select query fails
                        console.log("validateUserFromLocalDatabase:select query fails");
                        $deferred.reject(false);
                    });

                });
                /*.fail(function (status) {
                                    //database itself does not exists
                                    //this fail will not trigger because if DB does not exists it will be created
                                    console.log("validateUserFromLocalDatabase:database does not exists");
                                    $deferred.reject(status);
                                });*/
                return $deferred.promise();
            },

            createAndUpdateUserInfo: function (userInfo) {
                var $deferred = new $.Deferred();
                var that = this;

                that._DBManagerObject.open().done(function (status) {
                    that._DBManagerObject.createTables([CONSTANT.DB_TABLES.USER_TABLE]).done(function (status) {
                        //console.log("status of table creation:"+status);

                        that._DBManagerObject.select(CONSTANT.DB_TABLES.USER_TABLE, userInfo.employee_id).done(function (responseObj) {
                            console.log("fetch data from data suceess:DB Success responseObj:");
                            //console.log(responseObj);
                            if (_.isEmpty(responseObj)) { //the user table is empty or record does not exists
                                //insert the current userInfo record into the user table 
                                //and navigate to dashboard page after making entry for currentUserID in local storage
                                userInfo.isFirstTimelogin = true;
                                var obj = {
                                    key: userInfo.employee_id,
                                    value: userInfo
                                };
                                that._DBManagerObject.insert(CONSTANT.DB_TABLES.USER_TABLE, [obj]).done(function () {
                                    console.log("new record inserted into Users table successfully");
                                    that.processDownloadDataService().done(function (response) {
                                        $deferred.resolve();
                                    }).fail(function () {
                                        console.log("createAndUpdateUserInfo:processDownloadDataService:failed");
                                        $deferred.reject();
                                    });
                                });

                            } else {
                                //there is one record in the user table
                                //that matches so update it
                                var tempObj = responseObj[0].value;
                                tempObj.username = userInfo.username;
                                tempObj.password = userInfo.password;
                                tempObj.isFirstTimelogin = false;
                                that._DBManagerObject.update(CONSTANT.DB_TABLES.USER_TABLE, {
                                    key: responseObj[0].key,
                                    value: tempObj
                                }).done(function () {
                                    console.log("record updated into Users table successfully");
                                    //For this Sprint only. Remove it if delta and sync service is implemented.
                                    that.processDownloadDataService().done(function (response) {
                                        $deferred.resolve();
                                    }).fail(function () {
                                        console.log("createAndUpdateUserInfo:processDownloadDataService:failed");
                                        $deferred.reject();
                                    });

                                }).fail(function (error) {
                                    console.log("update record failed");
                                    console.log(error);
                                    $deferred.reject();
                                });
                            }

                        }).fail(function (error) {
                            //select query fails
                            console.log("validateUserFromLocalDatabase:select query fails");
                            $deferred.reject();
                        });

                    }).fail(function () {
                        //create table call fails
                        $deferred.reject();
                    });
                }).fail(function (status) {
                    //DB open call fails
                    $deferred.reject();
                });
                return $deferred.promise();
                //write success and done call back for create and update user
                //navigate depending on succes or failure
            }
        });
        return loginModel;
    });
