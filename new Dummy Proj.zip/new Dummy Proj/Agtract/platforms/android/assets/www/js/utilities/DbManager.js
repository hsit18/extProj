/*
 * DbManager:
 *      version: 1.0
 *      Cross Platform: true
 *      Initialization:
 *          Initializes on object creation.
 *      Date: 2/12/2015
 *      Functionality:
 *          Initializes appropriate database object depending on the support provided by the browser.
 */

// Module begins here.
define(["i18n!js/nls/str",
        "js/utilities/WebSql",
        "js/utilities/IndexedDb",
        "js/utilities/Constant"
    ],
    function (INTERNATIONALIZATION, webSQLObj, indexedDbObj, CONSTANT) {

        // Applying strict mode for variable declarations.
        "use strict";

        function DbManager() {
            this._dBType = this.init();
            this._dBObj = new this._dBType();
        }

        DbManager.prototype.init = function () {
            //check for webSQL support
            if (!!window.openDatabase) {
                return webSQLObj;
            }
            //check for indexedDB support
            else if (window.indexedDB) {
                return indexedDbObj;
            } else {
                alert(INTERNATIONALIZATION.ERROR_CREATING_DB);
                return;
            }
        };

        DbManager.prototype.open = function () {
            var $deferred = new $.Deferred(),
                that = this;
            this._dBObj.open().done(function (status) {
                $deferred.resolve(status);
            }).fail(function (error) {
                $deferred.resolve(error);
            });
            return $deferred.promise();
        };

        DbManager.prototype.createTables = function (tablenameArray) {
            var $deferred = new $.Deferred(),
                that = this;
            this._dBObj.createTables(tablenameArray).done(function (response) {
                $deferred.resolve(response);
            }).fail(function (error) {
                $deferred.resolve(error);
            });
            return $deferred.promise();
        };

        DbManager.prototype.select = function (tablename, key) {
            var $deferred = new $.Deferred(),
                that = this;
            this._dBObj.select(tablename, key).done(function (response) {
                $deferred.resolve(response);
            }).fail(function (error) {
                $deferred.resolve(error);
            });
            return $deferred.promise();
        };

        DbManager.prototype.insert = function (tablename, objArray, isValidOffineRecord) {

            var $deferred = new $.Deferred(),
                that = this;

            this._dBObj.insert(tablename, objArray).done(function (response) {

                if (isValidOffineRecord && isValidOffineRecord === true) {
                    that.insertInQueue(tablename, objArray).done(function (res) {
                        $deferred.resolve(response);
                    })
                } else {
                    $deferred.resolve(response);
                }
            }).fail(function (error) {
                $deferred.resolve(error);
            });

            return $deferred.promise();
        };

        DbManager.prototype.update = function (tablename, updateRequestObject, isValidOffineRecord) {
            var $deferred = new $.Deferred(),
                that = this;
            this._dBObj.update(tablename, updateRequestObject).done(function (response) {

                if (isValidOffineRecord && isValidOffineRecord === true) {
                    that.updateInQueue(tablename, updateRequestObject).done(function (res) {
                        $deferred.resolve(response);
                    })
                } else {
                    $deferred.resolve(response);
                }
            }).fail(function (error) {
                $deferred.resolve(error);
            });
            return $deferred.promise();
        };

        DbManager.prototype.remove = function (tablename, key, isValidOffineRecord) {

            var $deferred = new $.Deferred(),
                that = this;

            this._dBObj.remove(tablename, key).done(function (response) {

                if (isValidOffineRecord && isValidOffineRecord === true) {
                    that.removeInQueue(tablename, [key]).done(function (res) {
                        $deferred.resolve(response);
                    })
                } else {
                    $deferred.resolve(response);
                }
            }).fail(function (error) {
                $deferred.resolve(error);
            });
            return $deferred.promise();
        };

        DbManager.prototype.removeMultiple = function (tablename, keyArray, isValidOffineRecord) {

            var $deferred = new $.Deferred(),
                that = this;

            this._dBObj.removeMultiple(tablename, keyArray).done(function (response) {
                if (isValidOffineRecord && isValidOffineRecord === true) {
                    that.removeInQueue(tablename, keyArray).done(function (res) {
                        $deferred.resolve(response);
                    })
                } else {
                    $deferred.resolve(response);
                }
            }).fail(function (error) {
                $deferred.resolve(error);
            });
            return $deferred.promise();
        };

        DbManager.prototype.insertInQueue = function (tablename, tableObjArray) {
            var $deferred = new $.Deferred(),
                that = this,
                queueObjArray = [],
                obj = {},
                objVal = {},
                currentUserId = localStorage.getItem('currentUserID');;

            for (var record in tableObjArray) {

                obj = {};
                objVal = {};

                obj.key = tablename + '-' + tableObjArray[record].key;

                objVal = $.extend({}, tableObjArray[record].value);
                objVal[CONSTANT.QUEUE_RECORD_FIELDS.RECORD_STATUS] = CONSTANT.QUEUE_RECORD_STATUS.CREATED;
                objVal[CONSTANT.QUEUE_RECORD_FIELDS.TABLE_NAME] = tablename;
                objVal[CONSTANT.QUEUE_RECORD_FIELDS.QUEUE_EMPLOYEE_ID] = currentUserId;
                obj.value = objVal;
                queueObjArray.push(obj)
            }

            console.log("queueObjArray ===== " + JSON.stringify(queueObjArray));

            this._dBObj.insert(CONSTANT.DB_TABLES.QUEUE_TABLE, queueObjArray).done(function (response) {
                $deferred.resolve(response);
            }).fail(function (error) {
                $deferred.resolve(error);
            });
            return $deferred.promise();
        };

        DbManager.prototype.updateInQueue = function (tablename, tableUpdateRequestObject) {

            var $deferred = new $.Deferred(),
                that = this,
                queueObjArray = [],
                obj = {},
                objVal = {},
                currentUserId = localStorage.getItem('currentUserID'),
                searchKey = tablename + '-' + tableUpdateRequestObject.key;

            this._dBObj.select(CONSTANT.DB_TABLES.QUEUE_TABLE, searchKey).done(function (response) {

                console.log(searchKey + "updateInQueue record found ---- ", response);

                obj = {};
                objVal = {};

                obj.key = tablename + '-' + tableUpdateRequestObject.key;

                objVal = $.extend({}, tableUpdateRequestObject.value);
                
                if (response && response.length > 0 && response[0].value) {
                    var foundQueueObj = response[0].value;
                    
                    objVal[CONSTANT.QUEUE_RECORD_FIELDS.RECORD_STATUS] = foundQueueObj[CONSTANT.QUEUE_RECORD_FIELDS.RECORD_STATUS];
                    objVal[CONSTANT.QUEUE_RECORD_FIELDS.TABLE_NAME] = foundQueueObj[CONSTANT.QUEUE_RECORD_FIELDS.TABLE_NAME];
                    objVal[CONSTANT.QUEUE_RECORD_FIELDS.QUEUE_EMPLOYEE_ID] = foundQueueObj[CONSTANT.QUEUE_RECORD_FIELDS.QUEUE_EMPLOYEE_ID];
                    obj.value = objVal;
                    
                    console.log("updateInQueue queueObjArray update ===== " + JSON.stringify(obj));

                    that._dBObj.update(CONSTANT.DB_TABLES.QUEUE_TABLE, obj).done(function (response) {
                        $deferred.resolve(response);
                    }).fail(function (error) {
                        $deferred.resolve(error);
                    });

                } else {
                    
                    objVal[CONSTANT.QUEUE_RECORD_FIELDS.RECORD_STATUS] = CONSTANT.QUEUE_RECORD_STATUS.UPDATED;
                    objVal[CONSTANT.QUEUE_RECORD_FIELDS.TABLE_NAME] = tablename;
                    objVal[CONSTANT.QUEUE_RECORD_FIELDS.QUEUE_EMPLOYEE_ID] = currentUserId;
                    obj.value = objVal;

                    queueObjArray.push(obj);
                    console.log("updateInQueue queueObjArray insert ===== " + JSON.stringify(queueObjArray));

                    that._dBObj.insert(CONSTANT.DB_TABLES.QUEUE_TABLE, queueObjArray).done(function (response) {
                        $deferred.resolve(response);
                    }).fail(function (error) {
                        $deferred.resolve(error);
                    });
                }

            }).fail(function (error) {
                $deferred.resolve(error);
            });
            return $deferred.promise();
        };

        DbManager.prototype.removeInQueue = function (tablename, keyArray) {

            var $deferred = new $.Deferred(),
                that = this,
                queueObjArray = [],
                obj = {},
                objVal = {},
                currentUserId = localStorage.getItem('currentUserID');;

            for (var record in keyArray) {

                obj = {};
                objVal = {};

                obj.key = tablename + '-' + record;

                objVal.id = record;
                objVal[CONSTANT.QUEUE_RECORD_FIELDS.RECORD_STATUS] = CONSTANT.QUEUE_RECORD_STATUS.DELETED;
                objVal[CONSTANT.QUEUE_RECORD_FIELDS.TABLE_NAME] = tablename;
                objVal[CONSTANT.QUEUE_RECORD_FIELDS.QUEUE_EMPLOYEE_ID] = currentUserId;
                obj.value = objVal;
                queueObjArray.push(obj)
            }

            console.log("queueObjArray ===== " + JSON.stringify(queueObjArray));

            this._dBObj.insert(CONSTANT.DB_TABLES.QUEUE_TABLE, queueObjArray).done(function (response) {
                $deferred.resolve(response);
            }).fail(function (error) {
                $deferred.resolve(error);
            });
            return $deferred.promise();
        };
        return DbManager;
    });
