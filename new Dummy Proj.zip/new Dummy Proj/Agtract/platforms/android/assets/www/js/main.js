/**
 * Main Controller:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date: 21/01/2014
 * Functionality:
 *      Main Controller is the parent controller which is loaded at the app initialization.
 *      It holds the logic for navigation for the entire the app by using Backbone's Router.
 *      It is also responsible for initializing and holding the global objects and data which is required access the app.
 *      Main Controller is a modularized class defined using Require.js' AMD module structure.
 *      It accepts Backbone library as a dependency to create controllers within the module.
 */

// Strict mode allows you to place the code in the 'strict' operating context.
'use strict';

// Variables used across the app.
var router;
var isSyncInProcess = false;
var isAllowToShowCurrentJob = true;
/** 
 *  Main Controller's module definition.
 *  It has dependency on Backbone.js
 */
define(['Backbone',
        'js/router',
        'js/utilities/DbManager',
        'js/utilities/Utility',
        'js/utilities/Constant',
        'Bootstrap'
    ],

    function (Backbone, Router, DBManager, Utility, CONSTANT, Bootstrap) {

        function MainController() {
            this._DBManagerObject = null;
            this.init();
        }

        MainController.prototype.init = function () {

            var that = this;
            var utilityObject = new Utility();
            if (utilityObject.getLocalStorageStringData(CONSTANT.DB.DB_TABLE_CREATION_CHECK) === null) {
                that._DBManagerObject = new DBManager();
                that._DBManagerObject.open().done(function (status) {
                    that._DBManagerObject.createTables(CONSTANT.AGT_TABLES_LIST).done(function () {
                        //tables created successfully
                        utilityObject.setLocalStorageData(CONSTANT.DB.DB_TABLE_CREATION_CHECK, true);
                        that.launchUserPage();

                    }).fail(function () {
                        //create table call failed
                    })
                }).fail(function () {
                    // DB opening failed
                });
            } else {
                that.launchUserPage();
            }

            
        };

        MainController.prototype.launchUserPage = function () {

            var utilityObject = new Utility();
            router = new Router();
            if (utilityObject.getLocalStorageStringData(CONSTANT.DB.DB_CURRENT_USER) === null) {
                router.navigate('login', {
                    trigger: true
                });
            } else {                
                router.navigate('home', {
                    trigger: true
                });
            }
        };

        return MainController;
    });
