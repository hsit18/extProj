/**
 * Add New Job Model:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:17/02/2015
 * Functionality:
 *
 */

 define(['Backbone',
        'js/utilities/Constant',
        'js/model/baseModel/baseModel',
        'js/utilities/Utility',
        'jquery' 
 	],

 	function(Backbone, CONSTANT, baseModel, Utility, $){

 		'use strict';

 		var addNewJobModel = baseModel.extend({

 			initialize: function() {
                baseModel.prototype.initialize.call(this);                
                this._UtilityObj = new Utility();
            },

            addNewJob: function() {
            	var that = this,
                    $deferred = new $.Deferred(),
                    contractor_id = localStorage.getItem('contractor_id'),
                    addJobsData = {};

                that._DBManagerObject.open().done(function(){
                    $.when(
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.CLIENTS_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.CLIENT_LOCATIONS_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.LOCATIONS_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.TASKS_TABLE),                        
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.TASK_EQUIPMENTS_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.EQUIPMENTS_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.VEHICLES_TABLE)
                    ).done(function(clientsRes, clientLocationsRes, locationsRes, tasksRes, taskEquipmentsRes, equipmentsRes, veihiclesRes ){
                      
                        $.when(
                            that._UtilityObj.formatTableRecords(clientsRes),
                            that._UtilityObj.formatTableRecords(tasksRes),
                            that._UtilityObj.formatTableRecords(equipmentsRes),
                            that._UtilityObj.formatTableRecords(veihiclesRes)
                        ).done(function(clientsResponse, tasksResponse, equipmentsResponse, veihiclesResponse){
                            
                            for(var client_id in clientsResponse) {                                
                                var locationRecords = _.filter(locationsRes, function(obj){
                                    var clientLocObj = _.findWhere(_.pluck(clientLocationsRes, 'value'), {"location_id": obj.value.id, "client_id": client_id});
                                    
                                    return (clientLocObj);
                                });
                                
                                if(locationRecords) {                                    
                                    clientsResponse[client_id]['locations'] = _.pluck(locationRecords, 'value');
                                }                               
                            }
                            
                                                        
                            for(var task_id in tasksResponse) {                                
                                var equipmentRecords = _.filter(equipmentsRes, function(obj){
                                    var taskEquipObj = _.findWhere(_.pluck(taskEquipmentsRes, 'value'), {"equipment_id": obj.value.id, "task_id": task_id});
                                    return (taskEquipObj);
                                });
                                
                                if(equipmentRecords) {                                    
                                    tasksResponse[task_id]['equipments'] = _.pluck(equipmentRecords, 'value');
                                }
                                /*TODO: Temporary fix for the 3 MAR build .*/
                                var vehicles = _.where(veihiclesResponse, {"contractor_id": contractor_id});
                                if(vehicles) {                                    
                                    tasksResponse[task_id]['vehicles'] = vehicles;
                                }                                
                            }
                            
                            addJobsData['clients'] = clientsResponse;
                            addJobsData['tasks'] = tasksResponse;
                            console.log(addJobsData);
                            $deferred.resolve(addJobsData);
                             
                         });
                                    
                        
                    }).fail(function(){
                        console.log("failed to retrieve data from clients table");
                        $deferred.reject();
                    })
                });

                return $deferred.promise();
            },

            saveNewJob: function(jobData){
                var that = this,
                    $deferred = new $.Deferred(),
                    currentUser = localStorage.getItem('currentUserID'),
                    keyForJob = that._UtilityObj.generateUniqueId(),
                    contractorId = localStorage.getItem('contractor_id'),
                    priority = CONSTANT. JOB_PRIORITY_TABLE_MAPPING[jobData.priority],
                    currentUser = localStorage.getItem('currentUserID'),

                    jobsObj = {
                        "id": keyForJob,
                        "client_id": jobData.client_Id,
                        "location_id": jobData.clientLocation_Id,
                        "start_date": jobData.start_date,
                        "priority": priority,                        
                        "contractor_id": contractorId
                    },

                    jobTaskRecord = [];

                    for(var i=0; i<jobData.task.length; i++){

                        var keyForJobTask = that._UtilityObj.generateUniqueId(),                            
 
                        jobTaskObj = {
                            "id": keyForJobTask,
                            "employee_id": currentUser, 
                            "job_id": keyForJob,
                            "job_temp_id": keyForJob,
                            "task_id": jobData.task[i].task_id,
                            "equipment_id": jobData.task[i].equipment_id,
                            "vehicle_id": jobData.task[i].vehicle_id,
                            "rate": jobData.task[i].rate,
                            "qty": "0"                     
                        },

                        obj =  {
                            key: keyForJobTask,
                            value: jobTaskObj
                        };

                        jobTaskRecord.push(obj);
                    }

                    var jobsRecord = {
                        key: keyForJob,
                        value: jobsObj
                    };

                    console.log(jobTaskRecord,"<--jobtask**********job-->", jobsRecord);

                    that._DBManagerObject.open().done(function(){
                        $.when(
                            that._DBManagerObject.insert(CONSTANT.DB_TABLES.JOBS_TABLE, [jobsRecord], true),
                            that._DBManagerObject.insert(CONSTANT.DB_TABLES.JOB_TASK_TABLE, jobTaskRecord, true)
                        ).done(function(jobsRes, jobTaskRes){
                            console.log("data inserted successfully");
                            that.processSyncNowService().done(function () {
                                $deferred.resolve();
                            });
                        }).fail(function(){
                            console.log("data insertion failed");
                            $deferred.reject();
                        });
                    });      

                return $deferred.promise();
            }

 		});

 		return addNewJobModel;
 	});