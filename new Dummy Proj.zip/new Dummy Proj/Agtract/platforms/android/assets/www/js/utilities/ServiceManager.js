/*
 * Service Manager:
 *      version: 1.0
 *      Cross Platform: true
 *      Initialization:
 *          Initializes on object creation.
 *      Date: 2/12/2015
 *      Functionality:
 *          Handles web services related operations
 */

define(["jquery",
    "i18n!js/nls/str",
    "js/utilities/Messenger",
    "js/utilities/Constant"
], function ($, Internationalization, Messenger, CONSTANT) {

    //  Messenger object
    var messengerObject = Messenger.getInstance();

    // Constructor
    function ServiceManager() {

        // Instance variables
        this._url = "";
        this._type = "";
        this._header = "";
        this._response = null;
    }

    // Set request parameters
    ServiceManager.prototype.setRequiredProperties = function (reqDataObj, isDummy) {
        if (isDummy && isDummy === true) {
            this._url = CONSTANT.API.DUMMY_BASE_PATH + reqDataObj.url;
        } else {
            this._url = CONSTANT.API.BASE_PATH + reqDataObj.url;
        }

        this._data = reqDataObj.data;
        this._header = reqDataObj.headers;

        //Override default ajax setup
        if (reqDataObj.type) {
            this._type = reqDataObj.type;
        }
    };

    /*
     * getResponse: hits the URL and fetches the response
     * @return "promise"
     */
    ServiceManager.prototype.getResponse = function () {
        var $deferred = new $.Deferred();

        // Call jQuery ajax method
        var promise = $.ajax({
            headers: this._header,
            url: this._url,
            data: JSON.stringify(this._data),
            type: CONSTANT.POST_REQUEST,
            success: function (obj) {
                $deferred.resolve(obj);
            },
            timeout: CONSTANT.SERVICE_TIMEOUT,
            error: function (jqXHR, exception) {
                var errorMsg = "";

                // Error handling
                switch (jqXHR.status) {
                case 0:
                    errorMsg = Internationalization.NETWORK_ERROR_STATUS_0;
                    break;
                case 404:
                    errorMsg = Internationalization.NETWORK_ERROR_STATUS_404;
                    break;
                case 500:
                    errorMsg = Internationalization.NETWORK_ERROR_STATUS_500;
                    break;
                case "parsererror":
                    errorMsg = Internationalization.NETWORK_ERROR_PARSER_EXCEPTION;
                    break;
                case "timeout":
                    errorMsg = Internationalization.NETWORK_ERROR_TIMEOUT_EXCEPTION;
                    break;
                case "abort":
                    errorMsg = Internationalization.NETWORK_ERROE_ABORT_EXCEPTION;
                    break;
                default:
                    errorMsg = Internationalization.NETWORK_ERROR_UNKNOWN + "\n" + jqXHR.responseText;
                    break;
                }

                // Dispatch network related errors
                messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, errorMsg);
                $deferred.reject(errorMsg);
            }
        });

        return $deferred.promise();
    };

    return ServiceManager;
});
