/**
 * Manage Jobs View:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date: 02/16/2015
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Utility',
        'js/utilities/Messenger',
        'js/model/jobs/manageJobsModel',
        'js/views/jobs/editJobView',
        'js/model/jobs/editJobModel',
        'text!templates/manageJobs.html'
    ],

    function (Backbone, CONSTANT, Utility, Messenger, manageJobsModel, editJobView, editJobModel, manageJobsTemp) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';
        var jobsRelatedData = {},
        data;
        var manageJobsView = Backbone.View.extend({

            el: null,

            initialize: function () {
                 data = null;
                this.utilityObject = new Utility();
                this.utilityObject.showLoader();
                this.manageJobsModel = new manageJobsModel();
                
                //this.render();
                this.getManageJobsData();
                 this.editJobModel = new editJobModel();
            },

            events: {

            },

            addEventListener: function () {
                $('#addJobBtn').unbind('click');
                $('#addJobBtn').bind('click', this.loadAddNewJob);
                $('.jobs-edit-icon').unbind('click');
                $('.jobs-edit-icon').bind('click', this.loadEditJob);
                $('.show_location').unbind('click');
                $('.show_location').bind('click', {'context': this}, this.showLocation);
                $('.assigned-task-icon').unbind('click');
                $('.assigned-task-icon').bind('click', {'context': this}, this.assignJob);   
            },

            render: function (manageJobsData) {
                var that = this;
                 that.editJobModel.fetchVehicleEquipmentData().done(function (response) {
                data = {
                    "jobData": manageJobsData
                };
                }).fail(function () {
                    $deferred.reject();
                });
                this.$el = $('#pagecontainerDiv');
                var template = _.template(manageJobsTemp, manageJobsData);
                this.$el.html(template);
                this.utilityObject.hideLoader();
                this.addEventListener();
                console.log("in render @ manageJobsView--------here ",manageJobsData);
            },

            getManageJobsData: function () {
                var that = this;

                that.manageJobsModel.fetchManageJobsData().done(function (response) {
                    jobsRelatedData = response;
                    console.log("manage jobs data:", response);
                    that.manageJobsModel.proccessTimesheetRecords(response['job_tasks']).done(function (jobsTimesheetRecords) {
                        // console.log("jobsTimesheetRecords data:", jobsTimesheetRecords);
                        if(jobsTimesheetRecords) {
                            jobsRelatedData["timesheetData"] = jobsTimesheetRecords;
                        }                        
                        jobsRelatedData["task_status_css"] = CONSTANT.TASK_STATUS_CSS_CLASS;
                        
                        that.render(response);
                        that.addEventListener();
                    });

                });
            },

            loadAddNewJob: function () {
                router.navigate('addNewJob', {
                    trigger: true
                });
            },

            loadEditJob: function () {
                //var that = this;
                //alert($(this).data('jobtaskid'));
                var editJobViewObj = new editJobView();
                editJobViewObj.render(jobsRelatedData, $(this).data('jobtaskid'));
            },

            assignJob: function(event){
                var that = event.data.context,
                    $deferred = new $.Deferred(),
                    jobTaskId = $(this).data('jobtaskid');

                    console.log("VVVVVVVVVVVVV",jobTaskId);

                that.utilityObject.showLoader();
                that.manageJobsModel.assignJob(jobTaskId).done(function(){  
                    router.navigate('/', {
                        trigger: false
                    });                  
                    router.navigate('manageJobs', {
                        trigger: true
                    });
                    that.utilityObject.hideLoader();
                }).fail(function(){
                    that.utilityObject.hideLoader();
                });
            },

            showLocation: function (event) {
                var that = event.data.context;

                console.log("In ShowLocation");

                var locationId = $(this).data('locationid');                                
                var locations = data.jobData["locations"];

                console.log("In ShowLocation Id",locationId);
                console.log("In ShowLocation",locations);

                if(locations && locations[locationId] && locations[locationId].address) {
                    
                    var address = locations[locationId].address;
                    console.log("location address ---------",address);
                    that.utilityObject.locateAddress(address, 'edit_location_container');
                } 
                else{
                    console.log("In ShowLocation Else");

                }           
            }
         });

        return manageJobsView;

    });
