define({
    "root": {
        INVALID_LOGIN_CREDENTIALS: "Incorrect username or password entered. Please try again.",
        EMPTY_LOGIN_CREDENTIALS: "Please enter username and password.",

        NO_SEARCH_RESULT_FOUND: "No results found.",

        DENIED_GEOLOCATION: "User denied geolocation.",
        UNAVAILABLE_POSITION: "Position unavailable.",

        NETWORK_ERROR_STATUS_0: "Application is experiencing some network issues, please try again.",
        NETWORK_ERROR_STATUS_404: "Requested page not found. [404].",
        NETWORK_ERROR_STATUS_500: "Internal Server Error [500].",
        NETWORK_ERROR_PARSER_EXCEPTION: "Requested JSON parse failed.",
        NETWORK_ERROR_TIMEOUT_EXCEPTION: "Timeout error.",
        NETWORK_ERROE_ABORT_EXCEPTION: "Ajax request aborted.",
        NETWORK_ERROR_UNKNOWN: "Unknown error."
    },
    "en-au": true
});
