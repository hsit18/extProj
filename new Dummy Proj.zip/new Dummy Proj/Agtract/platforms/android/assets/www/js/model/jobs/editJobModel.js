/**
 * Edit Job Model:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:19/02/2015
 * Functionality:
 *
 */
define(['Backbone',
        'js/utilities/Constant',
        'js/model/baseModel/baseModel',
        'js/utilities/Utility',
        'jquery'
    ],

    function (Backbone, CONSTANT, baseModel, Utility, $) {

        'use strict';

        var editJobModel = baseModel.extend({

            initialize: function () {
                baseModel.prototype.initialize.call(this);
                this._UtilityObj = new Utility();
            },

            fetchVehicleEquipmentData: function () {
                var that = this,
                    $deferred = new $.Deferred();

                that._DBManagerObject.open().done(function () {
                    $.when(
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.EQUIPMENTS_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.VEHICLES_TABLE)
                    ).done(function (equipmentRes, vehicleRes) {

                        $.when(
                            that._UtilityObj.formatTableRecords(equipmentRes),
                            that._UtilityObj.formatTableRecords(vehicleRes)
                        ).done(function (equipmentsRecord, vehiclesRecord) {
                            var vehiclesEquipmentData = {
                                "vehicles": vehiclesRecord,
                                "equipments": equipmentsRecord
                            };
                            $deferred.resolve(vehiclesEquipmentData);
                        }).fail(function () {
                            $deferred.reject();
                        });
                    }).fail(function () {
                        $deferred.reject();
                    });
                }).fail(function () {
                    $deferred.reject();
                });
                return $deferred.promise();
            },

            handleEditJobActions: function (jobId, taskId) {
                var that = this,
                    $deferred = new $.Deferred();

                console.log("job id:" + jobId, "task id" + taskId);

                that._DBManagerObject.open().done(function () {
                    that._DBManagerObject.select(CONSTANT.DB_TABLES.TIMESHEETS_TABLE).done(function (timesheetRes) {

                        // find all timesheet data related to current job_task
                        var timesheetData = _.findWhere(_.pluck(timesheetRes, 'value'), {
                            'job_id': jobId.toString(),
                            'task_id': taskId.toString(),
                            'end_time': null
                        });
                        console.log("timesheet data for current job task", timesheetData);

                        if (timesheetData) {
                            console.log("last record for current job task", timesheetData);
                            $deferred.resolve(timesheetData);                            
                        } else {
                            var finishTimesheetData = _.findWhere(_.pluck(timesheetRes, 'value'), {
                                'job_id': jobId.toString(),
                                'task_id': taskId.toString(),
                                'action': CONSTANT.JOB_ACTION.FINISH
                            });
                            if(finishTimesheetData) {
                                $deferred.resolve(finishTimesheetData);
                            } else {
                                $deferred.resolve();
                            }
                            
                        }
                    }).fail(function () {
                        $deferred.reject();
                    });
                }).fail(function () {
                    $deferred.reject();
                });

                return $deferred.promise();
            },

            handleEditJob: function (action, jobId, taskId, startTime, timesheetLastObj) {
                var that = this,
                    $deferred = new $.Deferred(),
                    start_time = that._UtilityObj.convertDate(startTime),
                    currentUser = localStorage.getItem('currentUserID'),
                    end_time,
                    keyForTimesheet = that._UtilityObj.generateUniqueId();

                if (action && action === "Finish") {
                    end_time = that._UtilityObj.convertDate(startTime);
                } else {
                    end_time = null;
                }

                var timesheetRecord = {
                    id: keyForTimesheet,
                    job_id: jobId.toString(),
                    task_id: taskId.toString(),
                    employee_id: currentUser,
                    start_time: start_time,
                    end_time: end_time,
                    action: action
                };

                var timesheetObj = {
                    key: keyForTimesheet,
                    value: timesheetRecord
                };

                that._DBManagerObject.open().done(function () {
                    that._DBManagerObject.insert(CONSTANT.DB_TABLES.TIMESHEETS_TABLE, [timesheetObj], true).done(function (timesheetRes) {
                        
                        if(timesheetLastObj) {
                            
                            var previousObj = timesheetLastObj;
                            previousObj.end_time = timesheetRecord.start_time;
                            
                            var sqlUpdateObj = {
                                key: previousObj.id,
                                value: previousObj
                            };
                            that._DBManagerObject.update(CONSTANT.DB_TABLES.TIMESHEETS_TABLE, sqlUpdateObj, true).done(function () { 
                                console.log("previous record updated successfully in timesheet", sqlUpdateObj);
                                
                                that.processSyncNowService().done(function () {
                                    $deferred.resolve(action);                                    
                                }).fail(function () {
                                    $deferred.reject();
                                });                                                  
                            });
                        
                        } else {
                            console.log("record inserted successfully in timesheet", timesheetObj);
                            that.processSyncNowService().done(function () {
                                $deferred.resolve(action); 
                            }).fail(function () {
                                $deferred.reject();
                            });
                        }
                        
                    }).fail(function () {
                        $deferred.reject();
                    });
                }).fail(function () {
                    $deferred.reject();
                });

                return $deferred.promise();
            },

            processTotalTime: function (jobTaskObj) {
                console.log("incoming jobtaskobj", jobTaskObj);
                var that = this,
                    i = 0,
                    time = 0,
                    $deferred = new $.Deferred(),
                    currentUser = localStorage.getItem('currentUserID'),
                    jobsTimesheetRecords = {};
                
                    if(jobTaskObj) {
                        
                        jobsTimesheetRecords[jobTaskObj.id] = {};
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.TIMESHEETS_TABLE).done(function (response) {

                            if (response && response.length > 0) {

                                var timesheetRecords = _.pluck(response, 'value');
                                var jobTSRecords = _.where(timesheetRecords, {
                                    'job_id': jobTaskObj.job_id.toString(),
                                    'task_id': jobTaskObj.task_id.toString()
                                });
                               
                                var startedRes = _.findWhere(jobTSRecords, {'action': CONSTANT.JOB_ACTION.START});
                                if (startedRes && startedRes.end_time) {
                                    
                                    time = (new Date(startedRes.end_time).getTime()) - (new Date(startedRes.start_time).getTime());
                                    
                                    var resumedRes = _.where(jobTSRecords, {'action': CONSTANT.JOB_ACTION.RESUME});                                         
                                    for (var j in resumedRes) {
                                        time += (new Date(resumedRes[j].end_time).getTime()) - (new Date(resumedRes[j].start_time).getTime());
                                    }
                                    if (time && time > 0) {
                                        jobsTimesheetRecords[jobTaskObj.id]['time_taken'] = that._UtilityObj.calculateTime(time / 1000).slice(0, 5);
                                    }
                                }
                                $deferred.resolve(jobsTimesheetRecords);

                            } else {
                                $deferred.resolve(jobsTimesheetRecords);
                            }
                        });
                    } else {
                        $deferred.resolve();
                    }
                return $deferred.promise();
            },

            checkCurrentTask: function(action){
                var $deferred = new $.Deferred(),
                    that = this,
                    currentUser = localStorage.getItem('currentUserID');

                if(action === CONSTANT.JOB_ACTION.START || action === CONSTANT.JOB_ACTION.RESUME){

                    that._DBManagerObject.open().done(function(){
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.TIMESHEETS_TABLE).done(function(timesheetRes){

                            // timesheet records for current user
                            var timesheetData = _.where(_.pluck(timesheetRes, 'value'), {
                                "employee_id": currentUser
                            });

                            if(timesheetData && timesheetData.length>0){

                                // find records having action "Start" and start_time and end_time = null
                                var lastStartRecord = _.findWhere(timesheetData, {
                                    "action": CONSTANT.JOB_ACTION.START,
                                    "end_time": null
                                });
                                console.log("Start:: start_time and end_time=null", lastStartRecord);

                                // find records having action "Resume" and start_time and end_time = null                        
                                var lastResumeRecord = _.findWhere(timesheetData, {
                                    "action": CONSTANT.JOB_ACTION.RESUME,
                                    "end_time": null
                                });
                                console.log("Resume:: start_time and end_time=null", lastResumeRecord);

                                if(lastStartRecord || lastResumeRecord){
                                    $deferred.resolve(false);
                                    console.log("cannot start new job");
                                } else {
                                    $deferred.resolve(true);
                                    console.log("can start new job");
                                }                            
                            } else {
                                $deferred.resolve(true);
                                console.log("can start new job");
                            }

                        }).fail(function(){
                            $deferred.reject();
                        });
                    });
                } else {
                    $deferred.resolve(true);
                }
                return $deferred.promise();
            },

            updateQtyValue: function(jobTaskId,unitsValue){
                var $deferred = new $.Deferred(),
                    that = this,
                    tempKey = that._UtilityObj.generateUniqueId();

                    console.log("jobTaskId",jobTaskId,"units old", unitsValue);

                that._DBManagerObject.open().done(function(){
                    that._DBManagerObject.select(CONSTANT.DB_TABLES.JOB_TASK_TABLE).done(function(response){

                        var jobTaskRecord = _.findWhere(_.pluck(response, 'value'), {
                            "id": jobTaskId.toString()
                        });

                        console.log("old jobTaskRecord", jobTaskRecord);

                        var cloneObj = $.extend({}, jobTaskRecord);
                        cloneObj["qty"] = unitsValue.toString();

                        var updateObj = {
                            key: jobTaskRecord.id,
                            value : cloneObj
                        };

                        that._DBManagerObject.update(CONSTANT.DB_TABLES.JOB_TASK_TABLE, updateObj, true).done(function(){
                            console.log("record added success", updateObj);
                            that.processSyncNowService().done(function () {
                                $deferred.resolve();
                            });
                        }).fail(function(){
                            $deferred.reject();
                        });
                        //$deferred.resolve();
                    }).fail(function(){
                        $deferred.reject();
                    });
                });

                // $deferred.resolve();

                return $deferred.promise();
            }

        });

        return editJobModel;

    });
