/**
 * Database Communicator Model:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:2/12/2015
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/DbManager',
        'i18n!js/nls/str',
        'js/utilities/Constant'
    ],

    function (Backbone, DbManager, Internationalization, CONSTANT) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';

        var DbCommunicatorModel = Backbone.Model.extend({
            initialize: function () {
                this._DBManagerObject = new DbManager();
            },

            insertDownloadDataResponseToDB: function (downloadResponse) {
                var $deferred = new $.Deferred(),
                    that = this,
                    tableListArr = Object.keys(downloadResponse);

                that.insertDownloadData(0, tableListArr, downloadResponse).done(function () {
                    $deferred.resolve();
                });

                return $deferred.promise();
            },

            insertDownloadData: function (ind, tableLists, downloadRes) {
                var $deferred = new $.Deferred(),
                    that = this,
                    tableName = tableLists[ind],
                    recordsArray = [],
                    mappedTableName = "";

                if (tableName && downloadRes[tableName]) {
                    mappedTableName = CONSTANT.SERVER_TABLE_NAME_MAPPER[tableName];

                    //console.log(mappedTableName +" ---------  "+ JSON.stringify(downloadRes[tableName]));
                    that._DBManagerObject.open().done(function (status) {
                        that.formatDownloadDataToinsert(0, downloadRes[tableName], recordsArray).done(function (updatedRecordArray) {
                            //console.log("updatedRecordArray ------ " + JSON.stringify(updatedRecordArray));
                            if (updatedRecordArray && updatedRecordArray.length > 0) {
                                that._DBManagerObject.insert(mappedTableName, updatedRecordArray).done(function () {

                                    ind++;
                                    if (ind === tableLists.length) {
                                        $deferred.resolve();
                                    } else {
                                        that.insertDownloadData(ind, tableLists, downloadRes).done(function () {
                                            $deferred.resolve();
                                        });
                                    }
                                }).fail(function (error) {
                                    $deferred.resolve();
                                    //console.log("errrrrrrrrr1    "+error);
                                });
                            } else {
                                ind++;
                                if (ind === tableLists.length) {
                                    $deferred.resolve();
                                } else {
                                    that.insertDownloadData(ind, tableLists, downloadRes).done(function () {
                                        $deferred.resolve();
                                    });
                                }
                            }

                        }).fail(function (error) {
                            $deferred.resolve();
                            //console.log("errrrrrrrrr2222    "+error);
                        });

                    }).fail(function (error) {
                        //console.log("errrrrrrrrr4444    "+error);
                    });

                } else {
                    ind++;
                    if (ind === tableLists.length) {
                        $deferred.resolve();
                    } else {
                        that.insertDownloadData(ind, tableLists, downloadRes).done(function () {
                            $deferred.resolve();
                        });
                    }
                }

                return $deferred.promise();
            },

            formatDownloadDataToinsert: function (ind, records, recordsArray) {

                var $deferred = new $.Deferred(),
                    that = this,
                    recordObj = {};

                if (records.length > 0) {

                    //console.log(ind +"==="+ records.length);

                    if (records[ind]) {

                        recordObj = records[ind];
                        recordsArray.push({
                            key: recordObj.id,
                            value: recordObj
                        });
                        ind++;
                        if (ind === records.length) {
                            $deferred.resolve(recordsArray);
                        } else {
                            that.formatDownloadDataToinsert(ind, records, recordsArray).done(function () {
                                $deferred.resolve(recordsArray);
                            });
                        }

                    } else {
                        ind++;
                        if (ind === records.length) {
                            $deferred.resolve(recordsArray);
                        } else {
                            that.formatDownloadDataToinsert(ind, records, recordsArray).done(function () {
                                $deferred.resolve(recordsArray);
                            });
                        }
                    }
                } else {
                    $deferred.resolve(recordsArray);
                }
                return $deferred.promise();
            },

            loadCurrentUserQueueRecords: function (currentUserId) {

                var $deferred = new $.Deferred(),
                    that = this;

                that._DBManagerObject.select(CONSTANT.DB_TABLES.QUEUE_TABLE).done(function (response) {

                    if (response && response.length > 0) {
                        var filteredRecords = _.filter(response, function (obj) {
                            return (obj.value && obj.value[CONSTANT.QUEUE_RECORD_FIELDS.QUEUE_EMPLOYEE_ID] === currentUserId);
                        });
                        var records = _.pluck(filteredRecords, 'value');
                        $deferred.resolve(records);
                    } else {
                        $deferred.resolve(false);
                    }
                });
                return $deferred.promise();
            },

            processDeltaResponseToDB: function (deltaResponse) {

                var $deferred = new $.Deferred(),
                    that = this;
                    if(deltaResponse){
                        var tableListArr = Object.keys(deltaResponse);
                        //console.log(" deltaResponse    -------     "+JSON.stringify(deltaResponse));
                        that.processDeltaResponseTables(0, tableListArr, deltaResponse).done(function () {
                            $deferred.resolve();
                        });
                    } else {
                        $deferred.resolve();
                    }
                return $deferred.promise();
            },

            processDeltaResponseTables: function (ind, tableList, deltaRes) {

                var $deferred = new $.Deferred(),
                    tableName = tableList[ind],
                    that = this,
                    tableRecordsObj = {
                        tableName: '',
                        added: [],
                        updated: [],
                        deleted: []
                    };

                if (tableName && deltaRes[tableName]) {
                    //console.log(tableName + " deltaResponse    -------     "+JSON.stringify(deltaRes[tableName]));
                    that.formatDeltaTableRecords(0, tableName, deltaRes[tableName], tableRecordsObj).done(function (updatedTableRecordsObj) {
                        //console.log("updatedTableRecordsObj ======     "+ JSON.stringify(updatedTableRecordsObj));
                        that.updateDeltaTableRecords(updatedTableRecordsObj).done(function (response) {
                            ind++;
                            if (ind === tableList.length) {
                                $deferred.resolve();
                            } else {
                                that.processDeltaResponseTables(ind, tableList, deltaRes).done(function () {
                                    $deferred.resolve();
                                });
                            }
                        }).fail(function (error) {
                            console.log("error    " + error);
                        });

                    }).fail(function (error) {
                        console.log("error    " + error);
                    });

                } else {
                    ind++;
                    if (ind === tableList.length) {
                        $deferred.resolve();
                    } else {
                        that.processDeltaResponseTables(ind, tableList, deltaRes).done(function () {
                            $deferred.resolve();
                        });
                    }
                }

                return $deferred.promise();
            },

            formatDeltaTableRecords: function (ind, tableName, deltaResTableRecords, tableRecordsObj) {
                var $deferred = new $.Deferred(),
                    that = this,
                    obj = {};

                tableRecordsObj.tableName = CONSTANT.SERVER_TABLE_NAME_MAPPER[tableName];

                if (deltaResTableRecords && deltaResTableRecords.length > 0) {
                    if (deltaResTableRecords[ind]) {

                        that._DBManagerObject.open().done(function () {

                            that._DBManagerObject.select(tableRecordsObj.tableName, deltaResTableRecords[ind].id).done(function (responseObj) {
                                //console.log("responseObj ++++++++++++   " + JSON.stringify(responseObj));                           

                                if (responseObj && responseObj.length > 0) {

                                    switch (deltaResTableRecords[ind].record_status) {

                                    case 'added':
                                        console.log("Record Found in localDB: Unexpected record with status added:    "); //+ JSON.stringify(deltaResTableRecords[ind]));
                                        delete deltaResTableRecords[ind].record_status;
                                        obj.key = deltaResTableRecords[ind].id;
                                        obj.value = deltaResTableRecords[ind];
                                        tableRecordsObj.updated.push(obj);
                                        break;

                                    case 'updated':
                                        delete deltaResTableRecords[ind].record_status;
                                        obj.key = deltaResTableRecords[ind].id;
                                        obj.value = deltaResTableRecords[ind];
                                        tableRecordsObj.updated.push(obj);
                                        break;

                                    case 'deleted':
                                        delete deltaResTableRecords[ind].record_status;
                                        obj.key = deltaResTableRecords[ind].id;
                                        tableRecordsObj.deleted.push(obj);
                                        break;

                                    default:
                                        console.log("Record Found in localDB: Unknown Existing Obj record status:  " + JSON.stringify(deltaResTableRecords[ind]));
                                        break;
                                    }

                                    ind++;
                                    if (ind === deltaResTableRecords.length) {
                                        $deferred.resolve(tableRecordsObj);
                                    } else {
                                        that.formatDeltaTableRecords(ind, tableName, deltaResTableRecords, tableRecordsObj).done(function (updatedTableRecordsObj) {
                                            $deferred.resolve(updatedTableRecordsObj);
                                        });
                                    }
                                } else {
                                    // Record not exist
                                    // added: same case added
                                    // updated && deleted: console the faulty obj 

                                    switch (deltaResTableRecords[ind].record_status) {

                                    case 'added':
                                        delete deltaResTableRecords[ind].record_status;
                                        obj.key = deltaResTableRecords[ind].id;
                                        obj.value = deltaResTableRecords[ind];
                                        tableRecordsObj.added.push(obj);
                                        break;

                                    default:
                                        console.log("Record not Found in localDB: Unexpected record with status: "); //+ deltaResTableRecords[ind].record_status +" :    " + JSON.stringify(deltaResTableRecords[ind]));
                                        break;
                                    }
                                    ind++;
                                    if (ind === deltaResTableRecords.length) {
                                        $deferred.resolve(tableRecordsObj);
                                    } else {
                                        that.formatDeltaTableRecords(ind, tableName, deltaResTableRecords, tableRecordsObj).done(function (updatedTableRecordsObj) {
                                            $deferred.resolve(updatedTableRecordsObj);
                                        });
                                    }
                                }

                            });
                        });
                    } else {
                        ind++;
                        if (ind === deltaResTableRecords.length) {
                            $deferred.resolve(tableRecordsObj);
                        } else {
                            that.formatDeltaTableRecords(ind, tableName, deltaResTableRecords, tableRecordsObj).done(function (updatedTableRecordsObj) {
                                $deferred.resolve(updatedTableRecordsObj);
                            });
                        }
                    }

                } else {
                    $deferred.resolve(tableRecordsObj);
                }
                return $deferred.promise();
            },

            updateDeltaTableRecords: function (updatedTableRecordsObj) {

                var $deferred = new $.Deferred(),
                    that = this,
                    tableName = updatedTableRecordsObj.tableName;

                if (updatedTableRecordsObj.added && updatedTableRecordsObj.added.length > 0) {

                    that._DBManagerObject.open().done(function (status) {
                        that._DBManagerObject.insert(tableName, updatedTableRecordsObj.added).done(function () {

                            delete updatedTableRecordsObj.added;
                            that.updateDeltaTableRecords(updatedTableRecordsObj).done(function () {
                                $deferred.resolve();
                            });
                        });
                    });
                } else if (updatedTableRecordsObj.updated && updatedTableRecordsObj.updated.length > 0) {

                    that.updateRecordsToDB(0, tableName, updatedTableRecordsObj.updated).done(function () {
                        delete updatedTableRecordsObj.updated;
                        that.updateDeltaTableRecords(updatedTableRecordsObj).done(function () {
                            $deferred.resolve();
                        });
                    });
                } else if (updatedTableRecordsObj.deleted && updatedTableRecordsObj.deleted.length > 0) {

                    that.deleteRecordsToDB(0, tableName, updatedTableRecordsObj.deleted).done(function () {
                        delete updatedTableRecordsObj.deleted;
                        that.updateDeltaTableRecords(updatedTableRecordsObj).done(function () {
                            $deferred.resolve();
                        });
                    });

                } else {
                    $deferred.resolve();
                }

                return $deferred.promise();
            },

            updateRecordsToDB: function (ind, tableName, recordsArray) {

                var $deferred = new $.Deferred(),
                    that = this;

                if (recordsArray && recordsArray[ind]) {
                    that._DBManagerObject.open().done(function (status) {
                        that._DBManagerObject.update(tableName, recordsArray[ind]).done(function () {
                            ind++;
                            if (ind === recordsArray.length) {
                                $deferred.resolve();
                            } else {
                                that.updateRecordsToDB(ind, tableName, recordsArray).done(function () {
                                    $deferred.resolve();
                                });
                            }
                        });
                    });
                } else {
                    ind++;
                    if (ind === recordsArray.length) {
                        $deferred.resolve();
                    } else {
                        that.updateRecordsToDB(ind, tableName, recordsArray).done(function () {
                            $deferred.resolve();
                        });
                    }
                }

                return $deferred.promise();
            },

            deleteRecordsToDB: function (ind, tableName, recordsArray) {

                var $deferred = new $.Deferred(),
                    that = this;

                if (recordsArray && recordsArray[ind] && recordsArray[ind].key) {
                    that._DBManagerObject.open().done(function (status) {
                        that._DBManagerObject.remove(tableName, recordsArray[ind].key).done(function () {
                            ind++;
                            if (ind === recordsArray.length) {
                                $deferred.resolve();
                            } else {
                                that.deleteRecordsToDB(ind, tableName, recordsArray).done(function () {
                                    $deferred.resolve();
                                });
                            }
                        });
                    });
                } else {
                    ind++;
                    if (ind === recordsArray.length) {
                        $deferred.resolve();
                    } else {
                        that.deleteRecordsToDB(ind, tableName, recordsArray).done(function () {
                            $deferred.resolve();
                        });
                    }
                }

                return $deferred.promise();
            },

            removeTemporaryRecords: function (recordsObject) {
                var $deferred = new $.Deferred();
                console.log("removeAddedRecords:DbCommunicatorModel");
                console.log(recordsObject);

                if (recordsObject) {
                    var tableList = Object.keys(recordsObject);
                    if (recordsObject && tableList.length > 0) {
                        this.deleteSyncServTableRecords(0, tableList, recordsObject).done(function () {
                            $deferred.resolve();
                        });
                    } else {
                        $deferred.resolve();
                    }
                } else {                    
                    $deferred.resolve();
                }
                

                return $deferred.promise();
            },

            deleteSyncServTableRecords: function (ind, tableListArr, syncResponse) {

                var $deferred = new $.Deferred(),
                    that = this, isAllowToMoveNextTable = true;
                console.log(ind, "   >>>>>>>>>>>>>>    ", tableListArr.length);
                if (tableListArr && tableListArr[ind] && syncResponse[tableListArr[ind]] && syncResponse[tableListArr[ind]].length > 0) {

                    var mappedTableName = CONSTANT.SERVER_TABLE_NAME_MAPPER[tableListArr[ind]];
                    console.log(mappedTableName, "     >>>>>>>>>>>>>>>>>>>>>>>>>>>>     ", syncResponse[tableListArr[ind]]);
                    var successRecords = _.where(syncResponse[tableListArr[ind]], {
                        "success": "true"
                    });
                    var createdRecordStatusArray = _.where(successRecords, {'record_status': 'added'});
                    var otherRecordStatusArray = _.where(successRecords, {'record_status': 'updated'});
                    var otherRecordStatusArrayTemp = _.where(successRecords, {'record_status': 'deleted'});
                    if(otherRecordStatusArray) {
                        otherRecordStatusArray = otherRecordStatusArray.concat(otherRecordStatusArrayTemp);
                    } else {
                        otherRecordStatusArray = otherRecordStatusArrayTemp;
                    }
                    var queueRecordKeys = [];

                    if (successRecords && successRecords.length > 0) {
                        console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>     ", syncResponse[tableListArr[ind]]);
                        
                        if (createdRecordStatusArray && createdRecordStatusArray.length > 0) {                            
                                                       
                            var createdRecordsArray = _.pluck(createdRecordStatusArray, 'temp_id');
                            console.log(mappedTableName, "     >>>>>>>>  createdRecordsArray  >>>>>>>>>>     ", createdRecordsArray);
                            var queueRecordIds = createdRecordsArray;
                            
                            if (otherRecordStatusArray && otherRecordStatusArray.length > 0) {
                                var otherRecordsArray = _.pluck(otherRecordStatusArray, 'id');
                                console.log(mappedTableName, "     >>>>>>>>  otherRecordsArray  >>>>>>>>>>     ", otherRecordsArray);
                                queueRecordIds = createdRecordsArray.concat(otherRecordsArray);
                            }                            
                            
                            for (var i = 0; i < queueRecordIds.length; i++) {                                
                                queueRecordKeys.push(mappedTableName + '-' + queueRecordIds[i]);                                
                                if(i === (queueRecordIds.length-1)) {
                                    console.log("queueRecordKeys -  >>>>>>>>>>      ", queueRecordKeys);
                                    that._DBManagerObject.open().done(function (status) {
                                        that._DBManagerObject.removeMultiple(mappedTableName, createdRecordsArray).done(function () {
                                            that._DBManagerObject.removeMultiple(CONSTANT.DB_TABLES.QUEUE_TABLE, queueRecordKeys).done(function () {    
                                                ind++;
                                                if (ind === tableListArr.length) {
                                                    $deferred.resolve();
                                                } else {
                                                    that.deleteSyncServTableRecords(ind, tableListArr, syncResponse).done(function () {
                                                        $deferred.resolve();
                                                    });
                                                }
                                            });
                                        });
                                    })
                                }
                            }
                            
                            
                        } else if (otherRecordStatusArray && otherRecordStatusArray.length > 0) {
                            isAllowToMoveNextTable = false;
                            queueRecordKeys = [];
                            var otherRecordsArray = _.pluck(otherRecordStatusArray, 'id');
                            
                            for (var i = 0; i < otherRecordsArray.length; i++) {
                                queueRecordKeys.push(mappedTableName + '-' + otherRecordsArray[i]);
                            }

                            that._DBManagerObject.open().done(function (status) {
                                that._DBManagerObject.removeMultiple(CONSTANT.DB_TABLES.QUEUE_TABLE, queueRecordKeys).done(function () {
                                    ind++;
                                    if (ind === tableListArr.length) {
                                        $deferred.resolve();
                                    } else {
                                        that.deleteSyncServTableRecords(ind, tableListArr, syncResponse).done(function () {
                                            $deferred.resolve();
                                        });
                                    }
                                });
                            })
                        }
                    } else {
                        ind++;
                        if (ind === tableListArr.length) {
                            $deferred.resolve();
                        } else {
                            that.deleteSyncServTableRecords(ind, tableListArr, syncResponse).done(function () {
                                $deferred.resolve();
                            });
                        }
                    }

                } else {
                    ind++;
                    if (ind === tableListArr.length) {
                        $deferred.resolve();
                    } else {
                        that.deleteSyncServTableRecords(ind, tableListArr, syncResponse).done(function () {
                            $deferred.resolve();
                        });
                    }
                }

                return $deferred.promise();
            }
        });
        return DbCommunicatorModel;
    });
