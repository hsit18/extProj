/**
 * Dashboard View:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:
 * Functionality:
 *
 */

define(['Backbone'], function (Backbone) {

    // Strict mode allows you to place the code in the 'strict' operating context.
    'use strict';

    /**
     * The Backbone Router.
     * It translates the url requests into actions.
     */
    var Router = Backbone.Router.extend({
        history: [],
        execute: function (callback, args) {
            this.beforenavigationhandler(this.history[this.history.length - 1], Backbone.history.fragment);
            this.history.push(Backbone.history.fragment);
        },

        beforenavigationhandler: function (lastfragment, currentFragment) {
            console.log('currentFragment : ' + currentFragment);
            console.log('lastfragment : ' + lastfragment);
        },

        initialize: function () {
            Backbone.history.start();
            console.log("Router initialize");
        },
        // Routes configuration.
        routes: {
            'home': 'loadHomePage',
            'dashboard': 'loadDashboard',
            'login': 'loadLoginPage',
            'forgetPassword': 'loadForgetPassword',
            'manageJobs': 'loadManageJobs',
            'conversations': 'loadConversations',
            'messages': 'loadMessages',
            'map': 'loadMap',
            'settings': 'loadSettings',
            'addNewJob': 'loadAddNewJob'
        },

        loadHomePage: function () {
            console.log("from loadHomePage");
            require(['js/views/home/homeView'], function (homeView) {
                var dashObj = new homeView();
            });
        },
        
        loadDashboard: function () {
            console.log("from Dashboard");
            require(['js/views/dashboard/dashboardView'], function (DashboardView) {
                var dashObj = new DashboardView();
            });
        },

        loadLoginPage: function () {
            $('#draggable-cj').hide();
            require(['js/views/login/loginView'], function (LoginView) {
                var loginObj = new LoginView();
            });
        },

        loadForgetPassword: function () {
            console.log("from ForgetPassword");
            require(['js/views/login/forgetPasswordView'], function (forgetPasswordView) {
                var forgetPasswordObj = new forgetPasswordView();
            });
        },

        loadManageJobs: function () {
            console.log("from ManageJobs");
            require(['js/views/jobs/manageJobsView'], function (manageJobsView) {
                var manageJobsObj = new manageJobsView();
            });
        },

        loadConversations: function () {
            console.log("from Conversations");
            require(['js/views/dashboard/dashboardView'], function (DashboardView) {
                var dashObj = new DashboardView();
            });
        },

        loadMessages: function () {
            console.log("from Messages");
            require(['js/views/dashboard/dashboardView'], function (DashboardView) {
                var dashObj = new DashboardView();
            });
        },

        loadMap: function () {
            console.log("from Map");
            require(['js/views/jobs/mapLocationsView'], function (mapView) {
                var mapObj = new mapView();
            });
        },

        loadSettings: function () {
            console.log("from Settings");
            require(['js/views/settings/settingsView'], function (SettingsView) {
                var settingsObj = new SettingsView();
            });
        },

        loadAddNewJob: function () {
            console.log("from add new Job");
            require(['js/views/jobs/addNewJobView'], function (addNewJobView) {
                var dashObj = new addNewJobView();
            });
        }

    });

    return Router;
});
