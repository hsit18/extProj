/**
 * Dashboard Model:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/Constant',
        'js/model/baseModel/baseModel',
        'js/utilities/Utility',
        'jquery'
    ],
    function (Backbone, CONSTANT, baseModel, Utility, $) {

        'use strict';

        var dashboardModel = baseModel.extend({

            initialize: function () {
                baseModel.prototype.initialize.call(this);
                this._UtilityObj = new Utility();
                //   this.processDeltaServices();
            },

            fetchUserDashboardData: function () {
                var that = this,
                    $deferred = new $.Deferred();

                $.when(
                    that.getJobsData(),
                    that.calculateTotalHrs(),
                    that.getVehiclesData(),
                    that.getEquipmentData(),
                    that.checkTimeStamp()
                ).done(function (jobRes, hrsRes, vehicleResponse, equipmentResponse, startTimeStatus) {
                    var obj = {
                        'jobData': jobRes,
                        'timesheetData': hrsRes,
                        "equipments": equipmentResponse,
                        "vehicles": vehicleResponse,
                        "startTimeStatus": startTimeStatus
                    };
                    console.log("obj------------------->>>>>", obj);
                    $deferred.resolve(obj);
                });
                return $deferred.promise();
            },

            addTimeStamp: function (timeStamp) {
                //console.log("received timestamp: ", timeStamp);

                var currentUser = localStorage.getItem('currentUserID');
                //console.log('currentUserID: ', currentUser);

                var that = this,
                    $deferred = new $.Deferred;

                that._DBManagerObject.open().done(function () {
                    that._DBManagerObject.select(CONSTANT.DB_TABLES.EMPLOYEES_TABLE).done(function (responseObj) {
                        //console.log(" Success responseObj:    " + JSON.stringify(responseObj));

                        var recordWithKey = _.findWhere(responseObj, {
                            key: currentUser
                        });
                        console.log("before:", recordWithKey);
                        console.log("check in UTC:     " + that._UtilityObj.convertDate(that._UtilityObj.getUTCDate(timeStamp)));
                        recordWithKey.value["start_time"] = that._UtilityObj.convertDate(that._UtilityObj.getUTCDate(timeStamp));

                        var record = recordWithKey.value;

                        console.log("after:", record);

                        that._DBManagerObject.update(CONSTANT.DB_TABLES.EMPLOYEES_TABLE, {
                            key: currentUser,
                            value: record
                        }, true).done(function () {
                            //console.log("start time added");
                            that.processSyncNowService().done(function () {
                                $deferred.resolve();
                            });
                            //$deferred.resolve();
                        }).fail(function () {
                            $deferred.reject();
                        });
                    });
                });

                return $deferred.promise();
            },

            addTimeStampOut: function (timeStampOut) {
                //console.log("received timestamp", timeStampOut);

                var currentUser = localStorage.getItem('currentUserID');
                //console.log('currentUserID: ', currentUser);

                var that = this,
                    $deferred = new $.Deferred;

                that._DBManagerObject.open().done(function () {
                    that._DBManagerObject.select(CONSTANT.DB_TABLES.EMPLOYEES_TABLE).done(function (responseObj) {
                        var recordWithKey = _.findWhere(responseObj, {
                                key: currentUser
                            }),
                            start_time = that._UtilityObj.convertDate(recordWithKey.value["start_time"]),
                            end_time = that._UtilityObj.convertDate(that._UtilityObj.getUTCDate(timeStampOut)),
                            date = new Date(),
                            day = ("0" + date.getDate()).slice(-2),
                            mnth = ("0" + (date.getMonth() + 1)).slice(-2),
                            year = date.getFullYear(),
                            formattedDate = year + "-" + mnth + "-" + day;

                        var attendanceData = that._UtilityObj.getTimeDifferenceRecords(new Date(start_time).getTime(), new Date(end_time).getTime()),
                            timesheetRecordArray = [];

                        for (var i = 0; i < attendanceData.length; i++) {

                            var keyForTimesheet = that._UtilityObj.generateUniqueId(),

                                timesheetData = {
                                    id: keyForTimesheet,
                                    employee_id: currentUser,
                                    date: attendanceData[i].date,
                                    checkin: attendanceData[i].startTime,
                                    checkout: attendanceData[i].endTime
                                },

                                obj = {
                                    key: keyForTimesheet,
                                    value: timesheetData
                                };

                            timesheetRecordArray.push(obj);
                        }

                        console.log("attendance records to be inserted", timesheetRecordArray);

                        recordWithKey.value["start_time"] = null;

                        var userUpdatedObj = {
                            key: currentUser,
                            value: recordWithKey.value
                        };

                        $.when(
                            that._DBManagerObject.insert(CONSTANT.DB_TABLES.ATTENDANCE_TABLE, timesheetRecordArray, true),
                            that._DBManagerObject.update(CONSTANT.DB_TABLES.EMPLOYEES_TABLE, userUpdatedObj)
                        ).done(function (res1, res2) {
                            that.processSyncNowService().done(function () {
                                $deferred.resolve();
                            });
                        });

                    }).fail(function () {
                        $deferred.reject();
                        //console.log("timesheet table added successfully");                        
                    });
                });

                return $deferred.promise();
            },

            checkTimeStamp: function () {
                //console.log("In checkTimeStamp method");

                //check if user is already clocked in or not
                var that = this,
                    $deferred = new $.Deferred,
                    currentUser = localStorage.getItem('currentUserID');

                that._DBManagerObject.open().done(function () {
                    that._DBManagerObject.select(CONSTANT.DB_TABLES.EMPLOYEES_TABLE).done(function (responseObj) {
                        var record = _.findWhere(responseObj, {
                            key: currentUser
                        });
                        console.log("responseObj: ", record);
                        if (record && record.value["start_time"]) {
                            $deferred.resolve(true);
                        } else {
                            $deferred.resolve(false);
                        }
                    }).fail(function () {
                        console.log("failed to select");
                        $deferred.reject();
                    });
                }).fail(function () {
                    console.log("failed to open DB");
                });

                return $deferred.promise();
            },

            calculateTotalHrs: function () {
                var that = this,
                    $deferred = new $.Deferred();
                var currentUser = localStorage.getItem('currentUserID');

                that._DBManagerObject.open().done(function () {
                    that._DBManagerObject.select(CONSTANT.DB_TABLES.ATTENDANCE_TABLE).done(function (responseObj) {
                        //console.log("received response from attendence:", responseObj);

                        var records = _.filter(responseObj, function (obj) {
                            return (obj.value && obj.value.employee_id === currentUser);
                        });
                        //console.log("timesheet records for current employee:", records);
                        var todaySeconds = 0,
                            weekSeconds = 0,
                            monthSeconds = 0,
                            date = new Date(that._UtilityObj.getUTCDate(new Date().getTime())),
                            today = date.getDate(),
                            week = that._UtilityObj.getWeek(date),
                            month = date.getMonth();

                        console.log("Currnet date -----   ", date);
                        for (var i = 0; i < records.length; i++) {
                            var checkIn = new Date(records[i].value["checkin"]).getTime(),
                                checkOut = new Date(records[i].value["checkout"]).getTime(),
                                cIn = new Date(checkIn).getDate(),
                                cOut = new Date(checkOut).getDate();

                            // calculate total time for the day
                            if (cIn === today && cOut === today) {
                                var totalSec = checkOut - checkIn;
                                todaySeconds = todaySeconds + (totalSec / 1000);
                            }

                            // calculate total time for the Week
                            if (that._UtilityObj.getWeek(checkIn) === week && that._UtilityObj.getWeek(checkOut) === week) {
                                var totalSec = checkOut - checkIn;
                                weekSeconds = weekSeconds + (totalSec / 1000);
                            }

                            // calculate total time for the Month
                            if (new Date(checkIn).getMonth() === month && new Date(checkOut).getMonth() === month) {
                                var totalSec = checkOut - checkIn;
                                monthSeconds = monthSeconds + (totalSec / 1000);
                            }

                        }
                        var totalToday = Math.floor(todaySeconds / (60 * 60));
                        console.log("Total seconds employee worked today:", todaySeconds);

                        var totalWeek = Math.floor(weekSeconds / (60 * 60));
                        console.log("Total seconds employee worked this week:", weekSeconds);

                        var totalMonth = Math.floor(monthSeconds / (60 * 60));
                        console.log("Total seconds employee worked this month:", monthSeconds);

                        var totalHrsData = {
                            hoursToday: (totalToday < 10 ? "0" + totalToday : totalToday),
                            hoursWeek: (totalWeek < 10 ? "0" + totalWeek : totalWeek),
                            hoursMonth: (totalMonth < 10 ? "0" + totalMonth : totalMonth)
                        };
                        $deferred.resolve(totalHrsData);
                    });
                });
                return $deferred.promise();
            },

            sendLocalTimestamp: function () {

            },

            getJobsData: function () {
                var that = this,
                    $deferred = new $.Deferred(),
                    currentUser = localStorage.getItem('currentUserID');

                that._DBManagerObject.open().done(function () {
                    $.when(
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.JOB_TASK_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.JOBS_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.TIMESHEETS_TABLE)
                    ).done(function (jobTaskRes, jobRes, timesheetRes) {
                        var jobRecords = _.pluck(jobRes, 'value'),
                            jobTaskRecords = _.pluck(jobTaskRes, 'value'),
                            timesheetRecords = _.pluck(timesheetRes, 'value');

                        var date = new Date(),
                            today = date.getDate(),
                            month = date.getMonth(),
                            totalToday = 0,
                            totalCompletedToday = 0,
                            totalMonth = 0;
                        
                        //console.log(currentUser,"received response from JOB_TASK_TABLE:", jobTaskRecords);
                        //console.log("received response from JOBS_TABLE:", jobRecords);

                        var jobTaskRec = _.where(jobTaskRecords, {                                
                            'employee_id': currentUser
                        });
                        
                        var records = _.filter(jobRecords, function (obj) {
                            var c = _.findWhere(jobTaskRecords, {
                                'job_id': obj.id,
                                'employee_id': currentUser
                            });
                            return (c);
                        });
                        
                        var todayJobRecords = _.filter(records, function (obj) {
                            if(obj.start_date) {
                                var startDateObj = new Date(obj.start_date);
                                if (startDateObj && startDateObj.getDate() === today) {
                                    return (obj);
                                }  
                            }                            
                        });
                        
                        var monthJobRecords = _.filter(records, function (obj) {
                            if(obj.start_date) {
                                var startDateObj = new Date(obj.start_date);
                                if (startDateObj && startDateObj.getMonth() === month) {
                                    return (obj);
                                }  
                            }                            
                        });
                        //console.log( todayJobRecords.length, " -------------------------------- ", monthJobRecords.length);
                                                
                        //console.log("JOBS assigned to current employee:", records); 

                        var timesheetsData = _.where(timesheetRecords, {
                                'action': CONSTANT.JOB_ACTION.FINISH,
                                'employee_id': currentUser
                            });

                        //console.log("***********************", timesheetsData);
                        
                        for(var i=0; i<todayJobRecords.length;i++) {
                            var jobId = todayJobRecords[i].id,
                                taskRecs = _.where(jobTaskRec, {'job_id': jobId});
                            
                            // calculate jobs completed today
                            if(taskRecs && taskRecs.length > 0) {   //Timesheet calc
                                                               
                                var finishTask = _.filter(timesheetsData, function(obj){                                    
                                    var taskRecordObj = _.findWhere(taskRecs, {'job_id':obj.job_id, 'task_id':obj.task_id});
                                     return (taskRecordObj);
                                });
                                
                                if(finishTask && finishTask.length> 0 && finishTask.length === taskRecs.length) {
                                    totalCompletedToday++;
                                }
                            }                           

                        }

                        var totalJobsData = {
                            jobToday: (todayJobRecords.length < 10 ? "0" + todayJobRecords.length : todayJobRecords.length),
                            jobCompleted: (totalCompletedToday < 10 ? "0" + totalCompletedToday : totalCompletedToday),
                            jobMonth: (monthJobRecords.length < 10 ? "0" + monthJobRecords.length : monthJobRecords.length)
                        };

                        //console.log("job details for current employee", totalJobsData);

                        $deferred.resolve(totalJobsData);

                    }).fail(function () {
                        console.log("failed to select job and job task table");
                    });
                });

                return $deferred.promise();

            },

            // then get vehicles and equipments for current user using ids for vehicles and equipment from job_task table

            getVehiclesData: function () {
                var that = this,
                    contractorid = localStorage.getItem('contractor_id'), //add fetch details here
                    $deferred = new $.Deferred(),
                    currentUser = localStorage.getItem('currentUserID');

                that._DBManagerObject.open().done(function () {
                    $.when(
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.JOB_TASK_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.VEHICLES_TABLE)
                    ).done(function (jobTaskRes, vehicleRes) {
                        console.log("JobTaskRes------------------------->>", jobTaskRes);
                        console.log("vehicleRes------------------------->>", vehicleRes);
                        var jobTaskData = _.pluck(jobTaskRes, 'value'),
                            vehiclesData = _.pluck(vehicleRes, 'value');
                        console.log("jobTaskData------------------------->>", jobTaskData);
                        console.log("vehiclesData------------------------->>", vehiclesData);
                        var vehiclesRecord = _.filter(vehiclesData, function (obj) {
                            var jobtask = _.findWhere(jobTaskData, {
                                'employee_id': currentUser,
                                'vehicle_id': obj.id
                            });
                            return (jobtask);
                            console.log("vehiclesRecord------------------------->>", vehiclesRecord);
                        });
                        console.log("vehicles for current employee", vehiclesRecord);
                        $deferred.resolve(vehiclesRecord);

                    }).fail(function () {
                        $deferred.reject();
                    });
                }).fail(function () {
                    $deferred.reject();
                });

                return $deferred.promise();
            },

            getEquipmentData: function () {
                var that = this,
                    contractorid = localStorage.getItem('contractor_id'), //add fetch details here
                    $deferred = new $.Deferred(),
                    currentUser = localStorage.getItem('currentUserID');

                that._DBManagerObject.open().done(function () {
                    $.when(
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.JOB_TASK_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.EQUIPMENTS_TABLE)
                    ).done(function (jobTaskRes, equipmentRes) {
                        var jobTaskData = _.pluck(jobTaskRes, 'value'),
                            equipmentData = _.pluck(equipmentRes, 'value');

                        var equipmentsRecord = _.filter(equipmentData, function (obj) {
                            var jobtask = _.findWhere(jobTaskData, {
                                'employee_id': currentUser,
                                'equipment_id': obj.id
                            });
                            return (jobtask);
                        });

                        console.log("equipments for current employee", equipmentsRecord);
                        $deferred.resolve(equipmentsRecord);

                    }).fail(function () {
                        $deferred.reject();
                    });
                }).fail(function () {
                    $deferred.reject();
                });
                return $deferred.promise();
            },

            getEmployeeData: function () {
                var that = this,
                    $deferred = new $.Deferred(),
                    currentUser = localStorage.getItem('currentUserID');

                that._DBManagerObject.open().done(function () {
                    that._DBManagerObject.select(CONSTANT.DB_TABLES.EMPLOYEES_TABLE).done(function (response) {
                        //console.log("employees table: ", response);

                        var currenrEmployeeData = _.findWhere(response, {
                            "key": currentUser
                        });
                        if (currenrEmployeeData) {
                            var initials = (currenrEmployeeData.value.name).slice(0, 1);
                            var employeeData = {
                                name: currenrEmployeeData.value.name,
                                avatar: currenrEmployeeData.value.avatar, //"images/user.png",
                                contractor_id: currenrEmployeeData.value.contractor_id,
                                initials: initials.toUpperCase()
                            };

                            $deferred.resolve(employeeData);
                        } else {
                            $deferred.reject();
                        }                       

                    }).fail(function () {
                        console.log("unable to select employee table");
                        $deferred.reject();
                    });
                });

                return $deferred.promise();
            },

            processLogoutRequest: function () {

                var that = this,
                    $deferred = new $.Deferred();
                var currentUserID = that._UtilityObj.getLocalStorageStringData(CONSTANT.DB.DB_CURRENT_USER);
                that._DBManagerObject.select(CONSTANT.DB_TABLES.USER_TABLE, currentUserID).done(function (responseObj) {
                    responseObj[0].value.currentTimestamp = that._UtilityObj.getLocalStorageStringData(CONSTANT.DB.DB_CURRENT_TIMESTAMP);
                    that._DBManagerObject.update(CONSTANT.DB_TABLES.USER_TABLE, {
                        key: responseObj[0].key,
                        value: responseObj[0].value
                    }).done(function () {
                        that._UtilityObj.removeLocalStorageData(CONSTANT.DB.DB_CURRENT_USER);
                        that._UtilityObj.removeLocalStorageData(CONSTANT.DB.DB_CURRENT_CONTRACTOR);
                        $deferred.resolve();

                    }).fail(function (error) {
                        console.log("processLogoutRequest:update record failed");
                        console.log(error);
                        $deferred.reject();

                    });
                }).fail(function () {
                    //select query on user table failed
                    console.log("processLogoutRequest:select record failed");
                    $deferred.reject();
                });

                return $deferred.promise();
            }

        });

        return dashboardModel;
    });