define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Messenger',
        'js/utilities/Utility',        
        'js/model/settings/settingsModel',
        'text!templates/settings.html'
    ],

   
    function (Backbone, CONSTANT, Messenger, Utility, SettingsModel, settingsTempl) {

    	var messengerObject,responseObjtemp,clickFlag=true,utilityObject;
		var SettingsView= Backbone.View.extend({	    	
	    	el: $('#dashboardContainer'),

	    	initialize:function(){
	    		//this.render();
	    		messengerObject = Messenger.getInstance();
	    		this.settingsModelObject=new SettingsModel();
	    		this.utilityObject = new Utility();
	    		this.getCurrentUserData();
	    	},
	    	addEventListener:function(){
	            $("#updatePassword").bind("click",{'context':this},this.onUpdatePasswordClicked);
	          //  $(".profile-user-edit").bind("click",{'context':this},this.onProfilePictureClicked);
	            $("#editPhone").bind("click",{'context':this},this.onEditPhoneClicked);
	            $("#saveUserData").bind("click",{'context':this},this.onEditInfoClicked);
	            $("#saveUserData1").bind("click",{'context':this},this.onEditInfoClicked);
	        },

	        // Render the view.
	        render: function (responseObj) {
	            var template = _.template(settingsTempl, responseObj);
	            responseObjtemp =responseObj;
	            this.$el.find('.page-container').html(template);//.html(template);
	            this.addEventListener();
	        },

	        getCurrentUserData:function(){
	        	var that=this;
	        	this.settingsModelObject.getCurrentUserData().done(function(responseObj){
	        		console.log("settingsView:getCurrentUserData:success");
	        		//console.log(responseObj[0].value);
	        		that.render(responseObj[0].value);
	        	}).fail(function(){
	        		console.log("settingsView:getCurrentUserData:fail");

	        	});
	        },

	        onUpdatePasswordClicked:function(event){
	        	var that=event.data.context;
	        	var currUserPassword =that.$("#CurrPassword").val();
	        	var newPassword=that.$("#NewPassword").val();
	        	var confirmPassword=that.$("#ConfrnewPassword").val();
	        	that.utilityObject.checkConnection().done(function(isOnline){
                    if(isOnline){
	                	that.settingsModelObject.validateUpdatePasswordFields(currUserPassword,newPassword,confirmPassword).done(function(){
		        		//send it to model to upld the changes to local db and server
				        		console.log("Passwords are validated"); 
				        		messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.PASSWORD_UPDATED_SUCCESSFULLY);       		
			        	}).fail(function(){
				        		// messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.PASSWORD_UPDATION_FAILED);
				        	});
			        }else{
			        	messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.NO_CONNECTIVITY_ERROR); 
			        }

		        }).fail(function(){
                    console.log("no internet");
                });
		    		
	        
	        },
	        
	        onProfilePictureClicked:function(event){
	        	console.log("In here");
	        	var that=event.data.context;
	        	//open gallery select new picture
	        	//if returned false then do not hit db
	        	//if returned with object append to img tag
	        	//update to db
	        	that.settingsModelObject.getNewProfilePicture().done(function(picLocalDeviceURL){
	        		console.log("onProfilePictureClicked:success:base64data");
	        		console.log(picLocalDeviceURL);
	        		that.$("#profilePicture")[0].src=picLocalDeviceURL;
	        		that.settingsModelObject.updateNewProfilePicture(picLocalDeviceURL).done(function(){
	        			console.log("onProfilePictureClicked:succesfully update pro pic local DB");
	        		}).fail(function(){
	        			console.log("onProfilePictureClicked:un-succesful in update pro pic local DB");
	        		});
	        		//assign this base64 to img source and send it to db updation both local and server
	        		
	        	}).fail(function(){
	        		console.log("onProfilePictureClicked:failed:");
	        		/*that.$("#profilePicture")[0].src=value;
	        		that.settingsModelObject.updateNewProfilePicture(value).done(function(){
	        			console.log("onProfilePictureClicked:succesfully update pro pic local DB");
	        		}).fail(function(){
	        			console.log("onProfilePictureClicked:un-succesful in update pro pic local DB");
	        		});*/

	        	});
	        },

	        onEditPhoneClicked:function(event){
	        	var that=event.data.context;
	        	console.log("prop:"+that.$("#phoneNumber").prop('disabled'));
	        	if(that.$("#phoneNumber").prop('disabled')){
	        		//disbaled is true,shift to edit mode
	        		that.$("#phoneNumber").prop('disabled',false);
	        	} else {
	        		//disable is false,read the number ip validate it
	        		//if its a new entry then send it to update to local server
	        		var phoneNumber=$('#phoneNumber').val();

	        		that.settingsModelObject.validatePhoneNumber(phoneNumber).done(function(){
	        			console.log("phone number validation success");
	        			//that.$("#phoneNumber").prop('disabled',true);
	        			that.settingsModelObject.updatePhoneNumber(phoneNumber).done(function(){
	        				console.log("phone number updated to db succesfully");
	        			}).fail(function(){
	        				console.log("phone number update to local db failed");
	        			});
	        		}).fail(function(){
	        			console.log("phone number validation failed!!!");
	        		})
	        	}
	        	
	        },

	    	onEditInfoClicked:function(event){
	    		console.log("click Flag value in Function-----",clickFlag);
	    		var empNamestr,empPhonestr,empNamestr1,empPhonestr1;
	        	var that=event.data.context;
	        	//console.log("prop:"+that.$("#phoneNumber").prop('disabled'));
	        	if(that.$("#saveUserData").hasClass("profile-edit-icon-big")){
	        		console.log("Disabled");
                    empNamestr = "<input class=profile-input type=text id=employeeName value="+responseObjtemp.name+"></input>";
                    empPhonestr = "<input class=profile-input type=text id=employeeContactNumber value="+responseObjtemp.mobile+"></input>";

	        		 $('#tempempname').html(empNamestr);
	        		 $('#tempempcnt').html(empPhonestr);

	        		 console.log("click Flag value in IF-----",clickFlag);
	        		 that.$("#saveUserData").removeClass("profile-edit-icon-big").addClass("profile-update-icon");
	        		 that.$("#profilePicture").addClass("profile-user-edit");
	        		 that.$(".profile-user-edit").bind("click",{'context':that},that.onProfilePictureClicked);

	        		clickFlag=false;
	        	} else {
	        		
					 var empNameVal = that.$("#employeeName").val();
                     var empMobileNoVal =  that.$("#employeeContactNumber").val();
					 
					console.log("Enabled");
					that.settingsModelObject.validateNamePhoneNumber(empNameVal,empMobileNoVal).done(function(){
	        			empNamestr1 = '<p>'+empNameVal+'</p>'
	        		 	empPhonestr1 = '<p>'+empMobileNoVal+'</p>'

		        		$('#tempempname').html(empNamestr1);
		        		$('#tempempcnt').html(empPhonestr1);

	        			that.settingsModelObject.updateEmployeeNamePhoneNumber(empNameVal,empMobileNoVal).done(function(tempObj){
	        				 that.$("#saveUserData").removeClass("profile-update-icon").addClass("profile-edit-icon-big");
	        				 that.$("#profilePicture").removeClass("profile-user-edit");
	        				// that.render(tempObj);
	        				 messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.EPLOYEE_DATA_UPDATED_SUCCESSFULLY);
	        			}).fail(function(){
	        				console.log("Employee name and Phone Number update to local db failed");
	        			});
	        		}).fail(function(){
	        			console.log("Phone number validation failed!!!");
	        		})
					clickFlag=true;
	        	}        	
	        }

	    });
        return SettingsView;
    });
