/**
 * Manage Jobs View:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date: 02/16/2015
 * Functionality:
 *
 */
define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Utility',
        'js/utilities/Messenger'
    ],

    function (Backbone, CONSTANT, Utility, Messenger) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';
        var geocoder, map, directionsDisplay;
        var currPosition = {};
        var mapLocationsView = Backbone.View.extend({

            el: null,

            initialize: function () {
                var geolocate;
                var directionsService = new google.maps.DirectionsService();
                this.utilityObject = new Utility();
                this.utilityObject.showLoader();
                this.render();

            },

            render: function () {

                this.$el = $('#pagecontainerDiv');
                var that = this;
                $.get('templates/maps.html', function (mapTemp) {
                    var template = _.template(mapTemp);
                    that.$el.html(template);
                    var directionsDisplay;
                    var directionsService = new google.maps.DirectionsService();
                    var map;

                    var geocoder = new google.maps.Geocoder();
                    directionsDisplay = new google.maps.DirectionsRenderer();
                    var mapOptions = {
                        zoom: 15
                    };
                    map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
                    navigator.geolocation.getCurrentPosition(function (position) {

                        var geolocate = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                        currPosition = geolocate;
                        var infowindow = new google.maps.InfoWindow({
                            map: map,
                            position: geolocate

                        });

                        map.setCenter(geolocate);

                    });

                    directionsDisplay.setMap(map);
                    that.codeAddress(geocoder, map, directionsService, directionsDisplay);
                    that.utilityObject.hideLoader();
                });

            },

            calcRoute: function (q, directionsService, directionsDisplay) {

                var add = ["Kalyani Nagar Pune Maharashtra", "Vishrantwadi Pune Maharashtra", "Pimpri Pune Maharashtra", "Lonavala Pune Maharashtra"];
                var start = currPosition;
                var end = add[q];
                var request = {
                    origin: currPosition,
                    destination: end,
                    travelMode: google.maps.TravelMode.DRIVING
                };
                directionsService.route(request, function (response, status) {
                    if (status == google.maps.DirectionsStatus.OK) {
                        directionsDisplay.setDirections(response);
                    }
                });
            },

            codeAddress: function (geocoder, map, directionsService, directionsDisplay) {

                var i, q = 0,
                    r = 0,
                    that = this;
                var add = ["Kalyani Nagar Pune Maharashtra", "Vishrantwadi Pune Maharashtra", "Pimpri Pune Maharashtra", "Lonavala Pune Maharashtra"];
                for (i = 0; i < add.length; i++) {
                    var addresstemp = add[r];
                    r++;
                    geocoder.geocode({
                        'address': addresstemp
                    }, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            map.setCenter(results[0].geometry.location);
                            var marker = new google.maps.Marker({
                              position: results[0].geometry.location,
                              map: map,
                              icon: 'images/map-pin-icon.png' 
                            });
                            var contentStr="<div class=rows style=background:#fff;box-shadow: -2px 0px 10px 0px rgba(0, 0, 0, 0.66);>"+
                            "<div class=client-listing-row>"+
                                "<div class=row popup-seperator>"+
                                    "<div class=col-md-8><span class=job-id-popup>#25</span></div>"+
                                    "<div class=col-md-4 align-right remove-padding-right>"+  
                                        "<span class=navigator-icon></span>"+                  
                                        "<span class=jobs-edit-icon data-jobtaskid=21></span>"+
                                    "</div>"+
                                "</div>"+        
                                "<div class=row>"+
                                    "<div class=col-md-12>"+
                                        "<p class=client-icon-heading>Larry G. Sanders</p>"+
                                    "</div>"+
                                "</div>"+
                                "<div class=row>"+
                                    "<div class=col-md-8>"+
                                        "<p class=map-icon-heading-popup>3983 Geraldine Lane Auckland, NZ 10016</p>"+
                                        "<p class=task-icon-heading>Lorem Ipsum</p>"+
                                    "</div>"+
                                    "<div class=col-md-4 text-center>"+
                                        "<p><span class=client-unit>Time Taken</span></p>"+                                        
                                            "<p><span class=client-unit-count>05:40</span></p>"+
                                    "</div>"+
                                "</div>"+
                            "</div>"+
                        "</div>";
                            var infowindow = new google.maps.InfoWindow({ 
                                content: contentStr
                            });
                            q++;
                        } else {
                            alert("Geocode was not successful for the following reason: " + status);
                        }
                        google.maps.event.addListener(marker, 'click', function() {
                            infowindow.open(map,marker);
                         });
                        $('.calcRoute').unbind('click');
                        $('.calcRoute').bind('click', function () {
                            that.calcRoute($(this).data('index'), directionsService, directionsDisplay);

                        });
                    });

                }

            }

        });

        return mapLocationsView;

    });
