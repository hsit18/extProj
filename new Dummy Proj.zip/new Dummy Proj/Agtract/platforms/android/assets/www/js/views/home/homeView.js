/**
 * Dashboard View:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Messenger',
        'js/utilities/Utility',
        'js/model/home/homeModel',
        'js/utilities/ErrorHandler',
        'js/views/draggableView/draggableView',
        'text!templates/home.html'
    ],
    //$('div').drags();
    function (Backbone, CONSTANT, Messenger, Utility, homeModel, ErrorHandler, DraggableView, homeTempl) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';

        var messengerObject, utilityObject;

        var homeView = Backbone.View.extend({

            el: $('#dashboardContainer'),

            initialize: function () {
                this.utilityObject = new Utility();
                this.utilityObject.showLoader();
                this.homeModel = new homeModel(); 
                var errorObj = new ErrorHandler();
                this.render();
            },
            
            events: {

            },

            addEventListener: function () {                
                $('#main-menu li').unbind('click');
                $('#main-menu li').bind('click', {'context': this}, this.sidebarNavigation);
                $('#logout').unbind('click');
                $('#logout').bind('click', {'context': this}, this.logoutFromCurrentSession);                
            },

            // Render the view.
            render: function (employeeDashboardData) {
                
                var that  = this;
                that.utilityObject.showLoader();
                that.homeModel.getEmployeeData().done(function (responseObj) {

                    var employeeData = responseObj;
                    console.log("employeeData    ", employeeData)
                    var template = _.template(homeTempl, employeeData);
                    
                    that.$el.html(template);
                    that.utilityObject.hideLoader();
                    that.addEventListener();
                    that.initDraggable();                    
                    router.navigate('dashboard', {
                        trigger: true
                    });
                    that.utilityObject.hideLoader();
                    
                }).fail(function () {
                    console.log("failed to bring the data from the temp folder");
                });
            },

            initDraggable: function () {
                this.draggableViewObject = new DraggableView();
            },
       
            sidebarNavigation: function(event){
                
                var currentMenu = $(this).data('sidebarmenu'),
                    that = event.data.context;  
                
                that.utilityObject.showLoader();
                $('#main-menu li').removeClass('active-menu');
                $(this).addClass('active-menu');
                router.navigate('/', {
                        trigger: false
                    });
                
                switch(currentMenu) {
                   
                    case 'manageJobs':
                        $('#page-heading').text(CONSTANT.PAGE_HEADING[currentMenu]);
                        router.navigate('manageJobs', {
                            trigger: true
                        });
                        that.utilityObject.hideLoader();
                        break;
                        
                    case 'settings':
                        $('#page-heading').text(CONSTANT.PAGE_HEADING[currentMenu]);
                        router.navigate('settings', {
                            trigger: true
                        });
                        that.utilityObject.hideLoader();
                        break;
                         
                    default:
                        $('#page-heading').text(CONSTANT.PAGE_HEADING.dashboard);
                        router.navigate('dashboard', {
                            trigger: true
                        });
                        that.utilityObject.hideLoader();
                        break;
                }
            },
            
            logoutFromCurrentSession: function (event) {
                //localStorage.setItem("currentUserID","null");                
                var that = event.data.context;
                if (navigator.notification) {
                    navigator.notification.confirm(CONSTANT.ALERT_MESSAGES.CONFIRM_LOGOUT, function (buttonIndex) {
                        if (buttonIndex === 2) {
                            that.processLogoutCurrentUser();
                        } else {

                        }
                    }, 'Agtract', 'No,Yes');
                } else {
                    that.processLogoutCurrentUser();
                }

            },

            processLogoutCurrentUser: function () {
                //localStorage.setItem("currentUserID","null");                
                var that = this;
                utilityObject = new Utility();
                utilityObject.showLoader();
                if (utilityObject.getLocalStorageStringData(CONSTANT.DB.DB_CURRENT_TIMESTAMP)) {
                    that.homeModel.processLogoutRequest().done(function () {
                        console.log("processLogoutCurrentUser:processLogoutRequest:Success");
                        router.navigate('login', {
                            trigger: true
                        });
                        utilityObject.hideLoader();
                    }).fail(function () {
                        console.log("processLogoutCurrentUser:processLogoutRequest:Failed");
                    });
                } else {
                    router.navigate('login', {
                        trigger: true
                    });
                    utilityObject.hideLoader();
                }
            },
            
        });
        return homeView;
    });
