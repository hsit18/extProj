/**
 * Edit Job View:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date: 02/19/2015
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Utility',
        'js/utilities/Messenger',
        'js/model/jobs/editJobModel',
        'js/views/draggableView/draggableView',
        'text!templates/editJob.html'
    ],

    function (Backbone, CONSTANT, Utility, Messenger, editJobModel, DraggableView, editJobTemp) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';

        var messengerObject, data, timesheetLastObj, currentJobTaskId;

        var editJobView = Backbone.View.extend({

            el: null,

            initialize: function () {
                data = null;
                timesheetLastObj = null;
                this.utilityObject = new Utility();
                messengerObject = Messenger.getInstance();
                this.utilityObject.showLoader();
                this.editJobModel = new editJobModel();
                //this.render();                
            },

            events: {

            },

            addEventListener: function () {
                $('#backToJobs').unbind('click');
                $('#backToJobs').bind('click', this.getManageJobsData);

                $('#job-actions li').unbind('click');
                $('#job-actions li').bind('click', {'context': this}, this.confirmBeforeAction);

                $('#minus, #plus').unbind('click');
                $('#minus, #plus').bind('click', {'context': this}, this.handleUnits);                

                $('#units').unbind('click');
                $('#units').bind('click', {'context': this}, this.showNumberPopup);

                $('ul.dial-number li, #saveUnits, #cancelUnits').unbind('click');
                $('ul.dial-number li, #saveUnits, #cancelUnits').bind('click', {'context': this}, this.handleDialPad);

                $('.locTest').unbind('click');
                $('.locTest').bind('click', {'context': this}, this.locationPopUp);

                $('#addJobBtn').unbind('click');
                $('#addJobBtn').bind('click', this.loadAddNewJob);
            },

            render: function (manageJobsData, jobTaskId) {

                var $deferred = new $.Deferred(),
                    that = this;


                that.$el = $('#pagecontainerDiv');
                that.formatJobsRecords(manageJobsData).done(function(jobsData){
                    that.editJobModel.fetchVehicleEquipmentData().done(function (response) {
                        data = {
                            "jobTaskId": jobTaskId,
                            "jobData": jobsData,
                            "vehiclesEquipmentData": response
                        };
                        currentJobTaskId = jobTaskId;
                        console.log("data for edit job", data);
                        var template = _.template(editJobTemp, data);
                        that.$el.html(template);
                        that.addEventListener();
                        var jobId = manageJobsData["job_tasks"][jobTaskId].job_id,
                            taskId = manageJobsData["job_tasks"][jobTaskId].task_id;
                        console.log(jobId, taskId);                                

                        that.handleEditJobActions(jobId, taskId).done(function(){
                            that.utilityObject.hideLoader();
                        });                       
                        
                    }).fail(function () {
                        $deferred.reject();
                    });
                
                });
                console.log("in render @ editJobView ");

                return $deferred.promise();
            },

            getManageJobsData: function () {
                router.navigate("/", {
                    trigger: false
                });
                router.navigate("manageJobs", {
                    trigger: true
                });
            },

            initDraggable: function () {
                this.draggableViewObject = new DraggableView();
            },

            handleEditJobActions: function (jobId, taskId) {
                var that = this,
                    $deferred = new $.Deferred();

                that.editJobModel.handleEditJobActions(jobId, taskId).done(function (timesheetData) {

                    $('#job-actions li').addClass('disabled');
                    $("#resumeJob").hide();                    
                    
                    if(timesheetData && timesheetData.action) {
                        timesheetLastObj = timesheetData;
                        
                        switch(timesheetData.action) {
                            
                            case CONSTANT.JOB_ACTION.ENROUTE:
                                $("#startJob").removeClass("disabled"); 
                                $deferred.resolve();
                                break;

                            case CONSTANT.JOB_ACTION.PAUSE:
                                $("#resumeJob").show();
                                $("#pauseJob").hide();
                                $("#resumeJob").removeClass("disabled");
                                $deferred.resolve();
                                break;

                            case CONSTANT.JOB_ACTION.RESUME:
                            case CONSTANT.JOB_ACTION.START:
                                $("#pauseJob").show();
                                $("#resumeJob").hide();
                                $("#pauseJob, #completed").removeClass("disabled"); 
                                $deferred.resolve();
                                break;
                            
                            case CONSTANT.JOB_ACTION.FINISH:
                                $("#resumeJob").hide();
                                $("#pauseJob").show();
                                $deferred.resolve();
                                break;
                                
                            default:
                                $("#onRoute").removeClass("disabled");
                                $deferred.resolve();
                                break;
                        }                        
                    } else {
                        $("#onRoute").removeClass("disabled");
                        $deferred.resolve();
                    }                  
                    
                }).fail(function () {
                    $deferred.reject();
                });

                return $deferred.promise();
            },

            confirmBeforeAction: function(event) {
                var that = event.data.context,
                    thisObj = this,                    
                    action = $(this).data("status");


                if(action === CONSTANT.JOB_ACTION.FINISH) {
                    if (navigator.notification) {
                        navigator.notification.confirm(CONSTANT.ALERT_MESSAGES.CONFIRM_COMPLETE_TASK, function (buttonIndex) {
                            if (buttonIndex === 2) {
                                that.handleEditJob(event, thisObj);
                            }
                        }, 'Agtract', 'No,Yes');
                    } else {
                        that.handleEditJob(event, thisObj);
                    }
                } else {
                    that.handleEditJob(event, thisObj);
                }
            },

            handleEditJob: function (event, thisObj) {
                
                var that = event.data.context,                    
                    action = $(thisObj).data("status"),
                    jobId = $(thisObj).data("jobid"),
                    taskId = $(thisObj).data("taskid"),
                    date = new Date().getTime(),
                    startTime = that.utilityObject.getUTCDate(date);
                
                that.utilityObject.showLoader();
                that.editJobModel.checkCurrentTask(action).done(function(response){
                    if(response){                
                    that.editJobModel.handleEditJobActions(jobId, taskId).done(function (timesheetLastObj) {
                        that.editJobModel.handleEditJob(action, jobId, taskId, startTime, timesheetLastObj).done(function(action) {
                            var jobTaskObj = data.jobData["job_tasks"][currentJobTaskId]; 
                            that.calculateTotalTime(jobTaskObj).done(function(){
                                $('#job-actions li').addClass('disabled');
                                $("#resumeJob").hide();
                                that.initDraggable();
                                switch(action) {

                                    case CONSTANT.JOB_ACTION.ENROUTE:
                                        $("#startJob").removeClass("disabled");                            
                                        break;

                                    case CONSTANT.JOB_ACTION.PAUSE:
                                        $("#resumeJob").show();
                                        $("#pauseJob").hide();
                                        $("#resumeJob").removeClass("disabled");          
                                        break;

                                    case CONSTANT.JOB_ACTION.FINISH:
                                        $("#resumeJob").hide();
                                        $("#pauseJob").show();
                                        break;

                                    case CONSTANT.JOB_ACTION.RESUME:
                                    case CONSTANT.JOB_ACTION.START:
                                        $("#pauseJob").show();
                                        $("#resumeJob").hide();
                                        $("#pauseJob, #completed").removeClass("disabled");                           
                                        break;

                                    default:
                                        break;
                                }
                                that.utilityObject.hideLoader();
                            });
                           
                            
                        }).fail(function () {
                            that.utilityObject.hideLoader();
                        }); 
                    }); 
                    } else {
                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.ANOTHER_TASK_IN_PROGRESS);
                        that.utilityObject.hideLoader();
                    }              
                });
                
                
            },

            handleUnits: function(event){
                var that = event.data.context,
                    operation = $(this).data("operation"),
                    dialpadUnits = $("#enterUnits").text();

                if(operation === "minus" && dialpadUnits>0){
                    --dialpadUnits;                    
                    $("#enterUnits").text(parseInt(dialpadUnits));
                } else if(operation === "plus"){              
                    ++dialpadUnits;
                    $("#enterUnits").text(parseInt(dialpadUnits));
                }                
            },

            locationPopUp: function(event){
                
                var that = event.data.context
                var locationId = $(this).data('locationid');                                
                var locations = data.jobData["locations"];
                //alert($(this).data('locationid'));

                if(locations && locations[locationId] && locations[locationId].address) {
                    
                    var address = locations[locationId].address;
                    console.log("locationId ---------",address);
                    
                    //$('#LocationModal').modal('show');
                    that.utilityObject.locateAddress(address, 'edit_location_container');
                }                                                   
            },

            handleDialPad: function(event){                
                var that = event.data.context,
                    units = $("#units").text(),
                    dialpadUnits = $("#enterUnits").text(); 
                
                if($(this).data('save') === 'save') {
                    if(dialpadUnits !== ""){
                        that.utilityObject.showLoader();
                        that.editJobModel.updateQtyValue(currentJobTaskId, dialpadUnits).done(function(){
                            $("#units").text(dialpadUnits);
                            $('#dialpadModal').modal('hide');
                            $("#popup-overlay").hide();
                            that.utilityObject.hideLoader();                            
                    }).fail(function(){
                        that.utilityObject.hideLoader();
                    });
                    } else {
                        alert("units value cannot be empty");
                    }
                } else if($(this).data('save') === 'cancel') {                    
                    $('#dialpadModal').modal('hide');
                    $("#enterUnits").text(units);
                } else if($(this).data('save') === 'delete'){
                    $("#enterUnits").text(dialpadUnits.slice(0,-1));
                } else {
                    if(dialpadUnits !== ""){
                        if(parseInt(dialpadUnits) === 0){
                            $("#enterUnits").text($(this).data('number'));
                        } else {
                            var val = parseInt(dialpadUnits).toString();
                            $("#enterUnits").text(val + $(this).data('number'));
                        }                        
                    } else {
                        $("#enterUnits").text(dialpadUnits + $(this).data('number'));
                    }
                }
            },

            showNumberPopup: function(event) {
                var that = event.data.context;
                $("#popup-overlay").show();  
                $('#dialpadModal').on('hide.bs.modal', function(){
                  $("#popup-overlay").hide();
                });  
            },

            loadAddNewJob: function () {
                router.navigate('addNewJob', {
                    trigger: true
                });
            },

            calculateTotalTime: function(jobTaskObj) {
                var that = this,
                    $deferred = new $.Deferred();

                that.editJobModel.processTotalTime(jobTaskObj).done(function(totalTime){
                    console.log("total time", totalTime);
                    if(totalTime && totalTime[jobTaskObj.id] && totalTime[jobTaskObj.id].time_taken) {
                        $('#edit_job_time').text(totalTime[jobTaskObj.id].time_taken);
                        $deferred.resolve();
                    } else {
                        $deferred.resolve();
                    }                    
                    
                }).fail(function(){
                    $deferred.reject();
                });

                return $deferred.promise();
            },
            
            formatJobsRecords: function(manageJobsData) {
                 var that = this,
                    $deferred = new $.Deferred();
                if(manageJobsData && manageJobsData.jobs) {
                    _.each(manageJobsData.jobs, function(jobsObj) {
                        var startDate = jobsObj.start_date;
                        var priority = jobsObj.priority;
                        if(priority) {
                            manageJobsData.jobs[jobsObj.id]['priority'] = CONSTANT.JOB_PRIORITY_SERVER_MAPPING[priority];
                        }

                        if(startDate) {
                            var dateObj = new Date(startDate);
                            if(dateObj) {
                                manageJobsData.jobs[jobsObj.id]['formatted_date'] = dateObj.format('M, d Y');
                            }
                        }
                    });
                }                
                $deferred.resolve(manageJobsData);
                return $deferred.promise();
            }

        });

        return editJobView;

    });
