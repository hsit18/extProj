/**
 * Offline Queue Model:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:2/12/2015
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/DbManager',
        'i18n!js/nls/str',
        'js/utilities/Constant'
    ],

    function (Backbone, DbManager, Internationalization, CONSTANT) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';

        var OfflineQueueModel = Backbone.Model.extend({

            initialize: function () {
                this.syncServiceObject = null;
            },

            formatSyncRecords: function (response) {

                var that = this,
                    $deferred = new $.Deferred();

                console.log("syncServiceObjectBuilder ------ ");
                console.log("Before Formation syncServiceObj : " + JSON.stringify(response));

                that.syncServiceObjectBuilder(response).done(function (syncServiceObj) {
                    if (syncServiceObj) {
                        that.removeUnwantedKeyFromRecords(0, Object.keys(syncServiceObj), syncServiceObj).done(function (formattedResponse) {
                            console.log("Server Formatted Records : " + JSON.stringify(formattedResponse));
                            $deferred.resolve(syncServiceObj, formattedResponse);
                        });
                    } else {
                        $deferred.resolve();
                    }
                });

                return $deferred.promise();
            },

            syncServiceObjectBuilder: function (response) {

                var that = this,
                    record,
                    $deferred = new $.Deferred();

                that.loadAllLevelTables().done(function (syncServiceObj) {
                    if (response && response.length > 0) {
                        for (var tableName in syncServiceObj) {
                            var serviceMapperTableName = CONSTANT.SERVER_TABLE_NAME_MAPPER[tableName];
                            // console.log("serviceMapperTableName  ----   "+serviceMapperTableName);
                            var recordObj = _.map(response, function (obj) {
                                if (serviceMapperTableName === obj.tableName) {
                                    syncServiceObj[tableName][obj.id] = obj;
                                    return true;
                                } else {
                                    return false;
                                }
                            });

                            syncServiceObj[tableName] = _.toArray(syncServiceObj[tableName]);
                            if (syncServiceObj[tableName].length == 0) {
                                delete syncServiceObj[tableName];
                            }
                            this.syncServiceObject = syncServiceObj;
                        }
                        console.log('After Formation DATA syncServiceObj : ------ ' + JSON.stringify(syncServiceObj));
                        $deferred.resolve(syncServiceObj);
                    } else {
                        $deferred.resolve();
                    }
                }).fail(function (error) {
                    console.log("syncServiceObj ------ error   " + JSON.stringify(error));
                    $deferred.resolve();
                });
                return $deferred.promise();
            },

            loadAllLevelTables: function () {

                var $deferred = new $.Deferred(),
                    level = CONSTANT.QUEUE_TABLES_LEVEL,
                    lvlLength = Object.keys(level).length,
                    cnt = 0,
                    syncServiceObject = {};

                for (var index in level) {
                    var levelObj = level[index];
                    for (var i = 0; i < levelObj.length; i++) {

                        syncServiceObject[levelObj[i]] = {};
                        if (i === (levelObj.length - 1)) {
                            cnt++;
                            if (lvlLength === cnt) {
                                $deferred.resolve(syncServiceObject);
                            }
                        }
                    }
                }
                return $deferred.promise();
            },

            removeUnwantedKeyFromRecords: function (ind, tableListArr, syncServiceObj) {

                var that = this,
                    $deferred = new $.Deferred();

                if (tableListArr && tableListArr[ind]) {
                    that.processTableRecords(0, syncServiceObj[tableListArr[ind]]).done(function (tableUpdatedRecords) {

                        syncServiceObj[tableListArr[ind]] = tableUpdatedRecords;

                        ind++;
                        if (ind === tableListArr.length) {
                            $deferred.resolve(syncServiceObj);
                        } else {
                            that.removeUnwantedKeyFromRecords(ind, tableListArr, syncServiceObj).done(function (UpdatedSyncServiceObj) {
                                $deferred.resolve(UpdatedSyncServiceObj);
                            });
                        }
                    });
                } else {
                    ind++;
                    if (ind === tableListArr.length) {
                        $deferred.resolve(syncServiceObj);
                    } else {
                        that.removeUnwantedKeyFromRecords(ind, tableListArr, syncServiceObj).done(function (UpdatedSyncServiceObj) {
                            $deferred.resolve(UpdatedSyncServiceObj);
                        });
                    }
                }
                return $deferred.promise();
            },

            processTableRecords: function (ind, tableRecords) {

                var that = this,
                    $deferred = new $.Deferred();

                if (tableRecords && tableRecords[ind]) {
                    that.modifyRecordForServer(tableRecords[ind]).done(function (updatedRecord) {
                        delete updatedRecord[CONSTANT.QUEUE_RECORD_FIELDS.QUEUE_EMPLOYEE_ID];
                        delete updatedRecord[CONSTANT.QUEUE_RECORD_FIELDS.TABLE_NAME];
                        tableRecords[ind] = updatedRecord;
                    });
                    ind++;
                    if (ind === tableRecords.length) {
                        $deferred.resolve(tableRecords);
                    } else {
                        that.processTableRecords(ind, tableRecords).done(function (tableUpdatedRecords) {
                            $deferred.resolve(tableUpdatedRecords);
                        });
                    }
                } else {
                    ind++;
                    if (ind === tableRecords.length) {
                        $deferred.resolve(tableRecords);
                    } else {
                        that.processTableRecords(ind, tableRecords).done(function (tableUpdatedRecords) {
                            $deferred.resolve(tableUpdatedRecords);
                        });
                    }

                }
                return $deferred.promise();
            },

            modifyRecordForServer: function (recordObj) {

                var that = this,
                    $deferred = new $.Deferred();

                if (recordObj) {

                    if (recordObj[CONSTANT.QUEUE_RECORD_FIELDS.RECORD_STATUS] && recordObj[CONSTANT.QUEUE_RECORD_FIELDS.RECORD_STATUS] === CONSTANT.QUEUE_RECORD_STATUS.CREATED) {
                        recordObj.temp_id = recordObj.id;
                        delete recordObj.id;
                    }

                    switch (recordObj.tableName) {

                    case CONSTANT.DB_TABLES.ATTENDANCE_TABLE:
                        $deferred.resolve(recordObj);
                        break;
                            
                    case CONSTANT.DB_TABLES.JOB_TASK_TABLE:
                        if (recordObj[CONSTANT.QUEUE_RECORD_FIELDS.RECORD_STATUS] && recordObj[CONSTANT.QUEUE_RECORD_FIELDS.RECORD_STATUS] === CONSTANT.QUEUE_RECORD_STATUS.CREATED) {
                            delete recordObj.job_id;
                        }                       
                        $deferred.resolve(recordObj);
                        break;

                    default:
                        $deferred.resolve(recordObj);
                        break
                    }
                } else {
                    $deferred.resolve(recordObj);
                }
                return $deferred.promise();
            }

        });

        return OfflineQueueModel;
    });
