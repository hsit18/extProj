/*
 * Utilities:
 *      version: 1.0
 *      Cross Platform: true
 *      Initialization:
 *          Initializes on object creation.
 *      Date: 2/12/2015
 *      Functionality:
 *          A module that contains all the utilities functions
 */

define(["jquery",
        "i18n!js/nls/str",
        "js/utilities/Constant"
    ],
    function ($, Internationalization, CONSTANT) {

        // Applying strict mode for variable declarations.
        "use strict";
        // Constructor
        function Utility() {
            this._scopeObj = {
                context: this
            };
            this.dateFormattor();
        }

        Utility.prototype.createFormDataMap = function (formData) {
            var returnObj = {};
            for (var obj in formData) {
                returnObj[formData[obj].name] = formData[obj].value;
            }
            return returnObj;
        };

        Utility.prototype.showLoader = function () {
            $("#page-overlay").show();
        };

        Utility.prototype.hideLoader = function () {
            $("#page-overlay").hide();
        };

        Utility.prototype.convertDate = function (str) {
            var date = new Date(str),
                mnth = ("0" + (date.getMonth() + 1)).slice(-2),
                day = ("0" + date.getDate()).slice(-2),
                hh = date.getHours(),
                mm = date.getMinutes(),
                ss = date.getSeconds();

            var result = date.getFullYear() + "-" + mnth + "-" + day + " " + (hh < 10 ? "0" + hh : hh) + ":" + (mm < 10 ? "0" + mm : mm) + ":" + (ss < 10 ? "0" + ss : ss);

            return result;
        };

        // Function Name: checkConnection.
        // Description: Checks the connection state.
        //              Returns true if app is online.
        Utility.prototype.checkConnection = function () {
            var $deferred = new $.Deferred();
            console.log("Util.checkConnection");

            if (navigator.connection) {
                var networkState = navigator.connection.type;
                var states = {};
                states[Connection.UNKNOWN] = 'Unknown connection';
                states[Connection.ETHERNET] = 'Ethernet connection';
                states[Connection.WIFI] = 'WiFi connection';
                states[Connection.CELL_2G] = 'Cell 2G connection';
                states[Connection.CELL_3G] = 'Cell 3G connection';
                states[Connection.CELL_4G] = 'Cell 4G connection';
                states[Connection.NONE] = 'No network connection';

                if (states[networkState] == states[Connection.NONE] || states[networkState] == states[Connection.UNKNOWN]) {
                    $deferred.resolve(false);
                } else {
                    $deferred.resolve(true);
                }
            } else {
                if (navigator.onLine) {
                    $deferred.resolve(true);
                } else {
                    $deferred.resolve(false);
                }
            }
            return $deferred.promise();
        };

        Utility.prototype.checkConnectionForClosure = function () {

            return this.checkConnection;
        }

        // Function Name: initalizeConsoleLogging.
        // Description: Sets the logging level for the app.
        Utility.prototype.initalizeConsoleLogging = function () {
            var logLevel = CONSTANT.LOG_LEVEL;

            if (typeof window.console === "undefined") {
                window.console = {};
            }

            this._oldConsole = console;

            var logLevelMap = {
                'NONE': [],
                'ALL': ['log', 'info', 'debug', 'warn', 'error'],
                'INFO': ['info'],
                'DEBUG': ['log', 'debug', 'warn', 'error'],
                'WARN': ['warn'],
                'ERROR': ['warn', 'error'],
                'FATAL': ['error']
            };

            var enabledLogMethods = logLevelMap[logLevel];

            for (methodIndex in logLevelMap.ALL) {
                var method = logLevelMap.ALL[methodIndex];
                // do we really want this method? OR is it not defined at all?
                if ((enabledLogMethods.indexOf(method) == -1) || (console[method] == 'undefined')) {
                    console[method] = function () {};
                }
            }
        };

        Utility.prototype.generateUniqueId = function () {
            function s4() {
                return Math.floor((1 + Math.random()) * 0x10000)
                    .toString(16)
                    .substring(1);
            }
            return s4() + s4() + s4() + s4() + s4() + s4() + s4() + s4();
        };

        Utility.prototype.setLocalStorageData = function (key, value) {

            var data = null;
            if (typeof value == "object") {
                data = JSON.stringify(value);
            } else {
                data = value;
            }

            localStorage.setItem(key, data);
            data = null;
        };

        Utility.prototype.getLocalStorageObjectData = function (key) {
            return JSON.parse(localStorage.getItem(key));

        };

        Utility.prototype.getLocalStorageStringData = function (key) {
            return localStorage.getItem(key);

        };

        Utility.prototype.removeLocalStorageData = function (key) {

            if (localStorage.getItem(key)) {
                localStorage.removeItem(key);
            }
        };

        Utility.prototype.calculateTime = function (totalSec) {
            var hh = Math.floor(totalSec / (60 * 60));
            var mm = Math.floor((totalSec / (60)) - (hh * 60));
            var ss = (totalSec) - (hh * 3600) - (mm * 60);

            var result = (hh < 10 ? "0" + hh : hh) + ":" + (mm < 10 ? "0" + mm : mm) + ":" + (ss < 10 ? "0" + ss : ss);

            return result;
        };
        Utility.prototype.getWeek = function (date) {
            var date = new Date(date);
            date.setHours(0, 0, 0, 0);
            // Thursday in current week decides the year.
            date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
            // January 4 is always in week 1.
            var week1 = new Date(date.getFullYear(), 0, 4);
            // Adjust to Thursday in week 1 and count number of weeks from date to week1.
            return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
        };

        Utility.prototype.getGMTDate = function (date) {
            var date = new Date(date);
            var gmt = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));
            return gmt.getTime();
        }

        Utility.prototype.getUTCDate = function (date) {
            var date = new Date(date);
            var utc = new Date(date.getTime() + (date.getTimezoneOffset() * 60000));
            return utc.getTime();
        }

        Utility.prototype.getTimeDifferenceRecords = function (startTime, endTime) {

            var obj = {
                    date: "",
                    startTime: "",
                    endTime: ""
                },
                arr = [],
                copiedObject = {},
                dayOffset = 86400000,

                startTimeObj = new Date(startTime),
                endTimeObj = new Date(endTime),
                timeDiff = endTimeObj.getTime() - startTimeObj.getTime(),

                sec = (timeDiff > 0) ? (timeDiff / 1000) : 0,
                mins = (sec > 0) ? sec / 60 : 0,
                hrs = (mins > 0) ? mins / 60 : 0,
                days = (hrs > 0) ? hrs / 24 : 0;

            if ((startTimeObj.getFullYear() != endTimeObj.getFullYear()) || (startTimeObj.getMonth() != endTimeObj.getMonth()) || (startTimeObj.getDate() != endTimeObj.getDate())) {
                var daysCalcNewDate = new Date(startTimeObj.getTime());
                var cnt = 1;

                do {
                    daysCalcNewDate.setDate(daysCalcNewDate.getDate() + 1);
                    days = cnt;
                    cnt++;
                } while ((endTimeObj.getFullYear() > daysCalcNewDate.getFullYear()) || (endTimeObj.getMonth() > daysCalcNewDate.getMonth()) || (endTimeObj.getDate() > daysCalcNewDate.getDate()))
            }

            console.log("days: " + days + " hrs: " + hrs + " mins: " + mins + " sec: " + sec + " diff: " + timeDiff);
            console.log("start date: " + startTimeObj.toString());
            console.log("end date: " + endTimeObj.toString());

            if (parseInt(days) > 1) {
                copiedObject = jQuery.extend({}, obj);

                copiedObject.date = startTimeObj.getFullYear() + '-' + ('0' + (startTimeObj.getMonth() + 1)).slice(-2) + '-' + ('0' + startTimeObj.getDate()).slice(-2);

                copiedObject.startTime = this.convertDate(startTimeObj.getTime());
                copiedObject.endTime = copiedObject.date + ' 23:59:59';
                arr.push(copiedObject);

                for (var i = 1; i < days; i++) {

                    copiedObject = jQuery.extend({}, obj);
                    var newDate = new Date(startTimeObj.getTime());
                    newDate.setDate(newDate.getDate() + i);

                    copiedObject.date = newDate.getFullYear() + '-' + ('0' + (newDate.getMonth() + 1)).slice(-2) + '-' + ('0' + newDate.getDate()).slice(-2);
                    copiedObject.startTime = copiedObject.date + ' 00:00:00';
                    copiedObject.endTime = copiedObject.date + ' 23:59:59';
                    arr.push(copiedObject);

                }

                copiedObject = jQuery.extend({}, obj);

                copiedObject.date = endTimeObj.getFullYear() + '-' + ('0' + (endTimeObj.getMonth() + 1)).slice(-2) + '-' + ('0' + endTimeObj.getDate()).slice(-2);
                copiedObject.startTime = copiedObject.date + ' 00:00:00';
                copiedObject.endTime = this.convertDate(endTimeObj.getTime());
                arr.push(copiedObject);

            } else if (parseInt(timeDiff) > 0) {

                copiedObject = jQuery.extend({}, obj);

                if (startTimeObj.getDate() === endTimeObj.getDate()) {

                    copiedObject.date = startTimeObj.getFullYear() + '-' + ('0' + (startTimeObj.getMonth() + 1)).slice(-2) + '-' + ('0' + startTimeObj.getDate()).slice(-2);
                    copiedObject.startTime = this.convertDate(startTimeObj.getTime());
                    copiedObject.endTime = this.convertDate(endTimeObj.getTime());
                    arr.push(copiedObject);
                } else {

                    copiedObject.date = startTimeObj.getFullYear() + '-' + ('0' + (startTimeObj.getMonth() + 1)).slice(-2) + '-' + ('0' + startTimeObj.getDate()).slice(-2);

                    copiedObject.startTime = this.convertDate(startTimeObj.getTime());
                    copiedObject.endTime = copiedObject.date + ' 23:59:59';
                    arr.push(copiedObject);

                    copiedObject = jQuery.extend({}, obj);

                    copiedObject.date = endTimeObj.getFullYear() + '-' + ('0' + (endTimeObj.getMonth() + 1)).slice(-2) + '-' + ('0' + endTimeObj.getDate()).slice(-2);
                    copiedObject.startTime = copiedObject.date + ' 00:00:00';
                    copiedObject.endTime = this.convertDate(endTimeObj.getTime());
                    arr.push(copiedObject);
                }
            }

            console.log("Final result: ", arr);
            return arr;
        }

        Utility.prototype.formatTableRecords = function (tableRecords) {

            var formattedObj = {},
                $deferred = new $.Deferred();

            if (tableRecords && tableRecords.length > 0) {
                for (var i = 0; i < tableRecords.length; i++) {
                    if(tableRecords[i].value) {
                        formattedObj[tableRecords[i].value.id] = tableRecords[i].value;
                    } else {
                        formattedObj[tableRecords[i].id] = tableRecords[i];
                    }
                    
                    if (i === (tableRecords.length - 1)) {
                        $deferred.resolve(formattedObj);
                    }
                }
            } else {
                $deferred.resolve(formattedObj);
            }

            return $deferred.promise();;
        }

        Utility.prototype.showAddress = function(address,element){

                    // showAddress is used for displaying map inside a cointer in addNewJobsView
                    
                    /*Whenever this function is called 
                    Please ensure that the element passed has the following css properties,
                    position:absolute; width and height as per required. */
                    
                    var directionsDisplay;
                    var directionsService = new google.maps.DirectionsService();
                    var map;

                    var geocoder = new google.maps.Geocoder()
                    directionsDisplay = new google.maps.DirectionsRenderer();

                    var mapOptions = {
                        zoom:15
                    };
                        
                    var i,q=0;
                    var add = address;

                    geocoder.geocode( { 'address': add}, function(results, status) {
                    if(results && results[0] && results[0].geometry) {
                        map = new google.maps.Map(document.getElementById(element), mapOptions);
                        map.setCenter(results[0].geometry.location);
                        // var infowindow = new google.maps.InfoWindow({
                        //     map: map,
                        //     position: results[0].geometry.location,
                        //     content: '<div class="clientLoc" data-index="'+q+'">'+add+'</div>'
                        // });
                        var marker = new google.maps.Marker({
                            position: results[0].geometry.location,
                            map: map,
                            icon: 'images/map-pin-icon.png' 
                        });
                        
                         //    google.maps.event.addListener(marker, 'click', function() {
                         //        var contentStr="<div class='maplocation'>"+
                         //                    "<div>"+
                         //                        "<p>"+add+"</p>"+
                         //                    "</div>"+
                         //                "</div>";

                         //    var infowindow = new google.maps.InfoWindow({ 
                         //        content: contentStr
                         //    });
                         //    infowindow.open(map,marker);
                         // });

                    } 
                
                });

                directionsDisplay.setMap(map);
        },

        Utility.prototype.locateAddress = function(address,element){

                    // locateAddress is used for displaying map inside a cointer where ever required.
                    
                    /*Whenever this function is called 
                    Please ensure that the element passed has the following css properties,
                    position:absolute; width and height as per required. */
                    
                    var directionsDisplay;
                    var directionsService = new google.maps.DirectionsService();
                    var map;

                    var geocoder = new google.maps.Geocoder()
                    directionsDisplay = new google.maps.DirectionsRenderer();

                    var mapOptions = {
                        zoom:15
                    };

                    $('#'+element).show();
                    $('#popup-overlay').show();                    
                    $('#popup-overlay').on('click',function(){
                        $('#'+element).hide();
                        $(this).hide();
                        $('#popup-overlay').off('click');
                    })

                    
                    var i,q=0;
                    var add = address;

                    geocoder.geocode( { 'address': add}, function(results, status) {
                    if(results && results[0] && results[0].geometry) {
                        map = new google.maps.Map(document.getElementById(element), mapOptions);
                        map.setCenter(results[0].geometry.location);
                        // var infowindow = new google.maps.InfoWindow({
                        //     map: map,
                        //     position: results[0].geometry.location,
                        //     content: '<div class="clientLoc" data-index="'+q+'">'+add+'</div>'
                        // });
                        var marker = new google.maps.Marker({
                            position: results[0].geometry.location,
                            map: map,
                            icon: 'images/map-pin-icon.png' 
                        });

                        var contentStr="<div class='rows maplocation'>"+
                                            "<div class=col-md-8>"+
                                                "<p>"+add+"</p>"+
                                            "</div>"+
                                        "</div>";
                            var infowindow = new google.maps.InfoWindow({ 
                                content: contentStr
                            });
                           // q++;
                            google.maps.event.addListener(marker, 'click', function() {
                            infowindow.open(map,marker);
                         });

                    } else {
                        $('#'+element).html('<div class="map-not-available">Data Not Available</div>');
                    }
                
                });

                directionsDisplay.setMap(map);
        },
        
        
        Utility.prototype.dateFormattor = function() {
            //http://jacwright.com/projects/javascript/date_format/
            Date.prototype.format = function(format) {
                var returnStr = '';
                var replace = Date.replaceChars;
                for (var i = 0; i < format.length; i++) {       var curChar = format.charAt(i);         if (i - 1 >= 0 && format.charAt(i - 1) == "\\") {
                        returnStr += curChar;
                    }
                    else if (replace[curChar]) {
                        returnStr += replace[curChar].call(this);
                    } else if (curChar != "\\"){
                        returnStr += curChar;
                    }
                }
                return returnStr;
            };

            Date.replaceChars = {
                shortMonths: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                longMonths: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
                shortDays: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
                longDays: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],

                // Day
                d: function() { return (this.getDate() < 10 ? '0' : '') + this.getDate(); },
                D: function() { return Date.replaceChars.shortDays[this.getDay()]; },
                j: function() { return this.getDate(); },
                l: function() { return Date.replaceChars.longDays[this.getDay()]; },
                N: function() { return this.getDay() + 1; },
                S: function() { return (this.getDate() % 10 == 1 && this.getDate() != 11 ? 'st' : (this.getDate() % 10 == 2 && this.getDate() != 12 ? 'nd' : (this.getDate() % 10 == 3 && this.getDate() != 13 ? 'rd' : 'th'))); },
                w: function() { return this.getDay(); },
                z: function() { var d = new Date(this.getFullYear(),0,1); return Math.ceil((this - d) / 86400000); }, // Fixed now
                // Week
                W: function() { var d = new Date(this.getFullYear(), 0, 1); return Math.ceil((((this - d) / 86400000) + d.getDay() + 1) / 7); }, // Fixed now
                // Month
                F: function() { return Date.replaceChars.longMonths[this.getMonth()]; },
                m: function() { return (this.getMonth() < 9 ? '0' : '') + (this.getMonth() + 1); },
                M: function() { return Date.replaceChars.shortMonths[this.getMonth()]; },
                n: function() { return this.getMonth() + 1; },
                t: function() { var d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 0).getDate() }, // Fixed now, gets #days of date
                // Year
                L: function() { var year = this.getFullYear(); return (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)); },   // Fixed now
                o: function() { var d  = new Date(this.valueOf());  d.setDate(d.getDate() - ((this.getDay() + 6) % 7) + 3); return d.getFullYear();}, //Fixed now
                Y: function() { return this.getFullYear(); },
                y: function() { return ('' + this.getFullYear()).substr(2); },
                // Time
                a: function() { return this.getHours() < 12 ? 'am' : 'pm'; },
                A: function() { return this.getHours() < 12 ? 'AM' : 'PM'; },
                B: function() { return Math.floor((((this.getUTCHours() + 1) % 24) + this.getUTCMinutes() / 60 + this.getUTCSeconds() / 3600) * 1000 / 24); }, // Fixed now
                g: function() { return this.getHours() % 12 || 12; },
                G: function() { return this.getHours(); },
                h: function() { return ((this.getHours() % 12 || 12) < 10 ? '0' : '') + (this.getHours() % 12 || 12); },
                H: function() { return (this.getHours() < 10 ? '0' : '') + this.getHours(); },
                i: function() { return (this.getMinutes() < 10 ? '0' : '') + this.getMinutes(); },
                s: function() { return (this.getSeconds() < 10 ? '0' : '') + this.getSeconds(); },
                u: function() { var m = this.getMilliseconds(); return (m < 10 ? '00' : (m < 100 ?
            '0' : '')) + m; },
                // Timezone
                e: function() { return "Not Yet Supported"; },
                I: function() {
                    var DST = null;
                        for (var i = 0; i < 12; ++i) {
                                var d = new Date(this.getFullYear(), i, 1);
                                var offset = d.getTimezoneOffset();

                                if (DST === null) DST = offset;
                                else if (offset < DST) { DST = offset; break; }                     else if (offset > DST) break;
                        }
                        return (this.getTimezoneOffset() == DST) | 0;
                    },
                O: function() { return (-this.getTimezoneOffset() < 0 ? '-' : '+') + (Math.abs(this.getTimezoneOffset() / 60) < 10 ? '0' : '') + (Math.abs(this.getTimezoneOffset() / 60)) + '00'; },
                P: function() { return (-this.getTimezoneOffset() < 0 ? '-' : '+') + (Math.abs(this.getTimezoneOffset() / 60) < 10 ? '0' : '') + (Math.abs(this.getTimezoneOffset() / 60)) + ':00'; }, // Fixed now
                T: function() { var m = this.getMonth(); this.setMonth(0); var result = this.toTimeString().replace(/^.+ \(?([^\)]+)\)?$/, '$1'); this.setMonth(m); return result;},
                Z: function() { return -this.getTimezoneOffset() * 60; },
                // Full Date/Time
                c: function() { return this.format("Y-m-d\\TH:i:sP"); }, // Fixed now
                r: function() { return this.toString(); },
                U: function() { return this.getTime() / 1000; }
            };         
        }

        return Utility;
    });
