/*
 * WebSQL:
 *      version: 1.0
 *      Cross Platform: true
 *      Initialization:
 *          Initializes on object creation.
 *      Date: 2/12/2015
 *      Functionality:
 *          CRUD operations on WebSQL.
 */

define(["js/utilities/Constant",
        "i18n!js/nls/str",
        "jquery"
    ],
    function (CONSTANT, INTERNATIONALIZATION, $) {

        // Applying strict mode for variable declarations.
        "use strict";

        // Reference to html5sql library.
        var SqlDb = null;

        // Method to process the queries.
        var processQuery = function (query, successMsg, failureMsg) {
            var startTime = new Date();
            var $deferred = $.Deferred();
            SqlDb.process(query,
                function (transaction, results, rowsArray) { // Success callback function.

                    if (rowsArray) {
                        rowsArray = rowsArray.map(function (record) {
                            return {
                                key: record.key,
                                value: JSON.parse(record.value)
                            }
                        });
                        $deferred.resolve(rowsArray);
                    } else {
                        $deferred.resolve(true);
                    }
                    var endTime = new Date();
                    console.log(successMsg + ((endTime - startTime) / 1000) + "s");
                },
                function (error, failingQuery) { // Failure callback function.
                    var errorStr = "Error :" + failureMsg +
                        "\n Error Desc :" + error.message +
                        "\n In Statement/s :" + failingQuery;
                    $deferred.reject(false);
                    console.error(errorStr);
                }
            );

            return $deferred.promise();
        };

        // Util function to get key,val pair from passed object.
        var getKeyVal = function (obj) {
            var keys = [];
            var values = [];
            var temp = "";
            for (var k in obj) {
                keys.push(k);
                values.push(obj[k]);
            }
            for (var c in values) {
                temp += "'";
                temp += values[c];
                temp += "',";
            }
            temp = temp.slice(0, temp.length - 1);
            return {
                keys: keys,
                values: values,
                valuesStr: temp
            };
        };

        //Constructor
        function WebSql() {
            SqlDb = html5sql;
        }

        // Creates new database or opens an existing one.
        // Parameter: <String> dbName - Name of the DB.
        //            <String> dbDesc - Display name of the DB.
        //            <String> dbSize - Size of the DB.
        WebSql.prototype.open = function (dbName, dbDesc, dbSize) {
            var dbName = dbName || CONSTANT.DB.DB_NAME;
            var dbDesc = dbDesc || CONSTANT.DB.DB_DISPLAY_NAME;
            var dbSize = dbSize || CONSTANT.DB.DB_SIZE;
            var $deferred = new $.Deferred();
            try {
                SqlDb.openDatabase(dbName, dbDesc, dbSize);
                // Return success on successful creation of the DB.
                $deferred.resolve(true);
            } catch (error) {
                // Return error.
                $deferred.reject(false);
                console.log("Error in OpenDb " + error.message);
            } finally {

            }
            return $deferred.promise();
        };

        // Insert a new row into the Db.
        // Parameter: <String> tablename - name of the table to insert values into.
        //            <Array> objArray - Array of the data to be inserted in key value pair.
        WebSql.prototype.insert = function (tablename, objArray) {
            var sqlQueries = [];
            var str;
            for (var record in objArray) {
                str = "INSERT INTO " + tablename + "(key,value) VALUES (" + "\'" + objArray[record].key + "\'," + "\'" + JSON.stringify(objArray[record].value) + "\'" + ")";
                sqlQueries.push(str);
            }
            return (processQuery(sqlQueries, INTERNATIONALIZATION.INSERT_ROW_SUCCESS, INTERNATIONALIZATION.INSERT_ROW_FAILURE));
        };

        // Selects the record on the basis of selectors provided.
        // Parameters: <String> tablename - Name of the table from which the value is to be retrieved.
        //             <String> key - Primary key of the data to be retrieved.
        WebSql.prototype.select = function (tablename, key) {
            var sqlQueries;
            if (key) {
                // Returns the result set after successful retrieval.
                sqlQueries = "SELECT * FROM " + tablename + " WHERE key=" + "\'" + key + "\'";
            } else {
                // Returns all the records if no key specified.
                sqlQueries = "SELECT * FROM " + tablename;
            }

            return (processQuery(sqlQueries, INTERNATIONALIZATION.SELECT_ROWS_SUCCESS, INTERNATIONALIZATION.SELECT_ROWS_FAILURE));
        };

        // Creates new tables in the DB.
        // Parameter: <Array> tablenameArray - contains the names of the tables to be created.
        WebSql.prototype.createTables = function (tablenameArray) {
            var sqlQueries = [];
            var str;
            for (var record in tablenameArray) {
                str = 'CREATE TABLE IF NOT EXISTS ' + tablenameArray[record] + '( \"key\" Char(100 ) PRIMARY KEY NOT NULL,\"value\" Char(1000) NOT NULL)';
                sqlQueries.push(str);
            }

            return (processQuery(sqlQueries, INTERNATIONALIZATION.CREATE_TABLE_SUCCESS, INTERNATIONALIZATION.CREATE_TABLE_FAILURE));
        };

        // Deletes a particular record from the DB table.
        // Parameter: <String> tablename - name of the table to delete the record from.
        //            <String> key - Primary key of the record to be deleted.
        WebSql.prototype.remove = function (tablename, key) {
            var sqlQueries = null;
            if (key) {
                sqlQueries = "DELETE FROM " + tablename + " WHERE key=" + "\'" + key + "\'";
            } else {
                sqlQueries = "DELETE FROM " + tablename;
            }
            return (processQuery(sqlQueries, INTERNATIONALIZATION.DELETE_ROW_SUCCESS, INTERNATIONALIZATION.DELETE_ROW_FAILURE));
        };

        // Deletes a particular record from the DB table.
        // Parameter: <String> tablename - name of the table to delete the record from.
        //            <String> key - Primary key of the record to be deleted.
        WebSql.prototype.removeMultiple = function (tablename, keyArray) {

            var sqlQueries = [];
            var str;

            for (var key in keyArray) {
                if (key) {
                    str = "DELETE FROM " + tablename + " WHERE key=" + "\'" + keyArray[key] + "\'";
                }
                sqlQueries.push(str);
            }
            return (processQuery(sqlQueries, INTERNATIONALIZATION.DELETE_ROW_SUCCESS, INTERNATIONALIZATION.DELETE_ROW_FAILURE));
        };

        // Drops the DB table.
        // Parameter: <String> tablename - name of the table to be deleted.
        WebSql.prototype.drop = function (tablename) {
            var $deferred = new $.Deferred();
            var sqlQueries = "DROP TABLE IF EXISTS " + tablename;
            processQuery(sqlQueries, INTERNATIONALIZATION.DROP_TABLE_SUCCESS, INTERNATIONALIZATION.DROP_TABLE_FAILURE).done(function () {
                $deferred.resolve(true);
            }).fail(function (error) {
                $deferred.reject(error);
            });

            return $deferred.promise();
        };

        // Updates a particular record in the DB table.
        // Parameters: <String> tablename - name of the table in which we need to update the record.
        //             <Object> updateRequestObject - it holds the key value pair of the records to be updated.
        WebSql.prototype.update = function (tablename, updateRequestObject) {
            var sqlQueries;
            if (updateRequestObject.key) {
                sqlQueries = "UPDATE " + tablename + " SET value=" + "\'" + JSON.stringify(updateRequestObject.value) + "\'" + "WHERE key=" + "\'" + updateRequestObject.key + "\'";
            } else {
                sqlQueries = "UPDATE " + tablename + " SET value=" + "\'" + JSON.stringify(updateRequestObject.value) + "\'";
            }
            return (processQuery(sqlQueries, INTERNATIONALIZATION.UPDATE_ROW_SUCCESS, INTERNATIONALIZATION.UPDATE_ROW_FAILURE));
        };

        // Renames the tables specified in the constants to make them temporary backups.
        WebSql.prototype.renameAllTables = function () {

            var sqlQueries = [];
            var mapperObject = CONSTANT.RENAME_TABLE_MAPPER;
            for (var i in mapperObject) {
                var str = "ALTER TABLE " + i + " RENAME TO " + mapperObject[i];
                sqlQueries.push(str);
            }

            return (processQuery(sqlQueries, INTERNATIONALIZATION.RENAME_ALL_TABLES_SUCCESS, INTERNATIONALIZATION.RENAME_ALL_TABLES_FAILURE));
        };

        // Drops the DB tables listed in the constant above.
        WebSql.prototype.dropDB = function () {
            var $deferred = new $.Deferred();
            var sqlQueries = [];
            for (var index in CONSTANT.AGT_TABLES_LIST) {
                sqlQueries.push("DROP TABLE IF EXISTS " + CONSTANT.FDC_TABLES_LIST[index]);
            }

            processQuery(sqlQueries, INTERNATIONALIZATION.DROP_TABLE_SUCCESS, INTERNATIONALIZATION.DROP_TABLE_FAILURE).done(function () {
                $deferred.resolve(true);
            }).fail(function (error) {
                $deferred.reject(error);
            });

            return $deferred.promise();
        };

        // Renames the tables specified in the constants to make them temporary backups.
        WebSql.prototype.revertTables = function () {

            var sqlQueries = [];
            var revertMapperObject = CONSTANT.REVERT_TABLE_MAPPER;
            for (var i in revertMapperObject) {
                var str = "ALTER TABLE " + i + " RENAME TO " + revertMapperObject[i];
                sqlQueries.push(str);
            }

            return (processQuery(sqlQueries, INTERNATIONALIZATION.REVERT_ALL_TABLES_SUCCESS, INTERNATIONALIZATION.REVERT_ALL_TABLES_FAILURE));
        };

        return WebSql;
    });
