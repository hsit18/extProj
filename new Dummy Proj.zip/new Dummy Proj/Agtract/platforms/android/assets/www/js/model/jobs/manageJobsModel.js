/**
 * Manage Jobs  Model:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:16/02/2015
 * Functionality:
 *
 */
define(['Backbone',
        'js/utilities/Constant',
        'js/model/baseModel/baseModel',
        'js/utilities/Utility',
        'jquery'
    ],

    function (Backbone, CONSTANT, baseModel, Utility, $) {

        'use strict';

        var manageJobsModel = baseModel.extend({

            initialize: function () {
                baseModel.prototype.initialize.call(this);
                this._UtilityObj = new Utility();
            },

            fetchManageJobsData: function () {
                var that = this,
                    $deferred = new $.Deferred(),
                    currentUser = localStorage.getItem('currentUserID'),
                    manageJobsData = {};

                that._DBManagerObject.open().done(function () {
                    $.when(
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.JOB_TASK_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.JOBS_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.TASKS_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.CLIENTS_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.LOCATIONS_TABLE),
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.UNITS_TABLE)
                    ).done(function (jobTaskRes1, jobsRes, tasksRes, clientsRes, locationsRes, unitsRes) {

                        var jobTaskRes = _.filter(jobTaskRes1, function (obj) {
                            return (obj && obj.value.employee_id === currentUser);
                        });
                        console.log("job task for current employee :", jobTaskRes);

                        var unassignedJobTaskRes = _.filter(jobTaskRes1, function (obj) {
                            return (obj && obj.value.employee_id === null);
                        });
                        console.log("job task not for current employee :", unassignedJobTaskRes);
                        if(unassignedJobTaskRes && unassignedJobTaskRes.length > 0 ) {
                            jobTaskRes = jobTaskRes.concat(unassignedJobTaskRes);
                        }

                        var tasksRes = _.filter(tasksRes, function (obj) {
                            var jobTask = _.findWhere(_.pluck(jobTaskRes, 'value'), {
                                "task_id": obj.value.id
                            });
                            return (jobTask);
                        });
                        console.log("tasks for current employee", tasksRes);

                        var jobsRes = _.filter(jobsRes, function (obj) {
                            var jobTask = _.findWhere(_.pluck(jobTaskRes, 'value'), {
                                "job_id": obj.value.id
                            });
                            return (jobTask);
                        });
                        console.log("jobs for current employee", jobsRes);

                        var units = unitsRes;

                        $.when(
                            that._UtilityObj.formatTableRecords(jobTaskRes),
                            that._UtilityObj.formatTableRecords(tasksRes),
                            that._UtilityObj.formatTableRecords(jobsRes),
                            that._UtilityObj.formatTableRecords(units)
                        ).done(function (jobTaskResponse, tasksResponse, jobsResponse, unitsResponse) {
                            manageJobsData["job_tasks"] = jobTaskResponse;
                            manageJobsData["tasks"] = tasksResponse;
                            manageJobsData["jobs"] = jobsResponse;
                            manageJobsData["units"] = unitsResponse;

                            var locationsRes1 = _.filter(locationsRes, function (obj) {
                                 var jobs = _.findWhere(jobsResponse, {
                                    "location_id": obj.value.id
                                });
                                return (jobs);
                            });
                            console.log("locations", locationsRes);

                            var clientsRes1 = _.filter(clientsRes, function (obj) {
                                var jobs = _.findWhere(manageJobsData["jobs"], {
                                    "client_id": obj.value.id
                                });
                                return (jobs);
                            });
                            console.log("clients", clientsRes);
                            
                            var today = new Date();
                            today.setHours(0,0,0);
                            
                            console.log("today    ", today);
                            var currentJobs = _.filter(jobsResponse, function (obj) {
                                var dateobj = new Date(obj.start_date);
                                if(obj.start_date && dateobj) {
                                    dateobj.setHours(0,0,0);
                                    //console.log("dateobj    ", dateobj);
                                    if(today.getTime() >= dateobj.getTime()) {
                                        return (obj);
                                    }
                                }                                
                            });
                            
                             var assignedJobs = _.filter(jobsResponse, function (obj) {
                                var dateobj = new Date(obj.start_date);
                                if(obj.start_date && dateobj) {
                                    dateobj.setHours(0,0,0);
                                    //console.log("dateobj    ", dateobj);
                                    if(today.getTime() < dateobj.getTime()) {
                                        return (obj);
                                    }
                                }                                
                            });
                            
                            $.when(
                                that._UtilityObj.formatTableRecords(locationsRes1),
                                that._UtilityObj.formatTableRecords(clientsRes1),
                                that._UtilityObj.formatTableRecords(currentJobs),
                                that._UtilityObj.formatTableRecords(assignedJobs)
                            ).done(function (locationsResponse, clientsResponse, currentJobsResponse, assignedJobsResponse) {
                                manageJobsData["locations"] = locationsResponse;
                                manageJobsData["clients"] = clientsResponse;
                                manageJobsData["currentJobs"] = currentJobsResponse;
                                manageJobsData["assignedJobs"] = assignedJobsResponse;
                                $deferred.resolve(manageJobsData);
                            });

                        });

                    }).fail(function () {
                        console.log("failed to load data");
                        $deferred.reject();
                    });
                });
                return $deferred.promise();
            },

            proccessTimesheetRecords: function (jobTasksData) {
                var that = this,
                    i = 0,
                    time = 0,
                    $deferred = new $.Deferred(),
                    currentUser = localStorage.getItem('currentUserID'),
                    jobsTimesheetRecords = {};

                that._DBManagerObject.select(CONSTANT.DB_TABLES.TIMESHEETS_TABLE).done(function (response) {

                    if (response && response.length > 0) {

                        var timesheetRecords = _.pluck(response, 'value');

                        for (var id in jobTasksData) {

                            var jobTSRecords = _.where(timesheetRecords, {
                                'job_id': jobTasksData[id].job_id,
                                'task_id': jobTasksData[id].task_id
                            });
                            jobsTimesheetRecords[id] = {};
                            if (jobTSRecords && jobTSRecords.length > 0) {

                                var finishedRec = _.where(jobTSRecords, {
                                    'action': CONSTANT.JOB_ACTION.FINISH
                                });

                                if (finishedRec && finishedRec.length > 0) {
                                    if(finishedRec[0].end_time) {
                                        var dateObj = new Date(finishedRec[0].end_time);
                                        if(dateObj) {
                                            jobsTimesheetRecords[id]['complete_date'] = dateObj.format('M, d Y')
                                        }                                        
                                    }                                    
                                    jobsTimesheetRecords[id]['job_status'] = CONSTANT.TASK_STATUS.COMPLETED;
                                } else {
                                    var pausedRec = _.where(jobTSRecords, {
                                        'action': CONSTANT.JOB_ACTION.PAUSE,
                                        'end_time': null
                                    });
                                    if (pausedRec && pausedRec.length > 0) {
                                        jobsTimesheetRecords[id]['job_status'] = CONSTANT.TASK_STATUS.ON_HOLD;
                                    } else {
                                        var resumedRec = _.where(jobTSRecords, {
                                            'action': CONSTANT.JOB_ACTION.RESUME,
                                            'end_time': null
                                        });
                                        var startedRec = _.where(jobTSRecords, {
                                            'action': CONSTANT.JOB_ACTION.START,
                                            'end_time': null
                                        });
                                        if ((resumedRec && resumedRec.length > 0) || (startedRec && startedRec.length > 0)) {
                                            jobsTimesheetRecords[id]['job_status'] = CONSTANT.TASK_STATUS.IN_PROGRESS;
                                        } else {
                                            jobsTimesheetRecords[id]['job_status'] = CONSTANT.TASK_STATUS.NOT_STARTED;
                                        }
                                    }
                                }

                            } else {
                                jobsTimesheetRecords[id]['job_status'] = CONSTANT.TASK_STATUS.NOT_STARTED;
                            }
                            if (jobsTimesheetRecords[id] !== CONSTANT.TASK_STATUS.NOT_STARTED) {
                                var startedRes = _.findWhere(jobTSRecords, {
                                    'action': CONSTANT.JOB_ACTION.START
                                });
                                //var finishedRes = _.findWhere(jobTSRecords, {'action': CONSTANT.JOB_ACTION.FINISH});
                                if (startedRes && startedRes.end_time) {
                                    time = (new Date(startedRes.end_time).getTime()) - (new Date(startedRes.start_time).getTime());
                                    var resumedRes = _.where(jobTSRecords, {
                                        'action': CONSTANT.JOB_ACTION.RESUME
                                    });

                                    for (var j in resumedRes) {
                                        time += (new Date(resumedRes[j].end_time).getTime()) - (new Date(resumedRes[j].start_time).getTime());
                                    }
                                    if (time > 0) {
                                        jobsTimesheetRecords[id]['time_taken'] = that._UtilityObj.calculateTime(time / 1000).slice(0, 5);
                                    }
                                }
                            }

                            i++;
                            if (i === Object.keys(jobTasksData).length) {
                                $deferred.resolve(jobsTimesheetRecords);
                            }
                        }
                    } else {
                        $deferred.resolve();
                    }
                });
                return $deferred.promise();
            },

            assignJob: function(jobTaskId){
                var that = this,
                    $deferred = new $.Deferred(),
                    currentUser = localStorage.getItem('currentUserID');

                that._DBManagerObject.open().done(function(){
                    that._DBManagerObject.select(CONSTANT.DB_TABLES.JOB_TASK_TABLE).done(function(jobTaskRes){

                        var jobTask = _.findWhere(_.pluck(jobTaskRes, 'value'), {
                            "id": jobTaskId.toString()
                        });

                        console.log("old job task record", jobTask);

                        var cloneObj = $.extend({}, jobTask);
                        cloneObj["employee_id"] = currentUser;

                        var updateObj = {
                            key: jobTask.id,
                            value: cloneObj
                        };

                        that._DBManagerObject.update(CONSTANT.DB_TABLES.JOB_TASK_TABLE, updateObj, true).done(function(updatedRes){
                            console.log("new job task record",updateObj);
                            that.processSyncNowService().done(function () {
                                $deferred.resolve();
                            });                                                    
                        }).fail(function(){
                            console.log("failed to assign job task");
                            $deferred.reject();
                        });                                         

                    }).fail(function(){
                        $deferred.reject();
                    });
                });              

                return $deferred.promise();
            }

        });

        return manageJobsModel;

    });
