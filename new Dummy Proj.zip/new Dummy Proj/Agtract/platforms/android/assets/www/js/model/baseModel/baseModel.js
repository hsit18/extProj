/**
 * Base  Model:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:2/12/2015
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Utility',
        'js/utilities/Messenger',
        'js/model/baseModel/serviceCommunicatorModel',
        'js/model/baseModel/DbCommunicatorModel',
        'js/model/baseModel/OfflineQueueModel',
    ],

    function (Backbone, CONSTANT, Utility, Messenger, serviceCommunicatorModel, DbCommunicatorModel, OfflineQueueModel) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';

        var messengerObject, utilityObject;

        var baseModel = Backbone.Model.extend({

            initialize: function () {
                this._dbCommunicatorModel = new DbCommunicatorModel();
                this._offlineQueueModel = new OfflineQueueModel();
                this._serviceCommunicatorModel = new serviceCommunicatorModel();
                this._DBManagerObject = this._dbCommunicatorModel._DBManagerObject;
                this._messengerObject = Messenger.getInstance();
                this._utilityObject = new Utility();
            },

            processDownloadDataService: function () {

                var that = this,
                    $deferred = new $.Deferred();

                this._utilityObject.checkConnection().done(function (isOnline) {
                    if (isOnline) {
                        that._serviceCommunicatorModel.getDownloadDataResponse().done(function (response) {
                            if (response) {
                                that._dbCommunicatorModel.insertDownloadDataResponseToDB(response).done(function () {
                                    $deferred.resolve(response);
                                });
                            } else {
                                $deferred.resolve(response);
                            }
                        });
                    } else {
                        that._messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.NO_CONNECTIVITY_ERROR);
                        $deferred.resolve(false);
                    }
                });
                return $deferred.promise();
            },

            processDashboardData: function () {

                var that = this;
                var $deferred = new $.Deferred();

                that._serviceCommunicatorModel.getDashboardData().done(function (response) {
                    $deferred.resolve(response);
                });
                return $deferred.promise();

            },

            // processCompletedJobData: function() {
            //     var deferred = new $.Deferred();

            //     var that = this;

            //     that._serviceCommunicatorModel.getJobs().done(function(jobResponse){
            //         deferred.resolve(jobResponse);
            //     }).fail(function(){
            //         console.log("failed to get data");
            //     });
            //     return deferred.promise();
            // },

            processLoginResponse: function (username, password) {

                var $deferred = new $.Deferred(),
                    that = this;

                this._utilityObject.checkConnection().done(function (isOnline) {
                    if (isOnline) {
                        that._serviceCommunicatorModel.getLoginResponse(username, password).done(function (responseObj) {
                            //login response success
                            console.log("validateFirstTimeLogin:service hit success");

                            if (typeof (responseObj) === CONSTANT.STRING) {
                                responseObj = JSON.parse(responseObj);
                            }
                            console.log(responseObj);
                            if (responseObj) {
                                if (responseObj.success === "false") {
                                    $deferred.reject(responseObj.message);
                                }
                                $deferred.resolve(responseObj);
                            } else {
                                $deferred.resolve(responseObj);
                            }

                        }).fail(function (error) {
                            //login response fails
                            console.log("validateFirstTimeLogin:service hit fail");
                            //console.log(error);
                            $deferred.reject();
                        });
                    } else {
                        that._messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.NO_CONNECTIVITY_ERROR);
                        $deferred.resolve(false);
                    }
                });

                return $deferred.promise();
            },

            processForgetPasswordResponse: function (userName, emailId) {

                var $deferred = new $.Deferred(),
                    that = this;

                this._utilityObject.checkConnection().done(function (isOnline) {
                    if (isOnline) {
                        that._serviceCommunicatorModel.getForgetPasswordResponse(userName, emailId).done(function (responseObj) {
                            var forgot_Password = responseObj;
                            //alert(forgot_Password.ForgotPassword.msg);
                            //console.log(responseObj);
                            if (typeof (responseObj) === CONSTANT.STRING) {
                                responseObj = JSON.parse(responseObj);
                            }
                            if (responseObj) {
                                if (responseObj.success && responseObj.success === "false") {
                                    that._messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, forgot_Password.msg);
                                    //$deferred.reject();
                                }

                                $deferred.reject();
                            } else {
                                $deferred.resolve(responseObj);

                            }

                        }).fail(function (error) {
                            //login response fails
                            console.log("forget password service failed");
                            console.log(error);
                            $deferred.reject();
                        });
                    } else {
                        that._messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.NO_CONNECTIVITY_ERROR);
                        $deferred.resolve(false);
                    }
                });

                return $deferred.promise();
            },

            processDeltaServices: function () {

                var $deferred = new $.Deferred(),
                    that = this;

                this._utilityObject.checkConnection().done(function (isOnline) {
                    if (isOnline) {
                        that._serviceCommunicatorModel.getDeltaResponse().done(function (responseObj) {
                            
                            if(responseObj === false) {
                                that.invalidSessionLogout().done(function(){
                                    $deferred.reject();
                                });
                            } else {
                                that._dbCommunicatorModel.processDeltaResponseToDB(responseObj).done(function (response) {
                                    $deferred.resolve(response);
                                }).fail(function (error) {
                                    $deferred.reject();
                                });
                            }                            
                        }).fail(function (error) {
                            $deferred.reject();
                        });
                    } else {
                        //that._messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.NO_CONNECTIVITY_ERROR);
                        $deferred.resolve(false);
                    }
                });

                return $deferred.promise();
            },

            processSyncNowService: function () {

                var $deferred = new $.Deferred(),
                    that = this,
                    currentUserId = localStorage.getItem('currentUserID');

                this._utilityObject.checkConnection().done(function (isOnline) {
                    if (isOnline) {
                        that.processImageService().always(function(){
                            that._dbCommunicatorModel.loadCurrentUserQueueRecords(currentUserId).done(function (queueRecords) {
                                if (queueRecords && queueRecords.length > 0) {
                                    that._offlineQueueModel.formatSyncRecords(queueRecords).done(function (syncServiceObj) {
                                        that._serviceCommunicatorModel.syncRecordToServer(currentUserId, syncServiceObj).done(function (serviceRes) {
                                            if(serviceRes === false) {
                                                that.invalidSessionLogout().done(function(){
                                                    $deferred.reject();
                                                });
                                            } else {
                                                that._dbCommunicatorModel.removeTemporaryRecords(serviceRes).done(function () {
                                                    that.processDeltaServices().done(function () {
                                                        $deferred.resolve(syncServiceObj);
                                                    });
                                                });
                                            }
                                        });
                                    });

                                } else {
                                    $deferred.resolve(false);
                                }
                            });                        
                        });                        
                    } else {
                        //that._messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.NO_CONNECTIVITY_ERROR);
                        $deferred.resolve(false);
                    }
                });
                return $deferred.promise();
            },
            
            processImageService: function(){

                var $deferred = new $.Deferred(),
                    that = this,
                    currentUserId = localStorage.getItem('currentUserID');
                
                if(localStorage.getItem('pic_change_path')) {
                    that.getBase64Data(localStorage.getItem('pic_change_path')).done(function(base64Data){
                        var syncServiceObj = {
                                "employees": [
                                    {
                                      "id": currentUserId,
                                      "record_status": CONSTANT.QUEUE_RECORD_STATUS.UPDATED,
                                      "avatar_data": base64Data
                                    }
                                ]
                            };
                        that._serviceCommunicatorModel.syncImageToServer(currentUserId, syncServiceObj).done(function(serviceRes){
                            if(serviceRes === false) {
                                that.invalidSessionLogout().done(function(){
                                    $deferred.reject();
                                });
                            } else {
                                syncServiceObj = null;
                                base64Data = null;
                                localStorage.removeItem('pic_change_path');
                                $deferred.resolve();
                            }
                        }); 
                    });
                } else {
                    $deferred.resolve();
                }
                return $deferred.promise();
            },
       
            getBase64Data: function(filePath){
    
                var $deferred = new $.Deferred(),
                    that = this;
    
                window.resolveLocalFileSystemURL(filePath,function(fileEntry){
                    fileEntry.file(function(file){
                        var reader = new FileReader();
                        reader.onloadend = function(evt) {
                            console.log("Read as data URL");
                            console.log("!!!!!File Data: "+JSON.stringify(evt));
                            $deferred.resolve(evt.target.result);                            
                        };
                        reader.readAsDataURL(file);

                    }, function(error){
                        console.log("Fail to get file entry. File Name: Controller. Function Name: getBase64EncodingString()");
                        console.log("Error code: "+evt.target.error.code);
                        $deferred.reject(error);
                    });
                }, function(){
                    console.log("Fail to get file entry. File Name: Controller. Function Name: getBase64EncodingString()");
                });
    
                return $deferred.promise();
            },
            
            invalidSessionLogout: function(){
                
                var $deferred = new $.Deferred(),
                    that = this;
                
                
                if (navigator.notification) {
                    navigator.notification.confirm(CONSTANT.ALERT_MESSAGES.SESSION_EXPIRED, function () {                        
                        that.processInvalidSessionLogout().done(function(){
                            $deferred.resolve();
                        });                        
                    }, 'Agtract', 'OK');
                } else {
                    alert(CONSTANT.ALERT_MESSAGES.SESSION_EXPIRED);
                    that.processInvalidSessionLogout().done(function(){
                        $deferred.resolve();
                    });
                }               
                return $deferred.promise();                
            },
            
            processInvalidSessionLogout: function(){
                
                var $deferred = new $.Deferred(),
                    that = this;
                
                var currentUserID = that._utilityObject.getLocalStorageStringData(CONSTANT.DB.DB_CURRENT_USER);
                that._utilityObject.showLoader();
                that._DBManagerObject.remove(CONSTANT.DB_TABLES.USER_TABLE, currentUserID).done(function (responseObj) {
                    that._utilityObject.removeLocalStorageData(CONSTANT.DB.DB_CURRENT_USER);
                    that._utilityObject.removeLocalStorageData(CONSTANT.DB.DB_CURRENT_CONTRACTOR);
                    localStorage.removeItem('currentTimestamp');
                    localStorage.removeItem('session_id');
                    router.navigate('login', {
                        trigger: true
                    });
                    that._utilityObject.hideLoader();
                    $deferred.resolve();
                    
                }).fail(function () {
                    //select query on user table failed
                    console.log("invalidSessionLogout:remove record failed");
                    $deferred.reject();
                });                
                return $deferred.promise();                
            }
            
        });

        return baseModel;
    });
