/*
 * Constant:
 *      version: 1.0
 *      Cross Platform: true
 *      Initialization:
 *          Initializes on object creation.
 *      Date: 2/12/2015
 *      Functionality:
 *          Holds all the constants for entire application.
 */

// Require JS module.
define([], function () {

    // Applying strict mode for variable declarations.
    'use strict';

    // Global variable constants.
    var CONSTANT = {
        // GET - service request type.
        GET_REQUEST: 'GET',

        // POST - service request type.
        POST_REQUEST: 'POST',

        // Service content type.
        APP_CONTENT_TYPE: 'application/json',

        // Service response timeout.
        SERVICE_TIMEOUT: 50000,

        // Message type.
        SUCCESS_MESSAGE_TYPE: "success",

        STRING: "string",

        API: {
            BASE_PATH: 'http://192.168.14.27:9002/webservice/webservices.php?',
            //BASE_PATH: 'http://121.243.26.96:9008/webservice/webservices.php?', //Live URl
            DUMMY_BASE_PATH: 'js/temp/',
            LOGIN_SERVICE: 'request=authenticateUser',//loginResponse.json',
            DOWNLOAD_DATA_SERVICE: 'request=responseDownloadDataService',//downloadDataResponse.json',
            FORGET_PASSWORD: 'request=responseForgotPassword',//forgetPasswordResponse.json'
            DELTA_SERVICE: 'request=responseDeltaService',//'severResponseDelta.json',            
            SYNC_SERVICE: 'request=responseSyncService',//'employeeDashboardData.json',
            IMAGE_SYNC_SERVICE: 'request=responseSyncImageService',
            
            DASHBOARD_SERVICE: 'employeeDashboardData.json',
            JOBS_SERVICE: 'jobs.json'
          
        },

        DB: {
            DB_NAME: "AGT",

            DB_VERSION: "1.0",

            DB_DISPLAY_NAME: "AGT 1.0",

            DB_SIZE: 10 * 1024 * 1024,

            DB_TABLE_CREATION_CHECK:"areDBTablesCreated",

            DB_CURRENT_USER:"currentUserID",

            DB_CURRENT_CONTRACTOR: "contractors_id",

            DB_CURRENT_TIMESTAMP:"currentTimestamp"
        },
        
        DB_TABLES: {
            USER_TABLE: "USERS",
            JOBS_TABLE: "JOBS",
            TASKS_TABLE: "TASKS",
            JOB_TASK_TABLE: "JOB_TASK",
            EMPLOYEES_TABLE: "EMPLOYEES",
            MESSAGES_TABLE: "MESSAGES",
            MESSAGE_RECIEVER_TABLE: "MESSAGE_RECIEVER",
            EQUIPMENTS_TABLE: "EQUIPMENTS",
            VEHICLES_TABLE: "VEHICLES",
            CONTRACTOR_TABLE: "CONTRACTOR",
            ATTENDANCE_TABLE: "ATTENDANCE",
            QUEUE_TABLE: "QUEUE",
            LOCATIONS_TABLE: "LOCATIONS",
            CLIENTS_TABLE: "clients",
            CLIENT_LOCATIONS_TABLE: "CLIENT_LOCATIONS",
            UNITS_TABLE: "UNITS",
            TIMESHEETS_TABLE: "TIMESHEETS",
            JOB_LOCATIONS_TABLE: "JOB_LOCATIONS",
            TASK_EQUIPMENTS_TABLE: "TASK_EQUIPMENTS"
        },
        
        AGT_TABLES_LIST: ["USERS", "JOBS", "TASKS", "JOB_TASK", "EMPLOYEES", "MESSAGES",
                          "MESSAGE_RECIEVER", "EQUIPMENTS", "VEHICLES", "CONTRACTOR", "ATTENDANCE", 
                          "QUEUE", "LOCATIONS", "CLIENTS", "CLIENT_LOCATIONS", "UNITS", "TIMESHEETS",
                          "JOB_LOCATIONS", "TASK_EQUIPMENTS"],
        
        SERVER_TABLE_NAME_MAPPER: {
            "jobs": "JOBS",
            "tasks": "TASKS",
            "job_tasks": "JOB_TASK",
            "employees": "EMPLOYEES",
            "messages": "MESSAGES",
            "message_reciever": "MESSAGE_RECIEVER",
            "equipments": "EQUIPMENTS",
            "vehicles": "VEHICLES",
            "contractor": "CONTRACTOR",
            "attendance": "ATTENDANCE", 
            "locations": "LOCATIONS",
            "clients": "CLIENTS",
            "client_locations": "CLIENT_LOCATIONS",
            "units": "UNITS",
            "timesheets": "TIMESHEETS",
            "job_locations": "JOB_LOCATIONS",
            "task_equipments": "TASK_EQUIPMENTS"
        },
        
        ERROR_MESSAGES: {
            INVALID_USERNAME: "Please enter username.",
            INVALID_PASS: "Please enter password.",
            INVALID_USER_OR_PASS: "Invalid username or password.",
            NO_CONNECTIVITY_ERROR: 'Please check your internet connection and try again later.',
            INVALID_EMAIL: "Please enter a valid email ID.",
            INVALID_CURRENT_PASSWORD:"Please enter a valid Current Password",
            INVALID_NEW_PASSWORD:"Please enter a valid New Password",
            INVALID_CONFIRM_PASSWORD:"Please enter a valid Confirm Password",
            INVALID_CONFIRM_AND_NEW_PASSWORDS:"New password does not match Confirm Password",
            INVALID_OLD_AND_NEW_PASSWORD:"Old and New passwords cannot be the same",
            INVALID_PASSWORD:"Password Invalid",
            PASSWORD_UPDATION_FAILED:"Password updation failed.",
            PASSWORD_UPDATED_SUCCESSFULLY:"Password updated Successfully.",
            ANOTHER_TASK_IN_PROGRESS: "Please pause or complete the current task",
            TASK_INVALID:"Please select valid Task.",
            VEHICLE_INVALID:"Please select valid Vehicle.",
            EQUIPMENT_INVALID:"Please select valid Equipment.",
            RATE_INVALID:"Please select valid Rate.",
            CLIENT_INVALID:"Please select valid Client Name",
            CLIENT_LOCATION_INVALID:"Please select valid Client Location.",
            PADDOCK_NO_INVALID:"Please select valid Paddock Number.",
            START_DATE_INVALID:"Please enter a valid Start Time",
            PRIORITY_INVALID:"Please select valid Priority",
            TASKS_ARE_REPEATED:"Two or more tasks are similar",
            SAVED_SUCCESSFULLY:"Job created successfully.",
            EPLOYEE_DATA_UPDATED_SUCCESSFULLY:"Employee Data Updated Successfully.",
            INVALID_FIELDS:"Some fields are Incomplete.",
            INVALID_PHONENUMBER:"Phone Number is Invalid",
            INVALID_PHONENUMBER_DIGITS:"Phone number must have 10 digits.",
            INVALID_PHONENUMBER_NAME:"Phone Emp Name and Phone Number not valid."

        },
        
        ALERT_MESSAGES: {
            CONFIRM_LOGOUT: "Are you sure you want to logout?",
            SESSION_EXPIRED: "Your session has expired.",
            CONFIRM_COMPLETE_TASK: "Are you sure you want to complete this task?"
        },
        
        QUEUE_RECORD_STATUS: {
            CREATED: "added",
            "UPDATED": "updated",
            "DELETED": "deleted"
        },
        QUEUE_RECORD_FIELDS: {
            RECORD_STATUS: "record_status",
            TABLE_NAME: "tableName",
            QUEUE_EMPLOYEE_ID: "queueEmployeeId"
        },
        
        QUEUE_TABLES_LEVEL: {
            "LEVEL0": ["attendance", "employees", "jobs", "job_tasks", "timesheets", "job_locations"]            
        },

        JOB_STATUS: {
            PENDING: "0",
            COMPLETED: "1"
        },
        
        JOB_ACTION: {
            START: "Start",
            PAUSE: "Pause",
            RESUME: "Resume",
            FINISH: "Finish",
            ENROUTE: "Enroute"
        },
        
        TASK_STATUS: {
            NOT_STARTED: "0",
            IN_PROGRESS: "1",
            ON_HOLD: "2",
            COMPLETED: "3"
        },
        
        TASK_STATUS_CSS_CLASS: {
            "0": "not-started",
            "1": "in-progress",
            "2": "on-hold",
            "3": "completed"
        },
                
        JOB_PRIORITY: ['LOW', 'MEDIUM', 'HIGH'],
        
        JOB_PRIORITY_TABLE_MAPPING: {
            LOW: "L",
            MEDIUM: "M",
            HIGH: "H"
        },
        
        JOB_PRIORITY_SERVER_MAPPING: {
            "L": "Low",
            "M": "Medium",
            "H": "High"
        },
        
        PAGE_HEADING: {
            'dashboard': 'Dashboard',
            'manageJobs': 'Jobs',
            'conversations': 'Conversations',
            'messages': 'Messages',
            'map': 'Map',
            'settings': 'Settings'
        }
        
    };

    // Return the object.
    return CONSTANT;
});
