/**
 * Forget Password View:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date: 2/12/2015
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Utility',
        'js/utilities/Messenger',
        'js/model/login/forgetPasswordModel',
        'text!templates/forgetPassword.html'
    ],

    function (Backbone, CONSTANT, Utility, Messenger, forgetPasswordModel, forgetPasswordTemp) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';
        var messengerObject;

        var forgetPasswordView = Backbone.View.extend({

            el: $('#dashboardContainer'),

            initialize: function () {
                messengerObject = Messenger.getInstance();
                this.utilityObject = new Utility();
                this.utilityObject.showLoader();
                this.forgetPasswordModel = new forgetPasswordModel();
                this.render();
            },

            events: {

            },

            addEventListener: function () {
                $('#cancelPassword').unbind('click');
                $('#cancelPassword').bind('click', this.loadLogin);
                $('#submitPassword').unbind('click');
                $('#submitPassword').bind('click', {
                    'context': this
                }, this.submitPassword);
            },

            render: function () {
                var template = _.template(forgetPasswordTemp);
                this.$el.html(template);
                this.utilityObject.hideLoader();
                this.addEventListener();
            },

            loadLogin: function () {
                router.navigate('login', {
                    trigger: true
                });
            },

            submitPassword: function (event) {

                var userName = $('#userName').val();
                var emailId = $('#emailId').val();
                var that = event.data.context;

                that.utilityObject.showLoader();

                that.validateFields(userName, emailId).done(function (response) {

                    if (response) {
                        that.forgetPasswordModel.getForgetPasswordResponse(userName, emailId).done(function (response) {
                            if (response && response.ForgotPassword && response.ForgotPassword.success) {
                                if (response.ForgotPassword.success === "true") {
                                    that.utilityObject.hideLoader();
                                    that.loadLogin();
                                }
                            } else {
                                console.log("submitPassword:forgetPasswordView:Improper object received from server");
                                that.utilityObject.hideLoader();
                            }

                        }).fail(function () {
                            //getForgetPasswordResponse failed
                            console.log("forgetPasswordView:submitPassword:getForgetPasswordResponse:failed");
                            that.utilityObject.hideLoader();

                        });

                    } else {
                        console.log("forgetPasswordView:submitPassword:validateFields:fields are not valid");
                        that.utilityObject.hideLoader();
                    }

                }).fail(function () {
                    console.log("forgetPasswordView:submitPassword:validateFields:function failed");
                    that.utilityObject.hideLoader();
                });
            },

            validateFields: function (username, emailID) {
                var $deferred = new $.Deferred();
                if (username === "") {
                    messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_USERNAME);
                    $deferred.resolve(false);
                } else if (emailID === "" || emailID) {

                    var lastAtPos = emailID.lastIndexOf('@');
                    var lastDotPos = emailID.lastIndexOf('.');

                    if (lastAtPos < lastDotPos && lastAtPos > 0 && emailID.indexOf('@@') == -1 && lastDotPos > 2 && (emailID.length - lastDotPos) > 2) {
                        $deferred.resolve(true);
                    } else {
                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.INVALID_EMAIL);
                        $deferred.resolve(false);
                    }

                } else {
                    $deferred.resolve(true);
                }
                return $deferred.promise();
            }

        });

        return forgetPasswordView;

    });
