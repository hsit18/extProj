/**
 * Dashboard Model:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/Constant',
        'js/model/baseModel/baseModel',
        'js/utilities/Utility',
        'jquery'
    ],
    function (Backbone, CONSTANT, baseModel, Utility, $) {

        'use strict';

        var homeModel = baseModel.extend({

            initialize: function () {
                baseModel.prototype.initialize.call(this);
                this._UtilityObj = new Utility();
                //   this.processDeltaServices();
            },

            getEmployeeData: function () {
                var that = this,
                    $deferred = new $.Deferred(),
                    currentUser = localStorage.getItem('currentUserID');

                that._DBManagerObject.open().done(function () {
                    that._DBManagerObject.select(CONSTANT.DB_TABLES.EMPLOYEES_TABLE).done(function (response) {
                        //console.log("employees table: ", response);

                        var currenrEmployeeData = _.findWhere(response, {
                            "key": currentUser
                        });
                        if (currenrEmployeeData) {
                            var initials = (currenrEmployeeData.value.name).slice(0, 1);
                            var employeeData = {
                                name: currenrEmployeeData.value.name,
                                avatar: currenrEmployeeData.value.avatar, //"images/user.png",
                                contractor_id: currenrEmployeeData.value.contractor_id,
                                initials: initials.toUpperCase()
                            };
                            $deferred.resolve(employeeData);
                        } else {
                            $deferred.reject();
                        }                       

                    }).fail(function () {
                        console.log("unable to select employee table");
                        $deferred.reject();
                    });
                });

                return $deferred.promise();
            },

            processLogoutRequest: function () {

                var that = this,
                    $deferred = new $.Deferred();
                var currentUserID = that._UtilityObj.getLocalStorageStringData(CONSTANT.DB.DB_CURRENT_USER);
                that._DBManagerObject.select(CONSTANT.DB_TABLES.USER_TABLE, currentUserID).done(function (responseObj) {
                    responseObj[0].value.currentTimestamp = that._UtilityObj.getLocalStorageStringData(CONSTANT.DB.DB_CURRENT_TIMESTAMP);
                    that._DBManagerObject.update(CONSTANT.DB_TABLES.USER_TABLE, {
                        key: responseObj[0].key,
                        value: responseObj[0].value
                    }).done(function () {
                        that._UtilityObj.removeLocalStorageData(CONSTANT.DB.DB_CURRENT_USER);
                        that._UtilityObj.removeLocalStorageData(CONSTANT.DB.DB_CURRENT_CONTRACTOR);
                        $deferred.resolve();

                    }).fail(function (error) {
                        console.log("processLogoutRequest:update record failed");
                        console.log(error);
                        $deferred.reject();

                    });
                }).fail(function () {
                    //select query on user table failed
                    console.log("processLogoutRequest:select record failed");
                    $deferred.reject();
                });

                return $deferred.promise();
            }

        });

        return homeModel;
    });
