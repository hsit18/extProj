/**
 * Add New Job View:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date: 17/02/2015
 * Functionality:
 *
 */

 define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Utility',
        'js/utilities/Messenger',
        'js/model/jobs/addNewJobModel',
        'text!templates/addNewJob.html'
 	],

 	function(Backbone, CONSTANT, Utility, Messenger, addNewJobModel, addNewJobTemp){

        var addNewJobData,
            cntAddValue = 1,
            inputFieldArray = [0],
            cnttemp =1,
            messengerObject;

        
 		// Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';

        var addNewJobView = Backbone.View.extend({

        	el: null,

        	initialize: function(){
                this.addNewJobModel = new addNewJobModel();
                this.utilityObject = new Utility();
                messengerObject = Messenger.getInstance();
                //this.render();
                this.getAddNewJobData();
        	},

             addEventListener: function () {
                $('#clientSelection').unbind('change');
                $('#clientSelection').bind('change',{'context':this}, this.loadLocation);
                $('#taskSelection_0').unbind('change');
                $('#taskSelection_0').bind('change', {'cntVal': '0'}, this.loadVehicleandEquipment);
                $('#cancelJob').unbind('click');
                $('#cancelJob').bind('click',{'context':this}, this.cancelJob);
                $('#add1').unbind('click');
                $('#add1').bind('click',{'context':this}, this.addNewTask);
                $('.save').unbind('click');
                $('.save').bind('click',{'context':this}, this.saveNewJob);
            },

        	render: function(addNewJobRes){
                console.log("in render addNewJobView");
                this.$el = $('#pagecontainerDiv');
                addNewJobRes["priority"] = {
                    "High":CONSTANT.JOB_PRIORITY[2],
                    "Medium":CONSTANT.JOB_PRIORITY[1],
                    "Low":CONSTANT.JOB_PRIORITY[0]
                };
                console.log("addNewJobRes-------->>>>",addNewJobRes);
        	    var template = _.template(addNewJobTemp, addNewJobRes);
                this.$el.html(template);   
                this.addEventListener();             
        	},

            loadLocation: function (event) {
                var that = event.data.context;
                var clientIdTemp = document.getElementById("clientSelection");
                var clientId = clientIdTemp.options[clientIdTemp.selectedIndex].value;
                console.log("loadLocation    "+clientId);
                var clientobj = addNewJobData.clients[clientId];
                var str = '<option>Select</option>';
                 _.each(clientobj.locations, function(obj) {  
                    str += '<option value="'+obj.id+'">'+obj.address+ '</option>';
                });
                
                $('#locationSelection').html(str);
                $('#locationSelection').unbind('change');
                $('#locationSelection').bind('change',{'context':that},that.loadPaddocknum);
    
                },

            loadPaddocknum: function (event) {
                var that =event.data.context;
                console.log("loadPaddocknum");
                var clientIdTemp = document.getElementById("clientSelection");
                var clientId = clientIdTemp.options[clientIdTemp.selectedIndex].value;
                var clientLocIdTemp = document.getElementById("locationSelection");
                var clientLocId = clientLocIdTemp.options[clientLocIdTemp.selectedIndex].value;
                var clientobj = addNewJobData.clients[clientId];
                var str = '';
                 _.each(clientobj.locations, function(obj) { 

                     if(obj.id === clientLocId){ 
                        str += '<textarea id="paddockNo">'+obj.paddocks+ '</textarea>';
                     }
                });

                 $('#paddockNumber').html(str);
                
                //Loading Map on CLient Location

                    var element = "map-canvas-addNewjob",
                    loacationTemp = document.getElementById("locationSelection"),
                    address = loacationTemp.options[loacationTemp.selectedIndex].text;
                    that.utilityObject.showAddress(address,element);
             },

            loadVehicleandEquipment: function (event) {
                var TaskId = $(this).val();
                var cntVal = event.data.cntVal;

                var selTasktemp = document.getElementById("taskSelection_"+cntVal),
                    selTaskVal = selTasktemp.options[selTasktemp.selectedIndex].text;

                if(selTaskVal==="Select"){
                 $('#vehicleSelection_'+cntVal).addClass("disabled");
                 $('#equipmentSelection_'+cntVal).addClass("disabled");

                }else{

                var taskobj = addNewJobData.tasks;
                var str = '<option>Select</option>',str2='<option>Select</option>';
                 _.each(taskobj[TaskId].vehicles, function(obj) {
                     str += '<option value="'+obj.id+'">'+obj.vehicle+ '</option>';
                  });

                 _.each(taskobj[TaskId].equipments, function(obj) { 
                    str2 += '<option value="'+obj.id+'">'+obj.equipment+ '</option>';
                    });

                $('#vehicleSelection_'+cntVal).html(str);
                $('#equipmentSelection_'+cntVal).html(str2);

                $('#vehicleSelection_'+cntVal).removeClass("disabled");
                $('#equipmentSelection_'+cntVal).removeClass("disabled");

                } 

            },

            addNewTask:function (event){
                // var cnttemp = 1;
                cnttemp++;
               var that = event.data.context;
               var taskstr = '<option>Select</option>';
               var str = '<div id="tempDiv_'+cntAddValue+'" class="listing-clear">'+ 
                            '<div class="col-md-3">'+
                            '<p>'+
                                '<select id="taskSelection_'+cntAddValue+'">'+
                                    '<option>Select</option>'+
                                    '<option value=>Hello</option>'+
                                    '</select>'+
                                    '</p>'+
                            '</div>'+
                            '<div class="col-md-3">'+                                
                                '<p>'+
                                    '<select class="disabled" id="vehicleSelection_'+cntAddValue+'">'+
                                        '<option>Select</option>'+
                                    '</select>'+
                                '</p>'+
                            '</div>'+
                            '<div class="col-md-3">'+                                
                                '<p class="equipment-select">'+
                                    '<select  class="disabled" id="equipmentSelection_'+cntAddValue+'">'+
                                        '<option>Select</option>'+
                                    '</select>'+                                    
                                '</p>'+
                            '</div>'+
                            '<div class="col-md-3">'+                                
                                '<p>'+
                                    '<input type="text" id="rateSelection_'+cntAddValue+'" class="rate-input" />'+
                                    '<span class="removeTask" id="rem_'+cntAddValue+'">'+
                                    '<img src="images/cross-btn.png">'+
                                '</span>'+
                                '</p>'+
                            '</div>'+
                            '</div>';
                            $('#tasksVehEquipDiv').append(str);
                            var taskobj = addNewJobData.tasks;
                            _.each(taskobj, function(obj) { 
                                    taskstr += '<option value="'+obj.id+'">'+obj.task+ '</option>'; 
                                  });

                            $('#taskSelection_'+cntAddValue).html(taskstr);
                            
                            $('#taskSelection_'+cntAddValue).unbind('change');
                            $('#taskSelection_'+cntAddValue).bind('change', {'cntVal': cntAddValue},that.loadVehicleandEquipment);

                            $('#rem_'+cntAddValue).unbind('click');
                            $('#rem_'+cntAddValue).bind('click', {'cntVal': cntAddValue},that.removeClickedTask);

                            inputFieldArray.push(cntAddValue);
                            cntAddValue++;

            },

            removeClickedTask:function(event){
                                cntAddValue--;
                                var cntAddValueTemp = event.data.cntVal;
                                
                                $("#tempDiv_"+cntAddValueTemp).remove();
                                var i = inputFieldArray.indexOf(cntAddValueTemp);
                                if(i != -1) {
                                    inputFieldArray.splice(i, 1);
                                }
                                if(cntAddValue < 0)
                                {
                                    cntAddValue=0;
                                }
            },

            cancelJob:function(event){
                router.navigate('manageJobs',{
                                    trigger: true
                                });

            },

            saveNewJob: function(event){
                console.log("In save");
                var i,r=0,q=0,s=0,t=0,
                taskflag =false,
                vehicleflag=false,
                equipmentflag=false,
                clentnamelflag=false,
                clientlocflag=false,
                paddockflag=false,
                priorityflag=false,
                startDateflag=false,
                rateflag=false,
                taskObj = [],
                newJobObj ={},
                that = event.data.context,
                $deferred = new $.Deferred();
                var taskobjTemp = addNewJobData.tasks;
                var numberofTasks = Object.keys(taskobjTemp).length;
                var flag =true;

                for(i=0;i<cntAddValue;i++)
                {

                    var taskTemp = document.getElementById("taskSelection_"+inputFieldArray[i]);
                    var taskVal = taskTemp.options[taskTemp.selectedIndex].value;

                    var vehicleTemp = document.getElementById("vehicleSelection_"+inputFieldArray[i]);
                    var vehicleVal = vehicleTemp.options[vehicleTemp.selectedIndex].value;

                    var equipmentsTemp = document.getElementById("equipmentSelection_"+inputFieldArray[i]);
                    var equipmentsVal = equipmentsTemp.options[equipmentsTemp.selectedIndex].value;

                    var rateTemp = document.getElementById("rateSelection_"+inputFieldArray[i]);
                    var rateVal = rateTemp.value;

                    console.log("RATE VALUE-------------------",rateVal);

                    if(taskVal==="Select" || taskVal===null)
                    {
                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.TASK_INVALID); 
                        taskflag =false;
                    }else if(vehicleVal==="Select" || vehicleVal===null)
                    {

                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.VEHICLE_INVALID);
                        vehicleflag=false;
                    }else if(equipmentsVal===null || equipmentsVal=== "Select") //Add equipmentsVal=== "Select"
                    {
                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.EQUIPMENT_INVALID);
                        equipmentflag=false;
                    }else if(rateVal === ""){
                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.RATE_INVALID);
                        rateflag=false;
                    }else{
                     taskObj.push({id:i,task_id:taskVal,vehicle_id:vehicleVal,equipment_id:equipmentsVal,rate:rateVal});
                     taskflag =true;
                     vehicleflag=true;
                     equipmentflag=true;
                     rateflag=true;
                    }
                }

                var clientTemp = document.getElementById("clientSelection");
                    var clientVal = clientTemp.options[clientTemp.selectedIndex].value;
                    if(clientVal==="Select" || clientVal===null)
                    {
                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.CLIENT_INVALID);
                        clentnamelflag=false;

                    }else{
                        clentnamelflag=true;
                    }

                var clientLocTemp = document.getElementById("locationSelection");
                    var clientLocVal = clientLocTemp.options[clientLocTemp.selectedIndex].value;
                    if(clientLocVal==="Select" || clientLocVal===null)
                    {
                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.CLIENT_LOCATION_INVALID);
                        clientlocflag=false;
                    }else{
                        clientlocflag=true;
                    }

                var paddockTemp = document.getElementById("paddockNo");
                    paddockVal = paddockTemp.value;
                    if(paddockVal==="Select" || paddockVal===null)
                    {
                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.PADDOCK_NO_INVALID);
                        paddockflag=false;
                    }else{
                        paddockflag=true;
                    }

                var Start_date_Temp = document.getElementById("calDate");
                    var startVal = Start_date_Temp.value,
                        currentDateTemp = new Date();
                        startDate = new Date(startVal);
                        currentDate = that.utilityObject.convertDate(new Date(currentDateTemp).getTime());
                        startDate = startDate.setHours(0,0,0);
                        startDate = that.utilityObject.convertDate(new Date(startDate).getTime());
                    if(startDate < currentDate || startVal === "" || startVal === "mm/dd/yy")
                    {   
                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.START_DATE_INVALID);
                        startDateflag=false;

                    }else{
                        startDateflag=true;
                    }

                var priorityTemp = document.getElementById("prioritySelect");
                    var prorityVal = priorityTemp.options[priorityTemp.selectedIndex].value;
                    if(prorityVal==="Select" || prorityVal===null)
                    {
                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.PRIORITY_INVALID);
                        priorityflag=false;

                    }else{
                        priorityflag=true;
                    }

                

                if(startDateflag===true && priorityflag===true && paddockflag===true &&  clientlocflag===true && clentnamelflag===true && taskflag ===true && vehicleflag===true && equipmentflag===true && rateflag===true)
                {      
                    for(r = 0;r<inputFieldArray.length;r++)
                    { 
                        for(q = 0;q<inputFieldArray.length;q++){
                               
                               if(r!==q){
                                    var rtemp = document.getElementById("taskSelection_"+inputFieldArray[r]);
                                    var tempInputField = rtemp.options[rtemp.selectedIndex].value;

                                    var qtemp = document.getElementById("taskSelection_"+inputFieldArray[q]);
                                    
                                    if(qtemp){
                                        var tempField = qtemp.options[qtemp.selectedIndex].value;
                                        if( tempInputField === tempField ){
                                        flag =false;  
                                        messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.TASKS_ARE_REPEATED);
                                      }
                                    }else{
                                        flag =false;
                                    }
                                    

                                }
                        }
                    }
                        if(flag){
                            newJobObj = {
                                "client_Id":clientVal,
                                "clientLocation_Id":clientLocVal,
                                "paddock_No":paddockVal,
                                "start_date":startDate,
                                "priority":prorityVal,
                                "task":taskObj
                            };
                                messengerObject.dispatchEvent(Messenger.constants.DISPATCH_ERROR, CONSTANT.ERROR_MESSAGES.SAVED_SUCCESSFULLY);
                                that.addNewJobModel.saveNewJob(newJobObj).done(function(){                       
                                router.navigate('manageJobs',{
                                    trigger: true
                                });
                                inputFieldArray=[0];
                                cntAddValue=1;
                                $deferred.resolve();
                            }).fail(function(){
                                console.log("fail");
                                $deferred.reject();
                            });
                        }


                }                
            
                return $deferred.promise();
            },

            getAddNewJobData: function(){
                var that = this,
                    $deferred = new $.Deferred();

                that.addNewJobModel.addNewJob().done(function(response){
                    addNewJobData = response;
                    that.render(addNewJobData);
                    $deferred.resolve();
                }).fail(function(){
                    console.log("failed to get data");
                    $deferred.reject();
                });

                return $deferred.promise();
            }

    });

        return addNewJobView;
 });