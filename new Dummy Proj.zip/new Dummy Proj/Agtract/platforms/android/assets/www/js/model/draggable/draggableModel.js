define(['Backbone',
        'js/utilities/Constant',
        'js/utilities/Messenger',
        'js/utilities/Utility',
        'js/model/baseModel/baseModel',
        'jquery',
        'js/lib/jquery.md5',
    ],

    function (Backbone, CONSTANT, Messenger, Utility, baseModel, $, md5) {

        'use strict';

        var DraggableCollection = baseModel.extend({

            intialize: function () {
                baseModel.prototype.initialize.call(this);
            },

            currentJobData: function(){
                var that = this,
                    $deferred = new $.Deferred(),
                    currentUser = localStorage.getItem('currentUserID'),
                    taskId,
                    jobId;                    

                that._DBManagerObject.open().done(function(){
                    that._DBManagerObject.select(CONSTANT.DB_TABLES.TIMESHEETS_TABLE).done(function(response){                        

                        var timesheetData = _.where(_.pluck(response, 'value'), {
                            "employee_id": currentUser
                        });

                        console.log("all timesheet for currentUser", timesheetData);

                        if(timesheetData && timesheetData.length>0){

                        // find records having action "Start" and start_time and end_time = null
                        var lastStartRecord = _.findWhere(timesheetData, {
                            "action": CONSTANT.JOB_ACTION.START,
                            "end_time": null
                        });
                        console.log("Start records with start_time and end_time=null", lastStartRecord);

                        // find records having action "Resume" and start_time and end_time = null                        
                        var lastResumeRecord = _.findWhere(timesheetData, {
                            "action": CONSTANT.JOB_ACTION.RESUME,
                            "end_time": null
                        });
                        console.log("Resume records with start_time and end_time=null", lastResumeRecord);

                        if(lastStartRecord){
                            taskId = lastStartRecord.task_id;
                            jobId = lastStartRecord.job_id;                            
                        } else if(lastResumeRecord){
                            taskId = lastResumeRecord.task_id;
                            jobId = lastResumeRecord.job_id;
                        }

                        $.when(
                            that._DBManagerObject.select(CONSTANT.DB_TABLES.TASKS_TABLE),
                            that._DBManagerObject.select(CONSTANT.DB_TABLES.CLIENTS_TABLE),
                            that._DBManagerObject.select(CONSTANT.DB_TABLES.JOBS_TABLE),
                            that._DBManagerObject.select(CONSTANT.DB_TABLES.JOB_TASK_TABLE)
                        ).done(function(tasksRes, clientRes, jobsRes, jobTaskRes){

                            if(taskId){

                                var currentTaskObj = {},

                                currentTask = _.findWhere(_.pluck(tasksRes, 'value'), {
                                    "id": taskId
                                }),

                                jobObj = _.findWhere(_.pluck(jobsRes, 'value'), {
                                    "id": jobId
                                }),

                                clientObj = _.findWhere(_.pluck(clientRes, 'value'), {
                                    "id": jobObj.client_id
                                }),

                                jobTaskObj = _.findWhere(_.pluck(jobTaskRes, 'value'), {
                                    "job_id": jobId,
                                    "task_id": taskId,
                                    "employee_id": currentUser
                                });

                                currentTaskObj["currentTask"] = currentTask;
                                currentTaskObj["currentJob"] = jobObj;
                                currentTaskObj["currentClient"] = clientObj;
                                currentTaskObj["currentJobTask"] = jobTaskObj;

                                that.processTotalTime(jobTaskObj).done(function(totalTime){
                                    currentTaskObj["totalTime"] = totalTime;
                                    $deferred.resolve(currentTaskObj);
                                }).fail(function(){
                                    console.log("failed to calculate total time");
                                    $deferred.reject();
                                });
                            } else {
                                $deferred.resolve(false);
                            }                             

                        }).fail(function(){
                            $deferred.reject();
                        });    
                    }  else{
                        console.log("no current task found");
                        $deferred.resolve(false);
                    }   

                    }).fail(function(){
                        $deferred.reject();
                    });
                });

                return $deferred.promise();
            },

            processTotalTime: function (jobTaskObj) {
                console.log("incoming jobtaskobj", jobTaskObj);
                var that = this,
                    i = 0,
                    time = 0,
                    $deferred = new $.Deferred(),
                    currentUser = localStorage.getItem('currentUserID'),
                    jobsTimesheetRecords = {};
                
                    if(jobTaskObj) {
                        
                        jobsTimesheetRecords[jobTaskObj.id] = {};
                        that._DBManagerObject.select(CONSTANT.DB_TABLES.TIMESHEETS_TABLE).done(function (response) {

                            if (response && response.length > 0) {

                                var timesheetRecords = _.pluck(response, 'value');
                                var jobTSRecords = _.where(timesheetRecords, {
                                    'job_id': jobTaskObj.job_id,
                                    'task_id': jobTaskObj.task_id
                                });
                               
                                var startedRes = _.findWhere(jobTSRecords, {'action': CONSTANT.JOB_ACTION.START});
                                if (startedRes && startedRes.end_time) {
                                    
                                    time = (new Date(startedRes.end_time).getTime()) - (new Date(startedRes.start_time).getTime());
                                    
                                    var resumedRes = _.where(jobTSRecords, {'action': CONSTANT.JOB_ACTION.RESUME});                                    
                                    for (var j in resumedRes) {
                                        time += (new Date(resumedRes[j].end_time).getTime()) - (new Date(resumedRes[j].start_time).getTime());
                                    }
                                    if (time && time > 0) {
                                        jobsTimesheetRecords[jobTaskObj.id]['time_taken'] = that._UtilityObj.calculateTime(time / 1000).slice(0, 5);
                                    }
                                }
                                $deferred.resolve(jobsTimesheetRecords);

                            } else {
                                $deferred.resolve(jobsTimesheetRecords);
                            }

                        });
                    } else {
                        $deferred.resolve();
                    }
                return $deferred.promise();
            }

        });

        return DraggableCollection;
    });
