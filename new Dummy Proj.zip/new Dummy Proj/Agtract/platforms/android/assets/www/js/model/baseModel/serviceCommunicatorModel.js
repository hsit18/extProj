/**
 * Service Communicator Model:
 * Cross Platform: True.
 * Initialization: Initializes on object creation.
 * Date:2/12/2015
 * Functionality:
 *
 */

define(['Backbone',
        'js/utilities/ServiceManager',
        'i18n!js/nls/str',
        'js/utilities/Constant',
        'js/utilities/Utility'
    ],

    function (Backbone, ServiceManager, INTERNATIONALIZATION, CONSTANT, Utility) {

        // Strict mode allows you to place the code in the 'strict' operating context.
        'use strict';

        var serviceCommunicatorModel = Backbone.Model.extend({
            initialize: function () {
                this._serviceManagerObject = new ServiceManager();
                this._utilityObject = new Utility();
            },

            getLoginResponse: function (username, password) {

                var that = this,
                    $deferred = new $.Deferred(),
                    sessionId = this._utilityObject.generateUniqueId();

                // Service request object for web service call.
                var serviceRequestObject = {
                    url: CONSTANT.API.LOGIN_SERVICE,
                    data: {
                        token: "extentia",
                        username: username,
                        password: password,
                        userrole: "Employee",
                        session_id: sessionId
                        
                    },
                    type: CONSTANT.POST_REQUEST,
                    headers: {
                        "Content-type": CONSTANT.APP_CONTENT_TYPE
                    }
                };

                // Sets all the required properties for web service such as data, url, header.
                that._serviceManagerObject.setRequiredProperties(serviceRequestObject);
                // Calls the web service and gets response
                that._serviceManagerObject.getResponse().done(function (response) {
                    if (response) {
                        if (typeof (response) === CONSTANT.STRING) {
                            response = JSON.parse(response);
                        }
                        if (response && response.Login) {
                            localStorage.setItem('session_id', sessionId);
                            $deferred.resolve(response.Login);
                        } else {
                            $deferred.resolve();
                        }

                    } else {
                        $deferred.resolve(response);
                    }
                }).fail(function () {
                    $deferred.reject(INTERNATIONALIZATION.NETWORK_ERROR_STATUS_404);
                });

                return $deferred.promise();
            },

            getDeltaResponse: function () {

                var that = this,
                    $deferred = new $.Deferred(),
                    timestamp = localStorage.getItem(CONSTANT.DB.DB_CURRENT_TIMESTAMP),
                    userId = localStorage.getItem('currentUserID'),
                    sessionId = localStorage.getItem('session_id');

                var serviceRequestObject = {
                    url: CONSTANT.API.DELTA_SERVICE,
                    type: CONSTANT.POST_REQUEST,
                    data: {
                        token: "extentia",
                        timestamp: timestamp,
                        employee_id: userId,
                        session_id: sessionId
                    },
                    headers: {
                        "Content-type": CONSTANT.APP_CONTENT_TYPE
                    }
                };

                that._serviceManagerObject.setRequiredProperties(serviceRequestObject);
                that._serviceManagerObject.getResponse().done(function (response) {
                    if (typeof (response) === CONSTANT.STRING) {
                        response = JSON.parse(response);
                    }
                    console.log("getDeltaResponse response --------- " + JSON.stringify(response));
                    
                    if (response && response.DeltaService) {
                        if(response.DeltaService.valid_user == "true") {
                            if(response.DeltaService.records) {
                                localStorage.setItem(CONSTANT.DB.DB_CURRENT_TIMESTAMP, response.DeltaService.timestamp);
                                $deferred.resolve(response.DeltaService.records);
                            }
                        } else {
                            $deferred.resolve(false);
                        }
                    } else {
                        $deferred.resolve();
                    }

                }).fail(function (response) {
                    $deferred.reject(INTERNATIONALIZATION.NETWORK_ERROR_STATUS_404);
                });

                return $deferred.promise();
            },

            getDownloadDataResponse: function () {

                var userId = localStorage.getItem('currentUserID'),
                    that = this,
                    $deferred = new $.Deferred(),
                    sessionId = localStorage.getItem('session_id');
                
                // Service request object for web service call.
                var serviceRequestObject = {
                    url: CONSTANT.API.DOWNLOAD_DATA_SERVICE,
                    type: CONSTANT.POST_REQUEST,
                    data: {
                        'token': "extentia",
                        'employee_id': userId,
                        'session_id': sessionId
                    },
                    headers: {
                        "Content-type": CONSTANT.APP_CONTENT_TYPE
                    }
                };
                var utilityObject = new Utility();
                that._serviceManagerObject.setRequiredProperties(serviceRequestObject);
                that._serviceManagerObject.getResponse().done(function (response) {
                    if (typeof (response) === CONSTANT.STRING) {
                        response = JSON.parse(response);
                    }
                    console.log("DownloadDataService response --------- " + JSON.stringify(response));
                    
                    if (response && response.DownloadDataService) {
                        if(response.DownloadDataService.valid_user == "true") {
                            if (response.DownloadDataService.timestamp) {
                                utilityObject.setLocalStorageData(CONSTANT.DB.DB_CURRENT_TIMESTAMP, response.DownloadDataService.timestamp);
                            }
                            if(response.DownloadDataService.records) {                                
                                $deferred.resolve(response.DownloadDataService.records);
                            }
                        } else {
                            $deferred.resolve(false);
                        }
                    } else {
                        $deferred.resolve();
                    }                   
                }).fail(function (response) {
                    $deferred.reject(INTERNATIONALIZATION.NETWORK_ERROR_STATUS_404);
                });

                return $deferred.promise();
            },

            getDashboardData: function () {
                //Service Manager call to fetch json data from temp folder 
                var that = this;
                var $deferred = new $.Deferred();

                var serviceRequestObject = {
                    url: CONSTANT.API.DASHBOARD_SERVICE,
                    data: {
                        token: "extentia",
                        username: "admin",
                        password: "admin123"
                    },
                    type: CONSTANT.GET_REQUEST,
                    headers: {
                        "Content-type": CONSTANT.APP_CONTENT_TYPE
                    }
                };

                that._serviceManagerObject.setRequiredProperties(serviceRequestObject, true);

                that._serviceManagerObject.getResponse().done(function (response) {
                    if (typeof (response) === CONSTANT.STRING) {
                        response = JSON.parse(response);
                    }
                    if (response) {
                        $deferred.resolve(response);
                    } else {
                        $deferred.resolve();
                    }

                }).fail(function () {
                    $deferred.reject(INTERNATIONALIZATION.NETWORK_ERROR_STATUS_404);
                });
                return $deferred.promise();
            },

            syncRecordToServer: function (currentUserId, syncServiceObj) {
                var that = this,
                    $deferred = new $.Deferred(),
                    sessionId = localStorage.getItem('session_id');

                var serviceRequestObject = {
                    url: CONSTANT.API.SYNC_SERVICE,
                    data: {
                        token: "extentia",
                        employee_id: currentUserId,
                        records: syncServiceObj,
                        session_id: sessionId
                        
                    },
                    type: CONSTANT.POST_REQUEST,
                    headers: {
                        "Content-type": CONSTANT.APP_CONTENT_TYPE
                    }
                };

                that._serviceManagerObject.setRequiredProperties(serviceRequestObject);
                that._serviceManagerObject.getResponse().done(function (response) {

                    if (typeof (response) === CONSTANT.STRING) {
                        response = JSON.parse(response);
                    }
                    console.log("syncRecordToServer response --------- " + JSON.stringify(response));
                    if (response && response.SyncService) {
                        if(response.SyncService.valid_user == "true") {
                            if(response.SyncService.records) {
                                $deferred.resolve(response.SyncService.records);
                            }
                        } else {
                            $deferred.resolve(false);
                        }
                    } else {
                        $deferred.resolve();
                    }

                }).fail(function () {
                    $deferred.reject(INTERNATIONALIZATION.NETWORK_ERROR_STATUS_404);
                });

                return $deferred.promise();
            },

            getForgetPasswordResponse: function (userName, emailId) {
                var that = this;
                var $deferred = new $.Deferred();
                // Service request object for web service call.
                var serviceRequestObject = {
                    url: CONSTANT.API.FORGET_PASSWORD,
                    data: {
                        token: "extentia",
                        username: userName,
                        email: emailId
                            // userrole:"employee"
                    },
                    type: CONSTANT.GET_REQUEST,
                    headers: {
                        "Content-type": CONSTANT.APP_CONTENT_TYPE
                    }
                };

                // Sets all the required properties for web service such as data, url, header.
                that._serviceManagerObject.setRequiredProperties(serviceRequestObject);
                // Calls the web service and gets response
                that._serviceManagerObject.getResponse().done(function (responseObj) {
                    if (typeof (responseObj) === CONSTANT.STRING) {
                        responseObj = JSON.parse(responseObj);
                    }
                    if (responseObj && responseObj.ForgotPassword) {
                        $deferred.resolve(responseObj.ForgotPassword);
                    } else {
                        $deferred.resolve();
                    }

                }).fail(function () {
                    $deferred.reject(INTERNATIONALIZATION.NETWORK_ERROR_STATUS_404);
                });

                return $deferred.promise();
            },

            syncImageToServer: function (currentUserId, syncServiceObj) {
                var that = this,
                    $deferred = new $.Deferred(),
                    sessionId = localStorage.getItem('session_id');

                var serviceRequestObject = {
                    url: CONSTANT.API.IMAGE_SYNC_SERVICE,
                    data: {
                        token: "extentia",
                        employee_id: currentUserId,
                        records: syncServiceObj,
                        session_id: sessionId
                    },
                    type: CONSTANT.POST_REQUEST,
                    headers: {
                        "Content-type": CONSTANT.APP_CONTENT_TYPE
                    }
                };

                that._serviceManagerObject.setRequiredProperties(serviceRequestObject);
                that._serviceManagerObject.getResponse().done(function (response) {

                    if (typeof (response) === CONSTANT.STRING) {
                        response = JSON.parse(response);
                    }
                    console.log("syncImageToServer response --------- " + JSON.stringify(response));
                    
                    if (response && response.SyncService) {
                        if(response.SyncService.valid_user == "true") {
                            if(response.SyncService.records) {
                                $deferred.resolve(response.SyncService.records);
                            }
                        } else {
                            $deferred.resolve(false);
                        }
                    } else {
                        $deferred.resolve();
                    }

                }).fail(function () {
                    $deferred.reject(INTERNATIONALIZATION.NETWORK_ERROR_STATUS_404);
                });
                return $deferred.promise();
            }

        });

        return serviceCommunicatorModel;
    });
