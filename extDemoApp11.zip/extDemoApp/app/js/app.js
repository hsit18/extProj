;(function (window, undefined) {
    'use strict';

    var ExtDemoApp = ExtDemoApp || {};

    ExtDemoApp.services = angular.module('ExtDemoApp.services', []);
    ExtDemoApp.controllers = angular.module('ExtDemoApp.controllers', []);
    ExtDemoApp.directives = angular.module('ExtDemoApp.directives', []);

    ExtDemoApp.main = angular.module('ExtDemoApp',
        							[
        							 'ngRoute',
        							 'ExtDemoApp.services',
        							 'ExtDemoApp.directives',
        							 'ExtDemoApp.controllers',

        							])
    .config(['$routeProvider',function($routeProvider){
        $routeProvider.

         when("/drivers", {
                templateUrl: "templates/drivers.html",
                controller: "driversController",
                //customData:"Prashant"
         }).

         when("/driverDetails/:id",{
                templateUrl: "templates/driverDetails.html",
                controller: "driversDetailsController",
                //customData:"Patil"
         }).

         otherwise({redirectTo: '/drivers'});

         /*$stateProvider
         .state('app', {
               url: "/app",
               templateUrl: "templates/menu.html",
               controller: 'HomeCtrl'
         })*/

    }]);

    window.ExtDemoApp = ExtDemoApp || {};




})(window);

