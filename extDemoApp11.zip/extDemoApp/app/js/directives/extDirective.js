;(function (module, undefined) {
    'use strict';

    module.directive('extDirective',function() {
          return {
                templateUrl: 'templates/extDirectiveTemplate.html'
          };
    });


})(ExtDemoApp.directives);