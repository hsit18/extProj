;(function (module, undefined) {
    'use strict';

    module.factory('extDemoService',['$http', function($http) {

        var serviceObj = {};

        serviceObj.getDrivers = function() {
          return $http({
            method: 'JSONP',
            url: 'http://ergast.com/api/f1/2013/driverStandings.json?callback=JSON_CALLBACK'
          });
        }

        serviceObj.getDriverDetails = function(id,successCB,errorCB) {
          $http.jsonp('http://ergast.com/api/f1/2013/drivers/'+ id +'/driverStandings.json?callback=JSON_CALLBACK').
                 success(function(data, status, headers, config){
                        return successCB(data);
                 }).error(function(data, status, headers, config){
                        return errorCB(data);
                 });

        }

        serviceObj.getDriverRaces = function(id) {
          return $http({
            method: 'JSONP',
            url: 'http://ergast.com/api/f1/2013/drivers/'+ id +'/results.json?callback=JSON_CALLBACK'
          });
        }

        return serviceObj;
    }]);


})(ExtDemoApp.services);


