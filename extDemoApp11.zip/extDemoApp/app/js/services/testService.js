;(function (module, undefined) {
    'use strict';

    module.service('testService',function() {

        this.getRandomId = function(){
             return Math.floor((Math.random() * 10) + 1);
        }

    });


})(ExtDemoApp.services);


