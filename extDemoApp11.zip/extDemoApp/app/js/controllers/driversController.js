;(function (module, undefined) {
    'use strict';

    module.controller('driversController',['$scope','$route', 'extDemoService','testService', function($scope, $route,extDemoService,testService) {
         $scope.nameFilter = null;
         $scope.driversList = [];
         $scope.isAddDriver = false;
         console.log('$route custom data',$route.current.testData);
         $scope.addNewDriver = function(){
            $scope.isAddDriver = true;
         },

         $scope.saveDriver = function(driver){
            var object = {
                id:testService.getRandomId(),
                points:driver.points,
                isLocal:true,
                Driver:{
                    familyName:driver.familyName,
                    givenName:driver.givenName,
                    nationality:'Indian',
					driverId:testService.getRandomId()
                },
                Constructors:[
                    {
                        name:driver.team
                    }
                ]
            };
            $scope.driversList.push(object);
            $scope.isAddDriver = false;
            $scope.driver = {};
         },

         $scope.deleteDriver = function(id){
            $scope.list = $scope.driversList;
            for(var i=0;i<$scope.list.length;i++){
                 if($scope.list[i].id && $scope.list[i].id == id){
                     $scope.list.splice(i, 1);
                 }
            }
            $scope.driversList = $scope.list;

         },

         $scope.searchFilter = function (driver) {
             var re = new RegExp($scope.nameFilter, 'i');
             return !$scope.nameFilter || re.test(driver.Driver.givenName) || re.test(driver.Driver.familyName);
         };

         extDemoService.getDrivers().success(function (response) {
             $scope.driversList = response.MRData.StandingsTable.StandingsLists[0].DriverStandings;
         });

    }]);


})(ExtDemoApp.controllers);



