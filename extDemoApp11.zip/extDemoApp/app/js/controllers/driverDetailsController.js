;(function (module, undefined) {
    'use strict';

    module.controller('driversDetailsController',['$scope', '$routeParams','$route', 'extDemoService','$location',
        function($scope, $routeParams, $route, extDemoService,$location) {
            $scope.id = $routeParams.id;
            console.log('$route custom data',$route.current);
            $scope.races = [];
            $scope.driver = null;

            extDemoService.getDriverDetails($scope.id,function(response){
                 if(response.MRData.StandingsTable.StandingsLists.length > 0){
                    $scope.driver = response.MRData.StandingsTable.StandingsLists[0].DriverStandings[0];
                 }else{
                     alert('No Details Available');
                     $location.path('/drivers');
                 }

            },function(error){

            });

            extDemoService.getDriverRaces($scope.id).success(function (response) {
                $scope.races = response.MRData.RaceTable.Races;
            });

    }]);


})(ExtDemoApp.controllers);