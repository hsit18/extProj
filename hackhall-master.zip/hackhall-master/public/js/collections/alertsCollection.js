define([], function () { 
	return  Backbone.Collection.extend({
	});
});